# Financial Complaints Intelligence

Read the accompanying case study for scope, definitions and reproduction steps. Source records were obtained from the official CFPB API on 22 November 2026. This archive includes grouped facts and original project code, not consumer narratives or individual IDs. Use build.py directly; make_builder.py was only a local development scaffold. The standalone builder needs tableauhyperapi. The aggregate count field, not row count, represents complaints.
