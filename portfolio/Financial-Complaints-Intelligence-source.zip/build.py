from pathlib import Path
import csv,json,copy,sys,zipfile,uuid,xml.etree.ElementTree as E
P=Path(__file__).parent;F=json.loads((P/'schema.json').read_text());data=list(csv.DictReader((P/'complaints.csv').open(encoding='utf-8')))
BG='#EFF3F8';CARD='#FFFFFF';INK='#172D4B';MUTED='#526B75';TEAL='#087F8C';BLUE='#477CB6';CORAL='#CF704F';GOLD='#AC7C33';LINE='#D9E5E6'
def el(p,t,text=None,**a):
 q=E.SubElement(p,t,{k.replace('_','-'):str(v) for k,v in a.items()})
 if text is not None:q.text=str(text)
 return q
root=E.Element('workbook',{'source-platform':'win','version':'18.1','source-build':'2026.3.0 (20263.26.1022.1645)'})
m=el(root,'document-format-change-manifest')
for n in ['IntuitiveSorting','IntuitiveSorting_SP2','BasicButtonObject','BasicButtonObjectTextSupport','SheetIdentifierTracking','WindowsPersistSimpleIdentifiers']:el(m,n)
datas=el(root,'datasources');params=el(datas,'datasource',name='Parameters',hasconnection='false',inline='true',version='18.1');el(params,'aliases',enabled='yes')
def parameter(n,default,values,caption=None):
 typ='string' if isinstance(default,str) else 'integer';val=json.dumps(default);c=el(params,'column',name=f'[{n}]',caption=caption or n,datatype=typ,role='measure',type='nominal' if typ=='string' else 'quantitative',param_domain_type='list',value=val)
 if typ!='string':c.set('default-format','n0')
 el(c,'calculation',**{'class':'tableau','formula':val});mem=el(c,'members')
 for v in values:el(mem,'member',value=json.dumps(v))
parameter('Product','All products',['All products','Bank accounts','Credit cards','Money services'],'Portfolio product')
parameter('Focus product','Bank accounts',['Bank accounts','Credit cards','Money services'],'Product to investigate')
parameter('Period','2025',['2025','2024','Both years'],'Received period')
parameter('Company','All cohort companies',['All cohort companies']+sorted({r['Company'] for r in data if r['Company']!='Other companies'}),'Company · fixed 2024–25 top-10 cohorts')
ds=el(datas,'datasource',name='health',caption='Financial Complaints | CFPB aggregate records',inline='true',version='18.1')
cn=el(ds,'connection',**{'class':'federated'});nc=el(el(cn,'named-connections'),'named-connection',name='textscan.health',caption='health');el(nc,'connection',**{'class':'textscan','directory':'','filename':'complaints.csv','server':'','workgroup-auth-mode':'as-is'})
rel=el(cn,'relation',name='complaints.csv',table='[complaints#csv]',type='table',connection='textscan.health');cols=el(rel,'columns',header='yes',separator=',',character_set='UTF-8',locale='en_US');md=el(cn,'metadata-records')
for i,(n,t) in enumerate(F.items()):
 el(cols,'column',name=n,datatype=t,ordinal=i);rec=el(md,'metadata-record',**{'class':'column'})
 for a,b in [('remote-name',n),('remote-type',129 if t=='string' else 20 if t=='integer' else 5),('local-name',f'[{n}]'),('parent-name','[complaints.csv]'),('remote-alias',n),('ordinal',i),('local-type',t),('aggregation','Count' if t=='string' else 'Sum'),('contains-null','true')]:el(rec,a,b)
el(ds,'aliases',enabled='yes')
for n,t in F.items():el(ds,'column',name=f'[{n}]',datatype=t,role='dimension' if t=='string' else 'measure',type='nominal' if t=='string' else 'quantitative')
C={}
def calc(n,t,f,fmt=None,dim=False):C[n]=(t,f,fmt,dim)
calc('Portfolio scope','string',"IF [Parameters].[Product]='All products' OR [Product]=[Parameters].[Product] THEN 'Yes' ELSE 'No' END",dim=True)
calc('Focus scope','string',"IF [Product]=[Parameters].[Focus product] THEN 'Yes' ELSE 'No' END",dim=True)
calc('Period scope','string',"IF [Parameters].[Period]='Both years' OR STR([Year])=[Parameters].[Period] THEN 'Yes' ELSE 'No' END",dim=True)
calc('Company scope','string',"IF [Parameters].[Company]='All cohort companies' OR [Company]=[Parameters].[Company] THEN 'Yes' ELSE 'No' END",dim=True)
calc('Cohort scope','string',"IF [Company rank]<=10 THEN 'Yes' ELSE 'No' END",dim=True)
calc('Volume','integer','SUM([Complaints])','n#,##0')
calc('Timely rate','real',"SUM(IF [Timely]='Yes' THEN [Complaints] ELSE 0 END)/SUM(IF [Timely]='Yes' OR [Timely]='No' THEN [Complaints] ELSE 0 END)",'p0.0%')
calc('Untimely count','integer',"SUM(IF [Timely]='No' THEN [Complaints] ELSE 0 END)",'n#,##0')
calc('Known timely','integer',"SUM(IF [Timely]='Yes' OR [Timely]='No' THEN [Complaints] ELSE 0 END)",'n#,##0')
calc('Relief rate','real',"SUM(IF [Response]='Monetary relief' THEN [Complaints] ELSE 0 END)/SUM([Complaints])",'p0.0%')
calc('YoY change','real',"(SUM(IF [Year]=2025 THEN [Complaints] ELSE 0 END)-SUM(IF [Year]=2024 THEN [Complaints] ELSE 0 END))/SUM(IF [Year]=2024 THEN [Complaints] ELSE 0 END)",'p0.0%')
calc('Year series','string','STR([Year])',dim=True)
calc('Month of year','string','RIGHT([Month],2)',dim=True)
calc('Volume band','string',"IF [Complaints]<10 THEN 'Below 10' ELSEIF [Complaints]<100 THEN '10–99' ELSEIF [Complaints]<1000 THEN '100–999' ELSE '1000+' END",dim=True)
calc('Context','string',"[Parameters].[Period]+' | '+[Parameters].[Focus product]+' | Snapshot 22 Nov 2026'",dim=True)
for n,(t,f,fmt,dim) in C.items():
 c=el(ds,'column',name=f'[{n}]',datatype=t,role='dimension' if dim else 'measure',type='nominal' if t=='string' else 'quantitative')
 if fmt:c.set('default-format',fmt)
 el(c,'calculation',**{'class':'tableau','formula':f})
def ref(n,der=None):
 dim=F.get(n)=='string' or C.get(n,(None,None,None,False))[3];der=der or ('none' if dim else 'usr' if n in C else 'min')
 return f'[health].[{der}:{n}:{"nk" if F.get(n)=="string" or C.get(n,(None,))[0]=="string" else "qk"}]'
def inst(n):return ref(n).split('[health].')[1]
def pdep(p):
 dep=el(p,'datasource-dependencies',datasource='Parameters')
 for c in params.findall('column'):dep.append(copy.deepcopy(c))
actions=el(root,'actions')
for i,d in enumerate(['01 Executive Brief','02 Product Investigation','03 Company Lens']):
 a=el(actions,'action',caption='Open official CFPB source and definitions',name=f'[Source{i}]');el(a,'source',dashboard=d,type='sheet');el(a,'link',caption='',expression='https://www.consumerfinance.gov/data-research/consumer-complaints/')
works=el(root,'worksheets');names=[];dsstyle=el(ds,'style');dsmark=el(dsstyle,'style-rule',element='mark');colorfields=set()
def sheet(name,measure,kind=None,filters=None,mark='Text',rows='',cols='',series=None,path=None,labels=True,size=11,color=TEAL,label_field=None):
 names.append(name);w=el(works,'worksheet',name=name);el(el(el(w,'layout-options'),'title'),'formatted-text');t=el(w,'table');v=el(t,'view');el(el(v,'datasources'),'datasource',name='health',caption=ds.get('caption'));pdep(v);dep=el(v,'datasource-dependencies',datasource='health')
 for c in ds.findall('column'):dep.append(copy.deepcopy(c))
 for n in list(F)+list(C):
  q=inst(n);der=q[1:].split(':')[0];el(dep,'column-instance',column=f'[{n}]',derivation={'none':'None','min':'Min','usr':'User'}[der],name=q,pivot='key',type='nominal' if q.endswith(':nk]') else 'quantitative')
 for n,typ in F.items():
  if typ=='string':el(dep,'column-instance',column=f'[{n}]',derivation='Attribute',name=f'[attr:{n}:nk]',pivot='key',type='nominal')
 fil=dict(filters or {})

 for n,values in fil.items():
  g=el(el(v,'filter',**{'class':'categorical','column':ref(n)}),'groupfilter',function='union')
  for val in values:el(g,'groupfilter',function='member',level=inst(n),member=json.dumps(val))
 el(v,'aggregation',value='true');sty=el(t,'style')
 for element,fmts in [('worksheet',{'font-family':'Tableau Book','font-size':'11','color':INK,'background-color':CARD,'display-field-labels':'false'}),('pane',{'background-color':CARD,'band-color':CARD,'band-size':'0'}),('cell',{'background-color':CARD,'color':INK}),('header',{'background-color':CARD,'color':MUTED,'font-size':'10','band-color':CARD,'band-size':'0'}),('axis',{'background-color':CARD,'color':MUTED,'font-size':'10'}),('gridline',{'stroke-size':'0'}),('zeroline',{'stroke-size':'1','stroke-color':LINE})]:
  s=el(sty,'style-rule',element=element)
  for a,b in fmts.items():el(s,'format',attr=a,value=b)
 for f,side in [(rows,'rows'),(cols,'cols')]:
  if f:el(el(sty,'style-rule',element='axis'),'format',attr='title',field=f,scope=side,value='')

 pane=el(el(t,'panes'),'pane',selection_relaxation_option='selection-relaxation-allow');el(el(pane,'view'),'breakdown',value='auto');el(pane,'mark',**{'class':mark});en=el(pane,'encodings')
 if labels or mark=='Text':el(en,'text',column=ref(label_field or measure))
 if name=='Product volume':el(en,'size',column=ref('Volume'));el(en,'text',column=ref('Product'))
 if path:el(en,'path',column=ref(path))
 if series:
  el(en,'color',column=ref(series))
  if series not in colorfields:
   e=el(dsmark,'encoding',attr='color',field=inst(series),type='palette')
   mapping={'Product':{'Bank accounts':TEAL,'Credit cards':BLUE,'Money services':CORAL},'Year series':{'2024':BLUE,'2025':TEAL}}[series]
   for val,col in mapping.items():el(el(e,'map',to=col),'bucket',json.dumps(val))
   colorfields.add(series)
 for n in ['Product','Issue','Company','Response','Timely','Channel','Month']:el(en,'tooltip',column=f'[health].[attr:{n}:nk]')
 for n in ['Volume','Known timely','Untimely count','Timely rate']:el(en,'tooltip',column=ref(n))
 tip='Displayed measure: <'+ref(measure)+'>\nComplaints in this mark: <'+ref('Volume')+'>\nKnown timely-response denominator: <'+ref('Known timely')+'>\nUntimely responses: <'+ref('Untimely count')+'>\nTimely-response rate: <'+ref('Timely rate')+'>\nProduct: <[health].[attr:Product:nk]>\nIssue: <[health].[attr:Issue:nk]>\nCompany/cohort: <[health].[attr:Company:nk]>\nResponse: <[health].[attr:Response:nk]>\nMonth: <[health].[attr:Month:nk]>\nCFPB snapshot: 22 Nov 2026. Complaint counts are not customer complaint rates.'
 el(el(el(pane,'customized-tooltip'),'formatted-text'),'run',tip,fontsize=10,fontcolor=INK)
 if labels or mark=='Text':el(el(el(pane,'customized-label'),'formatted-text'),'run',('<'+ref('Product')+'>\n<'+ref(measure)+'>' if name=='Product volume' else '<'+ref(label_field or measure)+'>'),fontsize=size,fontname='Tableau Semibold' if size>=18 else 'Tableau Book',fontcolor='#FFFFFF' if name=='Product volume' else INK)
 st=el(el(pane,'style'),'style-rule',element='mark')
 for a,b in {'mark-color':color,'mark-transparency':'255','size':'3' if mark=='Square' else '.65','has-stroke':'false','mark-labels-show':'true' if labels or mark=='Text' else 'false'}.items():el(st,'format',attr=a,value=b)
 el(t,'rows',rows);el(t,'cols',cols);el(w,'simple-id',uuid='{'+str(uuid.uuid5(uuid.NAMESPACE_DNS,'health-sheet-'+name)).upper()+'}')
 return w

portfolio={'Portfolio scope':['Yes']};period={'Period scope':['Yes']};focus={'Focus scope':['Yes']};company={'Company scope':['Yes']}
for n,m in [('Portfolio count','Volume'),('Portfolio timely','Timely rate'),('Portfolio relief','Relief rate')]:sheet(n,m,filters={**portfolio,**period},size=30)
sheet('Portfolio growth','YoY change',filters=portfolio,size=30)
sheet('Portfolio trend','Volume',filters=portfolio,mark='Line',rows=ref('Volume'),cols=ref('Month'),series='Product',path='Month',labels=False)
sheet('Product volume','Volume',filters=period,mark='Square',series='Product',size=12)
sheet('Channel volume','Volume',filters={**portfolio,**period},mark='Bar',rows=ref('Channel'),cols=ref('Volume'),size=12,color=BLUE)
for n,m in [('Focus count','Volume'),('Focus timely','Timely rate'),('Focus relief','Relief rate')]:sheet(n,m,filters={**focus,**period},size=30)
sheet('Focus context','Context',size=12)
sheet('Issue volume','Volume',filters={**focus,**period},mark='Bar',rows=ref('Issue'),cols=ref('Volume'),size=11)
sheet('Response volume','Volume',filters={**focus,**period},mark='Bar',rows=ref('Response'),cols=ref('Volume'),size=11,color=CORAL)
sheet('Issue trend','Volume',filters=focus,mark='Line',rows=ref('Volume'),cols=ref('Month of year'),series='Year series',path='Month of year',labels=False)
for n,m in [('Company count','Volume'),('Company timely','Timely rate'),('Company relief','Relief rate')]:sheet(n,m,filters={**focus,**period,**company,'Cohort scope':['Yes']},size=30)
sheet('Company volumes','Volume',filters={**focus,**period,'Cohort scope':['Yes']},mark='Bar',rows=ref('Company'),cols=ref('Volume'),size=11)
sheet('Company timeliness','Timely rate',filters={**focus,**period,'Cohort scope':['Yes']},mark='Bar',rows=ref('Company'),cols=ref('Timely rate'),size=11,color=BLUE)
sheet('Company trend','Volume',filters={**focus,**company,'Cohort scope':['Yes']},mark='Line',rows=ref('Volume'),cols=ref('Month'),labels=False)
W=1440;H=1120;boards=el(root,'dashboards');used={};current=None;base=None
board_names=['01 Executive Brief','02 Product Investigation','03 Company Lens','04 Data Guide']
ids={n:'{'+str(uuid.uuid5(uuid.NAMESPACE_DNS,'financial-complaints-window-'+n)).upper()+'}' for n in board_names}
def zone(x,y,w,h,kind=None,text=None,font=11,fg=INK,bg=CARD,name=None,**a):
 q=el(base,'zone',id=len(base)+1,h=round(h/H*100000),w=round(w/W*100000),x=round(x/W*100000),y=round(y/H*100000),is_floating='true',**a)
 if kind:q.set('type-v2',kind)
 if name:q.set('name',name);used[current].append(name)
 if text is not None:el(el(q,'formatted-text'),'run',text,fontname='Tableau Semibold' if font>=14 else 'Tableau Book',fontsize=font,fontcolor=fg)
 st=el(q,'zone-style')
 for attr,val in {'background-color':bg,'border-style':'none','padding':'0','margin':'0'}.items():el(st,'format',attr=attr,value=val)
 return q
def txt(s,x,y,w,h,font=11,fg=MUTED,bg=BG):return zone(x,y,w,h,'text',text=s,font=font,fg=fg,bg=bg)
def control(n,x,y,w=334,h=61):return zone(x,y,w,h,'paramctrl',param=f'[Parameters].[{n}]',mode='compact',bg=CARD)
def dash(n,title,sub):
 global base,current
 current=n;used[n]=[];d=el(boards,'dashboard',name=n);el(d,'style');el(d,'size',minwidth=W,maxwidth=W,minheight=H,maxheight=H);el(el(d,'datasources'),'datasource',name='Parameters');pdep(d)
 base=el(el(d,'zones'),'zone',id=0,x=0,y=0,w=100000,h=100000,type_v2='layout-basic');zone(0,0,W,H,'empty',bg=BG)
 zone(0,0,W,110,'bitmap',param='Image/header.svg',is_scaled='1',is_centered='1',bg=INK)
 txt(title,28,27,1140,55,28,'#FFFFFF',INK);txt('JULIAN DEVONISH',1210,27,205,24,10,'#A9DCD3',INK);txt('FINANCIAL COMPLAINTS',1170,66,245,22,9,'#D2ECE7',INK)
 for i,(dest,caption) in enumerate(zip(board_names,['01 Executive brief','02 Product investigation','03 Company lens','04 Data & guide'])):
  q=zone(28+i*350,120,334,31,'dashboard-object',bg=BG);b=el(q,'button',action=f'tabdoc:goto-sheet window-id="{ids[dest]}"',button_type='text');s=el(b,'button-visual-state');el(s,'caption',caption);el(s,'button-caption-font-style',fontcolor='#FFFFFF' if n==dest else INK,fontname='Tableau Semibold',fontsize=10);el(s,'format',attr='background-color',value=TEAL if n==dest else '#E0EAEA')
 txt(sub,28,162,1384,25,10)
 txt('SOURCE: U.S. CFPB · Received 2024-2025 · Snapshot 22 Nov 2026 · Published complaints, not a representative customer sample',28,1080,1384,25,9)
def panel(sheetname,x,y,w,h,title,sub):
 zone(x,y,w,h,'empty');zone(x,y,4,h,'empty',bg=LINE);txt(title,x+17,y+13,w-34,32,16,INK,CARD);txt(sub,x+17,y+53,w-34,29,10,MUTED,CARD);zone(x+10,y+88,w-20,h-98,name=sheetname,show_title='false')
def card(n,title,sub,x,y,w=334,color=TEAL):
 zone(x,y,w,119,'empty');zone(x,y,w,3,'empty',bg=color);txt(title,x+13,y+12,w-26,27,11,MUTED,CARD);zone(x+8,y+42,w-16,49,name=n,show_title='false');txt(sub,x+13,y+94,w-26,22,9,MUTED,CARD)
def block(title,body,x,y,w,h,accent=TEAL):
 zone(x,y,w,h,'empty');txt(title,x+18,y+17,w-36,33,16,accent,CARD);txt(body,x+18,y+66,w-36,h-77,11,MUTED,CARD)


dash(board_names[0],'From complaints to clearer service priorities.','U.S. consumer-finance complaints · Bank accounts, credit cards and money services · Separate volume, response timeliness and response outcomes.')
control('Product',28,198,684);control('Period',732,198,680)
for i,(n,t,s,c) in enumerate([('Portfolio count','Published complaints','Selected period and product',TEAL),('Portfolio growth','Change in complaint volume','2025 versus 2024 · selected product',BLUE),('Portfolio timely','Timely-response rate','Yes / (Yes + No) · selected scope',INK),('Portfolio relief','Monetary-relief response','Share of all selected complaints',CORAL)]):card(n,t,s,28+i*350,282,color=c)
panel('Portfolio trend',28,425,1384,300,'The complaint trajectory','Both years · X: YY-MM · Teal: accounts · Blue: cards · Coral: money services · Product selector applies')
panel('Product volume',28,747,684,283,'Product mix in the selected period','All three products for context · Product selector does not filter this panel')
panel('Channel volume',732,747,680,283,'How complaints reached the CFPB','Selected product and period · CFPB submission channel')
txt('Dataset context: January contributed 29.8% of 2025 complaints across these three products. The spike warrants investigation; it does not establish a cause.',28,1043,1384,28,10,CORAL)

dash(board_names[1],'Find the friction. Understand the response.','Investigate one product at a time. Issue groups use the eight largest 2024–25 categories for that product; smaller categories remain in Other issues.')
control('Focus product',28,198,684);control('Period',732,198,680)
for i,(n,t,s,c) in enumerate([('Focus count','Complaints to investigate','Selected product and period',TEAL),('Focus timely','Timely-response rate','Yes / known Yes-No values',BLUE),('Focus relief','Monetary-relief response','Share of selected complaints',CORAL)]):card(n,t,s,28+i*350,282,color=c)
txt('Response is a reported category.\nIt does not prove satisfaction\nor the merits of a complaint.',1091,310,308,75,11,CORAL)
panel('Issue volume',28,425,830,382,'Which reported issues recur?','Selected period · Short display labels; full source categories are mapped in GitHub')
panel('Response volume',878,425,534,382,'What response was reported?','Selected period · Counts, not confirmed resolution quality')
panel('Issue trend',28,829,1384,208,'Compare the same months across years','Selected product · Both years remain visible · Blue: 2024 · Teal: 2025 · X: calendar month (01–12)')

dash(board_names[2],'Compare patterns, not unsupported league tables.','Fixed company cohorts: ten largest complaint volumes per product across 2024–25. Company size, customers and transaction denominators are unavailable.')
control('Focus product',28,198,450);control('Period',497,198,300);control('Company',817,198,595)
for i,(n,t,s,c) in enumerate([('Company count','Selected cohort complaints','Company selector applies to cards',TEAL),('Company timely','Timely-response rate','Yes / known Yes-No values',BLUE),('Company relief','Monetary-relief response','Share of selected cohort complaints',CORAL)]):card(n,t,s,28+i*350,282,color=c)
txt('A company outside the selected\nproduct cohort returns blank.\nChoose All cohort companies.',1091,310,308,75,11,CORAL)
panel('Company volumes',28,425,684,373,'Cohort complaint volumes','Product + period · Full cohort; selector affects cards/trend')
panel('Company timeliness',732,425,680,373,'Cohort timely-response rates','Same cohort · Yes / (Yes + No) · Hover for denominators and untimely counts')
panel('Company trend',28,820,1384,217,'Track the selected company or cohort','Both years · Selected product and company · No customer-normalised complaint rate is inferred')

dash(board_names[3],'The definitions are part of the analysis.','Independent portfolio analysis of official U.S. CFPB records. No synthetic complaints, narrative text, ZIP codes or individual complaint IDs are published here.')
block('01 / Scope and provenance','Complaints received in calendar 2024 and 2025, for three\nsource products: Checking or savings account; Credit card;\nMoney transfer, virtual currency, or money service.\nDownloaded through the official CFPB API on 22 Nov 2026.\nThe extract is a dated snapshot, not a live feed.\nLater responses and database revisions can change results.',28,208,684,252)
block('02 / Published does not mean representative','CFPB publishes eligible complaints sent to companies.\nPublication follows a response confirming a relationship\nor 15 days, whichever comes first. Some complaints go\nto other regulators and are not included. These records\nare not a statistical sample of all customer experiences.\nCounts cannot establish fraud, fault or company quality.',732,208,680,252)
block('03 / Calculations and denominators','Volume = sum of aggregated complaint counts.\nTimely-response rate = Yes / (Yes + No); unknown excluded.\nMonetary-relief share = monetary-relief responses / all\ncomplaints in the selected scope. This is not money paid.\nVolume change = (2025 count - 2024 count) / 2024 count.\nCards and chart subtitles state which controls apply.',28,480,684,252)
block('04 / Categories and comparison cohorts','Historical product and issue definitions are preserved.\nShort issue labels map to original text in the source bundle.\nTop-eight issue and top-ten company cohorts are fixed\nwithin each product using combined 2024–25 counts.\nOther groups retain all remaining records in totals.\nCompany names are shortened for display, not merged.',732,480,680,252)
block('05 / What this dashboard cannot establish','No customer counts, transaction exposure, satisfaction\nscores or verified case-resolution dates are supplied.\nReceived-to-company dates are not resolution times.\nMonetary relief is a response category, not a dollar value.\nReported timeliness is not equivalent to satisfaction.\nDo not interpret high volumes as high complaint rates.\n2026 product changes are outside this observation window.',28,752,684,298)
block('06 / Reproducibility and useful next steps','Official source: consumerfinance.gov/data-research/\nconsumer-complaints/ and its API documentation.\nGitHub includes API queries, hashes, category mappings,\naggregation code, validation and the final workbook.\nChecks reconcile record IDs, scope and aggregate totals.\nUse patterns to prioritise deeper investigation, then seek\nexposure data and case-level evidence before acting.',732,752,680,298)
for d in boards:el(d,'simple-id',uuid='{'+str(uuid.uuid5(uuid.NAMESPACE_DNS,'complaints-board-'+d.get('name'))).upper()+'}')
windows=el(root,'windows',**{'source-height':'30'})
for i,d in enumerate(boards):
 w=el(windows,'window',**{'class':'dashboard','name':d.get('name'),'maximized':'true' if i==0 else 'false'});vp=el(w,'viewpoints')
 for n in used[d.get('name')]:el(el(vp,'viewpoint',name=n),'zoom',type='entire-view')
 el(w,'active',id='-1');el(w,'simple-id',uuid=ids[d.get('name')])
for n in names:
 w=el(windows,'window',**{'class':'worksheet','name':n,'hidden':'true'});el(w,'cards');el(el(w,'viewpoint'),'zoom',type='entire-view');el(w,'simple-id',uuid='{'+str(uuid.uuid5(uuid.NAMESPACE_DNS,'complaints-window-'+n)).upper()+'}')
el(root,'thumbnails')
sys.path.insert(0,str(P.parents[1]/'work/tableau_runtime'))
from tableauhyperapi import HyperProcess,Telemetry,Connection,CreateMode,TableDefinition,TableName,SqlType,Inserter
hyper=P/'health.hyper';td=TableDefinition(TableName('Extract','Extract'),[TableDefinition.Column(n,SqlType.text() if t=='string' else SqlType.big_int() if t=='integer' else SqlType.double()) for n,t in F.items()])
with HyperProcess(Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as hp:
 with Connection(hp.endpoint,str(hyper),CreateMode.CREATE_AND_REPLACE) as conn:
  conn.catalog.create_schema('Extract');conn.catalog.create_table(td)
  with Inserter(conn,td) as ins:ins.add_rows([[r[n] if t=='string' else int(r[n]) if t=='integer' else float(r[n]) for n,t in F.items()] for r in data]);ins.execute()
  assert conn.execute_scalar_query('SELECT COUNT(*) FROM "Extract"."Extract"')==len(data)
ex=el(ds,'extract',count='-1',enabled='true',units='records');cx=el(ex,'connection',authentication='auth-none',author_locale='en_US',**{'class':'hyper','dbname':'Data/Extracts/health.hyper','default-settings':'yes','schema':'Extract','tablename':'Extract'});el(cx,'relation',name='Extract',table='[Extract].[Extract]',type='table');emd=copy.deepcopy(md)
for rec in emd:rec.find('parent-name').text='[Extract]'
cx.append(emd)
for n in colorfields:el(ds,'column-instance',column=f'[{n}]',derivation='None',name=inst(n),pivot='key',type='nominal')
ds.remove(ex);ds.append(ex);ds.remove(dsstyle);ds.append(dsstyle)
svg='''<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="110" viewBox="0 0 1440 110"><rect width="1440" height="110" fill="#172D4B"/><g fill="none" stroke="#7CA0CF" opacity=".25"><circle cx="1095" cy="55" r="65"/><circle cx="1095" cy="55" r="48"/><path d="M990 85L1020 70L1050 77L1080 42L1110 55L1155 20" stroke-width="3"/></g><path d="M0 109H1440" stroke="#087F8C" stroke-width="2"/></svg>'''
(P/'header.svg').write_text(svg)
for q in root.findall('.//zone'):
 if q.find('button') is not None and q.find('zone-style') is not None:
  st=q.find('zone-style');q.remove(st);q.append(st)
E.indent(root);out=P/'Financial Complaints Intelligence.twbx'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('Financial Complaints Intelligence.twb',E.tostring(root,encoding='utf-8',xml_declaration=True));z.write(hyper,'Data/Extracts/health.hyper');z.write(P/'complaints.csv','complaints.csv');z.write(P/'header.svg','Image/header.svg')
(P/'calculated-fields.json').write_text(json.dumps(C,indent=2));print('Built',len(names),'worksheets and',len(boards),'dashboards:',out)
