from pathlib import Path
import requests,concurrent.futures,json,hashlib,time
p=Path('outputs/financial-complaints');(p/'raw').mkdir(exist_ok=True)
products=['Checking or savings account','Credit card','Money transfer, virtual currency, or money service']
def get(product,year):
 q={'date_received_min':f'{year}-01-01','date_received_max':f'{year}-12-31','product':product,'format':'csv','size':100}
 r=requests.get('https://www.consumerfinance.gov/data-research/consumer-complaints/search/api/v1/',params=q,timeout=180)
 for retry in range(4):
  if r.status_code!=429:break
  time.sleep(20)
  r=requests.get(r.url,timeout=180)
 r.raise_for_status();f=product.split(',')[0].replace(' ','-')+f'-{year}.csv';(p/'raw'/f).write_bytes(r.content)
 return {'product':product,'file':f,'url':r.url,'bytes':len(r.content),'sha256':hashlib.sha256(r.content).hexdigest(),'retrieved':'2026-11-22'}
results=[]
for product in products:
 for year in [2024,2025]:
  results.append(get(product,year));print(results[-1],flush=True);time.sleep(4)
(p/'sources.json').write_text(json.dumps(results,indent=2));print(results)


