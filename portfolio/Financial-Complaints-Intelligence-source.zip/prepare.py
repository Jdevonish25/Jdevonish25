from pathlib import Path
import csv,json,collections,datetime
P=Path(__file__).parent
products={'Checking or savings account':'Bank accounts','Credit card':'Credit cards','Money transfer, virtual currency, or money service':'Money services'}
rows=[];ids=set();counts={}
for source in json.loads((P/'sources.json').read_text()):
 part=list(csv.DictReader((P/'raw'/source['file']).open(encoding='utf-8-sig',newline='')))
 counts[source['file']]=len(part)
 for r in part:
  assert r['Complaint ID'] not in ids;ids.add(r['Complaint ID'])
  assert r['Product']==source['product']
  assert '2024-01-01'<=r['Date received'][:10]<='2025-12-31'
 rows.extend(part)
co=collections.Counter((products[r['Product']],r['Company']) for r in rows)
issues=collections.Counter((products[r['Product']],r['Issue']) for r in rows)
topco={p:[k[1] for k,n in co.most_common() if k[0]==p][:10] for p in products.values()}
topissue={p:[k[1] for k,n in issues.most_common() if k[0]==p][:8] for p in products.values()}
short={'Improper use of your report':'Report misuse','Other transaction problem':'Other transactions','Other service problem':'Other service','Managing, opening, or closing your mobile wallet account':'Wallet management','Trouble accessing funds in your mobile or digital wallet':'Wallet access','Unauthorized transactions or other transaction problem':'Unauth./other txn','Confusing or missing disclosures':'Disclosures','Problem with a lender or other company charging your account':'Account charges','Problem caused by your funds being low':'Insufficient funds','Problem with a purchase shown on your statement':'Purchase on statement','Problem with a credit reporting company\'s investigation into an existing problem':'Credit-report investigation','Problem with a company\'s investigation into an existing problem':'Investigation','Money was not available when promised':'Money availability','Trouble using your card':'Using your card','Problem with the payoff process at the end of the loan':'Payoff process','Problem with a transfer or withdrawal':'Transfer or withdrawal','Fraud or scam':'Fraud or scam','Unexpected or other fees':'Unexpected / other fees','Incorrect information on your report':'Report errors','Other features, terms, or problems':'Other features / terms','Problem when making payments':'Making payments','Getting a credit card':'Getting a card','Closing your account':'Closing account','Managing an account':'Managing account','Closing an account':'Closing account','Opening an account':'Opening account','Problem with a purchase or transfer':'Purchase or transfer','Confusing or misleading advertising or marketing':'Advertising / marketing','Problem with customer service':'Customer service','Problem with a charge or fee':'Charge or fee','Problem adding money':'Adding money','Problem with an overdraft':'Overdraft'}
company_short={'NAVY FEDERAL CREDIT UNION':'Navy Federal CU','Paypal Holdings, Inc':'PayPal','Early Warning Services, LLC':'Early Warning','EARLY WARNING SERVICES, LLC':'Early Warning','TRANSUNION INTERMEDIATE HOLDINGS, INC.':'TransUnion','Experian Information Solutions Inc.':'Experian','EQUIFAX, INC.':'Equifax','Bread Financial Holdings, Inc.':'Bread Financial','PayPal Holdings, Inc':'PayPal','JPMORGAN CHASE & CO.':'JPMorgan Chase','BANK OF AMERICA, NATIONAL ASSOCIATION':'Bank of America','WELLS FARGO & COMPANY':'Wells Fargo','CITIBANK, N.A.':'Citibank','CAPITAL ONE FINANCIAL CORPORATION':'Capital One','SYNCHRONY FINANCIAL':'Synchrony','AMERICAN EXPRESS COMPANY':'American Express','U.S. BANCORP':'U.S. Bancorp','PNC Bank N.A.':'PNC Bank','TRUIST FINANCIAL CORPORATION':'Truist','DISCOVER BANK':'Discover','TD BANK US HOLDING COMPANY':'TD Bank US','PAYPAL HOLDINGS INC.':'PayPal','GOLDMAN SACHS BANK USA':'Goldman Sachs Bank USA','Block, Inc.':'Block','Chime Financial Inc':'Chime Financial','Coinbase, Inc.':'Coinbase','ROBINHOOD MARKETS INC.':'Robinhood'}
agg=collections.Counter();mapping={}
for r in rows:
 product=products[r['Product']];year=int(r['Date received'][:4]);month=r['Date received'][2:7]
 company=r['Company'];rank=topco[product].index(company)+1 if company in topco[product] else 99
 company=company_short.get(company,company.title()) if rank<99 else 'Other companies'
 issue=r['Issue'] if r['Issue'] in topissue[product] else 'Other issues'
 label=short.get(issue,issue)
 mapping.setdefault(label,[])
 if issue not in mapping[label]:mapping[label].append(issue)
 response={'Closed with explanation':'Explanation','Closed with monetary relief':'Monetary relief','Closed with non-monetary relief':'Non-monetary relief','Untimely response':'Untimely response','In progress':'In progress'}.get(r['Company response to consumer'],r['Company response to consumer'])
 timely=r['Timely response?'] if r['Timely response?'] in ['Yes','No'] else 'Unknown'
 channel=r['Submitted via'] if r['Submitted via'] not in ['','None'] else 'Unknown'
 agg[(month,year,product,label,company,rank,response,timely,channel)]+=1
fields={'Month':'string','Year':'integer','Product':'string','Issue':'string','Company':'string','Company rank':'integer','Response':'string','Timely':'string','Channel':'string','Complaints':'integer'}
with (P/'complaints.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.writer(f);w.writerow(fields);w.writerows((*k,n) for k,n in sorted(agg.items()))
assert sum(agg.values())==len(rows)
metrics={p:{str(y):sum(1 for r in rows if products[r['Product']]==p and int(r['Date received'][:4])==y) for y in [2024,2025]} for p in products.values()}
known=[r for r in rows if r['Timely response?'] in ['Yes','No']]
v={'source_rows':len(rows),'aggregate_rows':len(agg),'source_counts':counts,'product_year_counts':metrics,'timely_yes':sum(r['Timely response?']=='Yes' for r in known),'timely_known':len(known),'monetary_relief':sum(r['Company response to consumer']=='Closed with monetary relief' for r in rows),'checks':['Complaint IDs unique across exports','Received-date and product scope verified','Aggregate counts reconcile to source records'],'retrieved':'2026-11-22'}
(P/'schema.json').write_text(json.dumps(fields,indent=2));(P/'validation.json').write_text(json.dumps(v,indent=2));(P/'category-mapping.json').write_text(json.dumps({'products':products,'issues':mapping,'company_aliases':company_short,'top_company_cohort':topco,'top_issue_cohort':topissue},indent=2));print(json.dumps(v,indent=2))
