from pathlib import Path
import csv,json,math
P=Path(__file__).parent;rows=list(csv.DictReader((P/'complaints.csv').open(encoding='utf-8')))
def volume(predicate):return sum(int(r['Complaints']) for r in rows if predicate(r))
v=json.loads((P/'validation.json').read_text())
assert volume(lambda r:True)==404353
assert volume(lambda r:r['Year']=='2025')==258792
assert volume(lambda r:r['Year']=='2024')==145561
assert volume(lambda r:r['Year']=='2025' and r['Product']=='Bank accounts')==84195
assert volume(lambda r:r['Year']=='2025' and r['Product']=='Money services' and r['Company']=='Block')==42569
assert sorted({r['Month'] for r in rows})==[f'{y}-{m:02}' for y in ['24','25'] for m in range(1,13)]
assert len(rows)==len({tuple(r[k] for k in r if k!='Complaints') for r in rows})
assert all(int(r['Complaints'])>0 for r in rows)
yes=volume(lambda r:r['Year']=='2025' and r['Timely']=='Yes');known=volume(lambda r:r['Year']=='2025' and r['Timely'] in ['Yes','No'])
assert math.isclose(yes/known,256810/258792)
assert math.isclose(volume(lambda r:r['Year']=='2025' and r['Response']=='Monetary relief')/258792,22326/258792)
v['dashboard_checks']=['2024/2025 totals','2025 bank-account product scope','2025 Block money-services company scope','24 chronological months','Unique aggregate grain and positive counts','Timeliness denominator','Monetary-relief denominator']
v['api_count_reconciliation']={'Checking-or-savings-account-2024.csv':52821,'Checking-or-savings-account-2025.csv':84195,'Credit-card-2024.csv':75989,'Credit-card-2025.csv':89978,'Money-transfer-2024.csv':16751,'Money-transfer-2025.csv':84619}
v['checks'].append('Six export counts independently checked against API hits.total queries')
(P/'validation.json').write_text(json.dumps(v,indent=2))
print('Validation passed:',len(rows),'aggregate rows representing',volume(lambda r:True),'complaints')
