import requests,json,time
from pathlib import Path
p=Path('outputs/financial-complaints');v=json.loads((p/'validation.json').read_text());out=[]
for s in json.loads((p/'sources.json').read_text()):
 u=s['url'].replace('format=csv&size=100','size=1');r=requests.get(u,timeout=60);r.raise_for_status();n=r.json()['hits']['total']['value'];assert n==v['source_counts'][s['file']];out.append({'file':s['file'],'api_total':n});print(s['file'],n,flush=True);time.sleep(1)
v['api_count_reconciliation']=out;v['checks'].append('All six CSV export counts reconcile to independent API total queries');(p/'validation.json').write_text(json.dumps(v,indent=2))
