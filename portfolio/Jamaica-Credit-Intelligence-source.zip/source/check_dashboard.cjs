const fs=require('fs'),vm=require('vm'),assert=require('assert');
const nodes={};const node=s=>nodes[s]??={value:s==='#window'?'36':'',innerHTML:'',textContent:'',classList:{toggle(){}}};
const data=JSON.parse(fs.readFileSync('dist/data/credit.json','utf8'));
let app=fs.readFileSync('dist/app.js','utf8').split("fetch('data/credit.json')")[0];
const context={document:{querySelector:node,querySelectorAll:()=>[],addEventListener(){}},window:{addEventListener(){}},location:{hash:''},history:{replaceState(){}},console};
vm.createContext(context);vm.runInContext(app,context);context.data=data;
vm.runInContext('DATA=data',context);
let cases=0;
for(const i of [0,1,11,12,60,114])for(const mode of ['overview','sectors','quality','guide'])for(const win of ['12','36','0']){
 node('#window').value=win;vm.runInContext(`idx=${i};view='${mode}';render()`,context);
 assert(!/NaN|Infinity|undefined/.test(node('#content').innerHTML),`Invalid visible value ${i} ${mode}`);cases++;
}
vm.runInContext("idx=114;view='overview';render()",context);
assert(node('#content').innerHTML.includes('J$1.70T'));
assert(node('#content').innerHTML.includes('2.4%'));
vm.runInContext("idx=0;view='sectors';render()",context);assert(node('#content').innerHTML.includes('12 months of history'));
vm.runInContext("idx=114;view='quality';qualityMode='pdl';render()",context);assert(node('#content').innerHTML.includes('56.6B'));
console.log(JSON.stringify({renderCases:cases,latestTotal:data.rows.at(-1).total,latestNplRatio:data.rows.at(-1).npl/data.rows.at(-1).total*100,checks:'passed'},null,2));
