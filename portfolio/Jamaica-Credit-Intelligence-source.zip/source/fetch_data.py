from pathlib import Path
import urllib.request, hashlib, json
ROOT=Path(__file__).resolve().parents[1]
SOURCES={
 'loans_by_customer.xls':'https://boj.org.jm/wp-content/uploads/2026/09/FS.DTI_.05.xls',
 'loans_by_sector.xls':'https://boj.org.jm/wp-content/uploads/2026/09/FS.DTI_.07.xls',
 'loan_quality.xlsx':'https://boj.org.jm/wp-content/uploads/2021/11/FS.DTI.00.xlsx',
 'business_size.xlsx':'https://boj.org.jm/wp-content/uploads/2021/11/FS.DTI.01.xlsx',
}
def fetch():
 (ROOT/'source/raw').mkdir(exist_ok=True)
 manifest=[]
 for name,url in SOURCES.items():
  content=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=60).read()
  (ROOT/'source/raw'/name).write_bytes(content)
  manifest.append({'file':name,'url':url,'sha256':hashlib.sha256(content).hexdigest(),'retrieved':'2026-11-21'})
  print(name,len(content))
 (ROOT/'source/source-manifest.json').write_text(json.dumps(manifest,indent=2))
if __name__=='__main__':fetch()
