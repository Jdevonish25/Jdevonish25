"""Reshape BOJ workbooks; retain stocks in JMD millions, never sum across months."""
from pathlib import Path
import pandas as pd, json, math, csv
ROOT=Path(__file__).resolve().parents[1]
raw=ROOT/'source/raw'
s=pd.read_excel(raw/'loans_by_sector.xls',sheet_name='FS.DTI.07.TOT',header=None)
q=pd.read_excel(raw/'loan_quality.xlsx',sheet_name='FS.DTI.00B',header=None)
b=pd.read_excel(raw/'business_size.xlsx',sheet_name='FS.DTI.01',header=None)
names=['Agriculture','Construction & land','Distribution','Electricity, gas & water','Entertainment','Food & beverage services','Manufacturing','Mining','Professional & other services','Tourism','Transport']
quality_names=[str(q.iloc[i,0]).strip().replace(' 1','') for i in range(12,26)]
quality_dates={x.strftime('%Y-%m-%d'):i for i,x in enumerate(q.iloc[10]) if isinstance(x,pd.Timestamp) or hasattr(x,'strftime')}
size_dates={r.iloc[0].strftime('%Y-%m-%d'):r for _,r in b.iloc[14:].iterrows() if hasattr(r.iloc[0],'strftime')}
rows=[];checks=[]
for _,r in s.iloc[11:].iterrows():
 if not hasattr(r.iloc[0],'strftime'):continue
 date=r.iloc[0].strftime('%Y-%m-%d'); col=quality_dates[date];bs=size_dates[date]
 sectors={name:float(r.iloc[i+1]) for i,name in enumerate(names)}
 npl={name:float(q.iloc[12+i,col]) for i,name in enumerate(quality_names)}
 pdl={name:float(q.iloc[27+i,col]) for i,name in enumerate(quality_names)}
 row={'date':date,'total':float(r.iloc[22]),'business':float(r.iloc[12]),'household':float(r.iloc[13]),'public':float(r.iloc[19]),'financial':float(r.iloc[20]),'overseas':float(r.iloc[21]),'sectors':sectors,'npl':float(q.iloc[11,col]),'pdl':float(q.iloc[26,col]),'nplGroups':npl,'pdlGroups':pdl,'size':{name:float(bs.iloc[i+1]) for i,name in enumerate(['Large','Medium','Small','Micro'])}}
 for field,total in [('sectors',row['business']),('nplGroups',row['npl']),('pdlGroups',row['pdl'])]:
  delta=sum(row[field].values())-total
  checks.append({'date':date,'check':field,'difference_jmd_million':round(delta,6)})
 assert all(math.isfinite(v) and v>=0 for v in [row['total'],row['npl'],row['pdl'],*sectors.values()])
 assert abs(row['total']-sum(row[k] for k in ['business','household','public','financial','overseas']))<.02
 rows.append(row)
assert len(rows)==115 and len({r['date'] for r in rows})==len(rows)
assert rows[-1]['date']=='2026-09-30'
# Published quality totals and components can contain source reconciliation differences.
# Preserve both, display source totals for headline metrics, never force reconciliation.
exceptions=[c for c in checks if abs(c['difference_jmd_million'])>.02]
manifest=json.loads((ROOT/'source/source-manifest.json').read_text())
output={'title':'Jamaica Credit Intelligence','retrieved':'2026-11-21','unit':'JMD millions','coverage':'Deposit-taking institutions: commercial banks, building societies and merchant banks','sources':manifest,'rows':rows,'validation':{'months':len(rows),'sourceReconciliationExceptions':exceptions}}
(ROOT/'dist/data/credit.json').write_text(json.dumps(output,allow_nan=False,separators=(',',':')))
with (ROOT/'dist/data/credit-monthly.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['date','series','category','value_jmd_million'])
 for r in rows:
  for k in ['total','business','household','public','financial','overseas','npl','pdl']:w.writerow([r['date'],'headline',k,r[k]])
  for k in ['sectors','nplGroups','pdlGroups','size']:
   for name,value in r[k].items():w.writerow([r['date'],k,name,value])
(ROOT/'source/validation.json').write_text(json.dumps(output['validation'],indent=2))
print(json.dumps({'months':len(rows),'first':rows[0]['date'],'latest':rows[-1], 'reconciliation_exception_count':len(exceptions)},indent=2))
