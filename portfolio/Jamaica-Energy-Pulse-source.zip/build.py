from pathlib import Path
import csv,json,copy,sys,zipfile,uuid,xml.etree.ElementTree as E
P=Path(__file__).parent;F=json.loads((P/'schema.json').read_text());data=list(csv.DictReader((P/'energy.csv').open(encoding='utf-8')))
BG='#080F1C';CARD='#101B2D';INK='#F1F5F9';MUTED='#A5B4C8';TEAL='#9865F8';BLUE='#22C7E6';CORAL='#FB8975';GOLD='#FBBF24';LINE='#26354B'
def el(p,t,text=None,**a):
 q=E.SubElement(p,t,{k.replace('_','-'):str(v) for k,v in a.items()})
 if text is not None:q.text=str(text)
 return q
root=E.Element('workbook',{'source-platform':'win','version':'18.1','source-build':'2026.3.0 (20263.26.1022.1645)'})
m=el(root,'document-format-change-manifest')
for n in ['IntuitiveSorting','IntuitiveSorting_SP2','BasicButtonObject','BasicButtonObjectTextSupport','SheetIdentifierTracking','WindowsPersistSimpleIdentifiers']:el(m,n)
root.insert(1,E.Element('repository-location',{'derived-from':'https://public.tableau.com/workbooks/JamaicaEnergyPulse_17957976011980?rev=1.0','id':'JamaicaEnergyPulse_17957976011980','path':'/workbooks','revision':'1.0'}))
datas=el(root,'datasources');params=el(datas,'datasource',name='Parameters',hasconnection='false',inline='true',version='18.1');el(params,'aliases',enabled='yes')
def parameter(n,default,values,caption=None):
 typ='string' if isinstance(default,str) else 'integer';val=json.dumps(default,ensure_ascii=False);c=el(params,'column',name=f'[{n}]',caption=caption or n,datatype=typ,role='measure',type='nominal' if typ=='string' else 'quantitative',param_domain_type='list',value=val)
 if typ!='string':c.set('default-format','n0')
 el(c,'calculation',**{'class':'tableau','formula':val});mem=el(c,'members')
 for v in values:el(mem,'member',value=json.dumps(v,ensure_ascii=False))

parameter('Year',2025,[2025,2024,2023,2022,2021],'Reporting year (2025 preliminary)')
parameter('Class','10 · Residential',['10 · Residential','20 · General service','40 · Power service','50 · Large power','60 · Street lighting','70 · Largest power'],'Customer class')
ds=el(datas,'datasource',name='health',caption='Jamaica Energy | Official annual statistics',inline='true',version='18.1')
cn=el(ds,'connection',**{'class':'federated'});nc=el(el(cn,'named-connections'),'named-connection',name='textscan.health',caption='health');el(nc,'connection',**{'class':'textscan','directory':'','filename':'energy.csv','server':'','workgroup-auth-mode':'as-is'})
rel=el(cn,'relation',name='energy.csv',table='[complaints#csv]',type='table',connection='textscan.health');cols=el(rel,'columns',header='yes',separator=',',character_set='UTF-8',locale='en_US');md=el(cn,'metadata-records')
for i,(n,t) in enumerate(F.items()):
 el(cols,'column',name=n,datatype=t,ordinal=i);rec=el(md,'metadata-record',**{'class':'column'})
 for a,b in [('remote-name',n),('remote-type',129 if t=='string' else 20 if t=='integer' else 5),('local-name',f'[{n}]'),('parent-name','[energy.csv]'),('remote-alias',n),('ordinal',i),('local-type',t),('aggregation','Count' if t=='string' else 'Sum'),('contains-null','true')]:el(rec,a,b)
el(ds,'aliases',enabled='yes')
for n,t in F.items():el(ds,'column',name=f'[{n}]',datatype=t,role='dimension' if t=='string' else 'measure',type='nominal' if t=='string' else 'quantitative')

category=ds.find("column[@name='[Category]']"); aliases=el(category,'aliases',enabled='yes')
for raw,label in {'10 · Residential':'Residential','20 · General service':'General service','40 · Power service':'Power service','50 · Large power':'Large power','60 · Street lighting':'Street lighting','70 · Largest power':'Largest power'}.items():el(aliases,'alias',key=json.dumps(raw,ensure_ascii=False),value=label)

for field in ['Sales sorted','Charge sorted','Generation sorted']:
 col=ds.find(f"column[@name='[{field}]']");a=el(col,'aliases',enabled='yes')
 for val in sorted({r[field] for r in data}):
  el(a,'alias',key=json.dumps(val,ensure_ascii=False),value=val.replace('0','',1) if val.startswith('0') else val)
C={}
def calc(n,t,f,fmt=None,dim=False):C[n]=(t,f,fmt,dim)
calc('Selected year','string',"IF [Year]=[Parameters].[Year] THEN 'Yes' ELSE 'No' END",dim=True)
calc('Selected class','string',"IF [Category]=[Parameters].[Class] THEN 'Yes' ELSE 'No' END",dim=True)
calc('Value sum','real','SUM([Value])','n#,##0.0')
calc('GWh','real','SUM([Value])/1000','n#,##0')
calc('Charge','real','SUM([Value])','n#,##0')
calc('Sales GWh','real',"SUM(IF [Category]='Reported sales' AND [Year]=[Parameters].[Year] THEN [Value] ELSE 0 END)/1000",'n#,##0.0')
calc('Average charge','real',"SUM(IF [Category]='Average charge' AND [Year]=[Parameters].[Year] THEN [Value] ELSE 0 END)",'n#,##0.00')
calc('Renewable share','real',"SUM(IF [Metric]='Generation' AND ([Category]='Hydro' OR [Category]='Wind' OR [Category]='Solar') AND [Year]=[Parameters].[Year] THEN [Value] ELSE 0 END)/SUM(IF [Category]='Net generation' AND [Year]=[Parameters].[Year] THEN [Value] ELSE 0 END)",'p0.0%')
calc('Loss share','real',"SUM(IF [Category]='System losses' AND [Year]=[Parameters].[Year] THEN [Value] ELSE 0 END)/SUM(IF [Category]='Net generation' AND [Year]=[Parameters].[Year] THEN [Value] ELSE 0 END)",'p0.0%')
calc('Annual loss share','real',"SUM(IF [Category]='System losses' THEN [Value] ELSE 0 END)/SUM(IF [Category]='Net generation' THEN [Value] ELSE 0 END)",'p0.0%')
calc('Annual charge','real',"SUM(IF [Category]='Average charge' THEN [Value] ELSE 0 END)",'n#,##0.00')
calc('Class sales','real',"SUM(IF [Metric]='Sales' THEN [Value] ELSE 0 END)/1000",'n#,##0.0')
calc('Class charge','real',"SUM(IF [Metric]='Charge' THEN [Value] ELSE 0 END)",'n#,##0.00')
calc('Series','string',"IF [Category]='Reported sales' THEN 'Sales' ELSEIF [Category]='Net generation' THEN 'Generation' ELSE 'Losses' END",dim=True)
calc('Net generation GWh','real',"SUM(IF [Category]='Net generation' AND [Year]=[Parameters].[Year] THEN [Value] ELSE 0 END)/1000",'n#,##0')

calc('Generation share','real','SUM([Value])/MAX([Annual net MWh])','p0%')
calc('Generation percent','real','SUM([Value])/MAX([Annual net MWh])*100','n#,##0')
calc('Customer share','real','SUM([Value])/MAX([Annual sales MWh])','p0.0%')
calc('Selected class charge','real',"MAX(IF [Year]=[Parameters].[Year] AND [Category]=[Parameters].[Class] THEN [Class average charge] END)",'n"J$"#,##0.00')
calc('Selected class premium','real',"[Selected class charge]/[Average charge]-1",'p+0.0%;-0.0%')
calc('Highest class charge','real',"MAX(IF [Year]=[Parameters].[Year] AND [Metric]='Charge' THEN [Value] END)",'n"J$"#,##0.00')
calc('Selected class title','string',"MAX(IF [Category]=[Parameters].[Class] THEN [Class name] END)+' | '+STR([Parameters].[Year])",dim=False)
calc('Class highlight','string',"IF [Category]=[Parameters].[Class] THEN 'Selected class' ELSE 'Other classes' END",dim=True)
calc('Selected class annual charge','real',"MAX(IF [Category]=[Parameters].[Class] THEN [Class average charge] END)",'n"J$"#,##0.00')
calc('Selected class annual sales','real',"MAX(IF [Category]=[Parameters].[Class] THEN [Class annual sales MWh] END)/1000",'n#,##0.0')
calc('Class premium','real','MAX([Class average charge])/MAX([Published charge])-1','p+0.0%;-0.0%')
calc('Annual losses GWh','real','MAX([Annual loss MWh])/1000','n#,##0.0')
calc('Annual renewable share','real','MAX([Annual renewable MWh])/MAX([Annual net MWh])','p0.0%')
for n,f in [('Sales note','Sales comparison'),('Charge note','Charge comparison'),('Renewable note','Renewable comparison'),('Loss note','Loss comparison'),('Overview finding','Overview insight'),('Cost finding','Cost insight'),('Period heading','Year label')]:
 calc(n,'string',f'MAX(IF [Year]=[Parameters].[Year] THEN [{f}] END)')
calc('Sales label','string','MAX([Bar sales label])')
calc('Mix legend','string','MAX([Legend label])')
calc('Rate label','string','MAX([Charge label])')
calc('Sales spark','real',"SUM(IF [Category]='Reported sales' THEN [Value] ELSE 0 END)/1000",'n#,##0')
calc('Charge spark','real',"MAX([Published charge])",'n"J$"#,##0')
calc('Relative residual','real','(MAX([Annual net MWh])-MAX([Annual loss MWh])-MAX([Annual sales MWh]))/MAX([Annual net MWh])','p0.0000%')
calc('Tooltip year','string',"IF COUNTD([Year])=1 THEN STR(MIN([Year])) ELSE STR([Parameters].[Year]) END")
calc('Tooltip context','string',"IF COUNTD([Category])=1 THEN MIN([Category]) ELSE 'Reported grid-system indicator' END")
calc('Tooltip class','string',"MAX(IF [Category]=[Parameters].[Class] THEN [Class name] END)")
for n,(t,f,fmt,dim) in C.items():
 c=el(ds,'column',name=f'[{n}]',datatype=t,role='dimension' if dim else 'measure',type='nominal' if t=='string' else 'quantitative')
 if fmt:c.set('default-format',fmt)
 el(c,'calculation',**{'class':'tableau','formula':f})
def ref(n,der=None):
 dim=F.get(n)=='string' or C.get(n,(None,None,None,False))[3];der=der or ('none' if dim else 'usr' if n in C else 'min')
 return f'[health].[{der}:{n}:{"nk" if F.get(n)=="string" or C.get(n,(None,))[0]=="string" else "qk"}]'
def inst(n):return ref(n).split('[health].')[1]
def pdep(p):
 dep=el(p,'datasource-dependencies',datasource='Parameters')
 for c in params.findall('column'):dep.append(copy.deepcopy(c))
works=el(root,'worksheets');names=[];dsstyle=el(ds,'style');dsmark=el(dsstyle,'style-rule',element='mark');colorfields=set()
def sheet(name,measure,kind=None,filters=None,mark='Text',rows='',cols='',series=None,path=None,labels=True,size=11,color=TEAL,label_field=None):
 names.append(name);w=el(works,'worksheet',name=name);el(el(el(w,'layout-options'),'title'),'formatted-text');t=el(w,'table');v=el(t,'view');el(el(v,'datasources'),'datasource',name='health',caption=ds.get('caption'));pdep(v);dep=el(v,'datasource-dependencies',datasource='health')
 for c in ds.findall('column'):dep.append(copy.deepcopy(c))
 for n in list(F)+list(C):
  q=inst(n);der=q[1:].split(':')[0];el(dep,'column-instance',column=f'[{n}]',derivation={'none':'None','min':'Min','usr':'User'}[der],name=q,pivot='key',type='nominal' if q.endswith(':nk]') else 'quantitative')
 for n,typ in F.items():
  if typ=='string':el(dep,'column-instance',column=f'[{n}]',derivation='Attribute',name=f'[attr:{n}:nk]',pivot='key',type='nominal')
 fil=dict(filters or {})

 for n,values in fil.items():
  g=el(el(v,'filter',**{'class':'categorical','column':ref(n)}),'groupfilter',function='union')
  for val in values:el(g,'groupfilter',function='member',level=inst(n),member=json.dumps(val,ensure_ascii=False))
 el(v,'aggregation',value='true');sty=el(t,'style')
 for element,fmts in [('worksheet',{'font-family':'Arial','font-size':'12','color':INK,'background-color':CARD,'display-field-labels':'false'}),('pane',{'background-color':CARD,'band-color':CARD,'band-size':'0'}),('cell',{'background-color':CARD,'color':INK}),('header',{'background-color':CARD,'color':MUTED,'font-size':'11','band-color':CARD,'band-size':'0'}),('axis',{'background-color':CARD,'color':MUTED,'font-size':'11'}),('gridline',{'stroke-size':'0'}),('zeroline',{'stroke-size':'1','stroke-color':LINE})]:
  s=el(sty,'style-rule',element=element)
  for a,b in fmts.items():el(s,'format',attr=a,value=b)
 for f,side in [(rows,'rows'),(cols,'cols')]:
  if f:
   axis=el(sty,'style-rule',element='axis');el(axis,'format',attr='title',field=f,scope=side,value='');el(axis,'format',attr='tick-label-format',field=f,scope=side,value='n#,##0')

 pane=el(el(t,'panes'),'pane',selection_relaxation_option='selection-relaxation-allow');el(el(pane,'view'),'breakdown',value='auto');el(pane,'mark',**{'class':mark});en=el(pane,'encodings')
 if labels or mark=='Text':el(en,'text',column=ref(label_field or measure))
 if mark=='Pie':el(en,'wedge-size',column=ref(measure))
 if path:el(en,'path',column=ref(path))
 if series:
  el(en,'color',column=ref(series))
  if series not in colorfields:
   e=el(dsmark,'encoding',attr='color',field=inst(series),type='palette')
   mapping={'Category':{'Natural gas':'#7183AE','Petroleum':'#C28C72','Hydro':BLUE,'Wind':'#57D5A5','Solar':GOLD},'Metric':{'Sales':TEAL,'Generation':BLUE},'Series':{'Sales':TEAL,'Generation':BLUE,'Losses':CORAL},'Class highlight':{'Selected class':BLUE,'Other classes':'#4A657C'}}.get(series,{})
   for val,col in mapping.items():el(el(e,'map',to=col),'bucket',json.dumps(val))
   colorfields.add(series)

 for n in ['Tooltip year','Tooltip context','Tooltip class']:el(en,'tooltip',column=ref(n))
 tip='Reporting year: <'+ref('Tooltip year')+'>\n'
 if name in ['Cost class','Cost premium','Class heading','Class card heading']:
  tip+='Customer class: <'+ref('Tooltip class')+'>\n'
 elif name in ['Generation mix','Generation legend','Generation history','Demand by class','Class charge bars','Premium by class']:
  tip+='Source category: <'+ref('Tooltip context')+'>\n'
 tip+='Displayed value: <'+ref(measure)+'>\n'
 if name in ['Generation history','Generation mix','Generation legend']:
  el(en,'tooltip',column=ref('Generation share'));el(en,'tooltip',column=ref('GWh'))
  tip+='Share of annual net generation: <'+ref('Generation share')+'>\nGeneration: <'+ref('GWh')+'> GWh\n'
 elif name=='Demand by class':
  el(en,'tooltip',column=ref('Customer share'));tip+='Share of annual reported sales: <'+ref('Customer share')+'>\nUnits: GWh (one million kWh).\n'
 elif name in ['Class charge bars','Premium by class']:
  el(en,'tooltip',column=ref('Class premium'));tip+='Premium / discount to system average: <'+ref('Class premium')+'>\nCharges are historical averages in J$/kWh, not complete bills.\n'
 elif name in ['KPI charge','Cost class','Cost highest','Charge trend']:
  tip+='Units: historical average Jamaican dollars per kWh.\nNot a current tariff quotation or complete bill.\n'
 elif name in ['KPI sales','Donut total']:
  tip+='Units: GWh = one million kilowatt-hours.\n'
 elif name in ['KPI renewables','KPI losses']:
  tip+='Share of published net generation.\nRenewables include hydro, wind and solar. Losses do not identify their causes.\n'
 tip+='2025 is preliminary. Source: METT Jamaica Energy Statistics 2025, pp.15 and 18.'
 el(el(el(pane,'customized-tooltip'),'formatted-text'),'run',tip,fontsize=11,fontcolor='#172D4B')
 if labels or mark=='Text':el(el(el(pane,'customized-label'),'formatted-text'),'run','<'+ref(label_field or measure)+'>',fontsize=size,fontname='Arial',bold='true' if size>=18 else 'false',fontcolor=INK)
 st=el(el(pane,'style'),'style-rule',element='mark')
 for a,b in {'mark-color':color,'mark-transparency':'255','size':'1.8' if mark=='Pie' else '3' if mark=='Square' else '.65','has-stroke':'false','mark-labels-show':'true' if labels or mark=='Text' else 'false'}.items():el(st,'format',attr=a,value=b)
 
 if mark=='Line':el(st,'format',attr='line-markers',value='true')
 
 if name.startswith('Spark'):
  for f in [rows,cols]:
   for typ in ['axis','header']:
    el(el(sty,'style-rule',element=typ),'format',attr='display',field=f,value='false')
 el(t,'rows',rows);el(t,'cols',cols);el(w,'simple-id',uuid='{'+str(uuid.uuid5(uuid.NAMESPACE_DNS,'health-sheet-'+name)).upper()+'}')
 return w



selected={'Selected year':['Yes']}
for n,m in [('KPI sales','Sales GWh'),('KPI charge','Average charge'),('KPI renewables','Renewable share'),('KPI losses','Loss share'),('Cost class','Selected class charge'),('Cost premium','Selected class premium'),('Cost highest','Highest class charge')]:sheet(n,m,size=30)
for n,m in [('Note sales','Sales note'),('Note charge','Charge note'),('Note renewables','Renewable note'),('Note losses','Loss note')]:sheet(n,m,size=11)
for n,m in [('Overview insight','Overview finding'),('Cost insight','Cost finding')]:sheet(n,m,size=13)
sheet('Selected period','Period heading',size=13)
sheet('Class heading','Selected class title',size=17)
sheet('Class card heading','Selected class title',size=12)
sheet('Sales trajectory','GWh',filters={'Category':['Reported sales']},mark='Bar',rows=ref('GWh'),cols=ref('Period'),size=10)
sheet('Generation mix','GWh',filters={**selected,'Metric':['Generation']},mark='Pie',series='Category',labels=False)
sheet('Generation legend','Generation share',filters={**selected,'Metric':['Generation']},mark='Text',rows=ref('Generation sorted'),label_field='Mix legend',series='Category',size=12)
sheet('Generation history','Generation percent',filters={'Metric':['Generation']},mark='Bar',rows=ref('Generation percent'),cols=ref('Period'),series='Category',labels=False)
sheet('Demand by class','GWh',filters={**selected,'Metric':['Sales']},mark='Bar',rows=ref('Sales sorted'),cols=ref('GWh'),label_field='Sales label',color=TEAL,size=11)
sheet('Loss trend','Annual loss share',mark='Line',rows=ref('Annual loss share'),cols=ref('Period'),path='Period',labels=True,color=CORAL,size=11)
sheet('Charge trend','Annual charge',mark='Line',rows=ref('Annual charge'),cols=ref('Period'),path='Period',labels=True,color=BLUE,size=11)
sheet('Class charge bars','Charge',filters={**selected,'Metric':['Charge']},mark='Bar',rows=ref('Charge sorted'),cols=ref('Charge'),label_field='Rate label',series='Class highlight',size=11)
sheet('Class sales trend','Selected class annual sales',mark='Line',rows=ref('Selected class annual sales'),cols=ref('Period'),path='Period',color=TEAL,size=11)
sheet('Class charge trend','Selected class annual charge',mark='Line',rows=ref('Selected class annual charge'),cols=ref('Period'),path='Period',color=BLUE,size=11)
sheet('Premium by class','Class premium',filters={**selected,'Metric':['Charge']},mark='Bar',rows=ref('Charge sorted'),cols=ref('Class premium'),series='Class highlight',size=11)
sheet('Donut total','Net generation GWh',size=18)
for n,m,col in [('Spark sales','Sales spark',TEAL),('Spark charge','Charge spark',BLUE),('Spark renewable','Annual renewable share','#34D399'),('Spark loss','Annual loss share',CORAL)]:sheet(n,m,mark='Line',rows=ref(m),cols=ref('Period'),path='Period',labels=False,color=col)

W=1440;H=810;boards=el(root,'dashboards');used={};current=None;base=None
board_names=['01 Energy Pulse','02 Cost and Demand','03 Data Guide']
ids={n:'{'+str(uuid.uuid5(uuid.NAMESPACE_DNS,'jamaica-energy-window-'+n)).upper()+'}' for n in board_names}
def zone(x,y,w,h,kind=None,text=None,font=12,fg=INK,bg=CARD,name=None,**a):
 q=el(base,'zone',id=len(base)+1,h=round(h/H*100000),w=round(w/W*100000),x=round(x/W*100000),y=round(y/H*100000),is_floating='true',**a)
 if kind:q.set('type-v2',kind)
 if name:q.set('name',name);used[current].append(name)
 if text is not None:el(el(q,'formatted-text'),'run',text,fontname='Arial',fontsize=font,fontcolor=fg,bold='true' if font>=16 else 'false')
 st=el(q,'zone-style')
 for a,b in {'background-color':bg,'border-style':'none','padding':'0','margin':'0'}.items():el(st,'format',attr=a,value=b)
 return q
def txt(t,x,y,w,h,font=12,fg=MUTED,bg=BG):return zone(x,y,w,h,'text',text=t,font=font,fg=fg,bg=bg)
def view(n,x,y,w,h):return zone(x,y,w,h,name=n,show_title='false')
def panel(n,x,y,w,h,title,sub):
 zone(x,y,w,h,'empty');zone(x,y,w,2,'empty',bg=LINE)
 txt(title,x+16,y+13,w-32,29,17,INK,CARD);txt(sub,x+16,y+51,w-32,28,11,MUTED,CARD)
 view(n,x+12,y+88,w-24,h-104)
def control(n,x,y,w):return zone(x,y,w,49,'paramctrl',param=f'[Parameters].[{n}]',mode='compact')
def card(n,title,note,spark,x,y,w=334,accent=TEAL):
 zone(x,y,w,114,'empty');zone(x,y,w,3,'empty',bg=accent)
 txt(title,x+14,y+10,w-28,24,11,MUTED,CARD);view(n,x+12,y+35,w-24,43)
 view(note,x+12,y+83,w-24,25)
def block(title,body,x,y,w,h,accent=TEAL):
 zone(x,y,w,h,'empty');zone(x,y,3,h,'empty',bg=accent)
 txt(title,x+18,y+15,w-36,33,17,accent,CARD)
 txt(body,x+18,y+61,w-36,h-74,13,INK,CARD)
def dash(n,section):
 global base,current
 current=n;used[n]=[];d=el(boards,'dashboard',name=n);el(d,'style');el(d,'size',minwidth=W,maxwidth=W,minheight=H,maxheight=H);el(el(d,'datasources'),'datasource',name='Parameters');pdep(d)
 base=el(el(d,'zones'),'zone',id=0,x=0,y=0,w=100000,h=100000,type_v2='layout-basic');zone(0,0,W,H,'empty',bg=BG)
 txt('JAMAICA / ENERGY INTELLIGENCE',24,12,900,19,10,TEAL)
 txt('Jamaica Energy Pulse',24,31,1000,50,28,INK)
 txt('Julian Devonish\nIndependent analytics project',1100,27,316,46,11,MUTED)
 for i,(dest,caption) in enumerate(zip(board_names,['01 / Energy overview','02 / Cost & demand','03 / Data & methodology'])):
  q=zone(24+i*469,88,453,35,'dashboard-object',bg=BG);b=el(q,'button',action=f'tabdoc:goto-sheet window-id="{ids[dest]}"',button_type='text');bs=el(b,'button-visual-state');el(bs,'caption',caption);el(bs,'button-caption-font-style',fontcolor=INK,fontname='Arial',fontsize=12);el(bs,'format',attr='background-color',value=TEAL if dest==n else CARD)
 txt(section,24,137,1392,27,12,INK)
 txt('METT Jamaica Energy Statistics 2025 | Annual 2021–2025 | 2025 preliminary | Nominal J$ | Julian Devonish · v2.0 · 27 Nov 2026',24,778,1392,23,10)

dash(board_names[0],'Electricity sales, generation and costs across Jamaica’s reported grid system.')
view('Selected period',24,173,760,36);control('Year',1080,166,336)
for i,(n,t,no,sp,c) in enumerate([('KPI sales','ELECTRICITY SOLD · GWh','Note sales','Spark sales',TEAL),('KPI charge','AVERAGE CHARGE · J$/kWh','Note charge','Spark charge',BLUE),('KPI renewables','RENEWABLE GENERATION','Note renewables','Spark renewable','#34D399'),('KPI losses','SYSTEM LOSS SHARE','Note losses','Spark loss',CORAL)]):card(n,t,no,sp,24+i*353,228,334,c)
panel('Generation history',24,360,430,318,'Energy sources over time','Share of net generation · 100% each year')
zone(470,360,480,318,'empty');txt('Electricity generation mix',486,373,448,29,17,INK,CARD);txt('Selected year · Total GWh and source shares',486,411,448,28,11,MUTED,CARD)
view('Generation mix',480,457,208,202)
zone(524,498,120,120,'bitmap',param='Image/hole.svg',is_scaled='1',is_centered='1')
view('Donut total',536,540,96,30);txt('GWh',560,574,48,18,10,INK,CARD)
view('Generation legend',696,468,244,180)
panel('Demand by class',966,360,450,318,'Sales by customer class','GWh | Share of sales · Ranked highest first')
zone(24,696,1392,62,'empty');view('Overview insight',40,707,1360,44)

dash(board_names[1],'Cost comparison / Historical average charges per kWh, not current tariffs or complete electricity bills.')
control('Year',24,166,450);control('Class',490,166,520);view('Selected period',1030,177,386,36)
card('KPI charge','SYSTEM AVERAGE · J$/kWh','Note charge','Spark charge',24,228,334,BLUE)
zone(377,228,334,114,'empty');txt('SELECTED CLASS · J$/kWh',391,238,306,24,11,MUTED,CARD);view('Cost class',389,263,310,43);view('Class card heading',391,311,306,25)
zone(730,228,334,114,'empty');txt('VS SYSTEM AVERAGE',744,238,306,24,11,MUTED,CARD);view('Cost premium',742,263,310,43);txt('Premium (+) or discount (−)',744,311,306,25,11,MUTED,CARD)
zone(1083,228,333,114,'empty');txt('HIGHEST CLASS CHARGE',1097,238,305,24,11,MUTED,CARD);view('Cost highest',1095,263,309,43);txt('Highest of six class averages',1097,311,305,25,11,MUTED,CARD)
panel('Charge trend',24,360,688,318,'Average electricity charge','Published system average · J$/kWh · All five years')
panel('Class charge bars',728,360,688,318,'Compare customer classes','J$/kWh | Premium to system average · Selected class in cyan')
zone(24,696,1392,62,'empty');view('Cost insight',40,707,1360,44)

dash(board_names[2],'Data & methodology / Official evidence, explicit calculations and transparent limitations.')
block('01 / Official source and coverage','Jamaica Energy Statistics 2025 — METT, July 2026.\nMinistry of Energy, Transport and Telecommunications.\n2021–2025 annual observations; 2025 preliminary.\nReported JPS grid system; not all off-grid generation.\nPage 15: generation, sales and losses. Page 18: charges.\nRetrieved and visually checked: 27 November 2026.',24,184,688,264)
block('02 / Definitions and comparisons','GWh = MWh / 1,000 = one million kilowatt-hours.\nRenewables = hydro + wind + solar; gas is fossil fuel.\nRenewable share = renewable MWh / net generation.\nLoss share = reported system losses / net generation.\nAverage charge: published nominal Jamaican dollars/kWh.\nYoY changes are relative; share changes use pp.\n2021 has no prior-year comparison in this dataset.',728,184,688,264,BLUE)
block('03 / Preparation and validation','Official PDF → tidy CSV → Python checks → Hyper → Tableau.\n105 unique Year × Metric × Category observations.\nNo year-only joins; repeated denominators use MAX.\nGeneration sources and sales classes match their totals.\nGeneration − losses − sales residuals, in MWh:\n2021: −5 | 2022: −2 | 2023: +385 | 2024: +2 | 2025: +283.\nSource differences retained, not assumed to be rounding.',24,466,688,292)
block('04 / Controls and limitations','Year updates cards, mix and annual class comparisons.\nHistorical generation and charge charts retain all five years.\nCustomer class updates its charge, premium and highlight.\nNo monthly or parish detail, inflation adjustment or forecast.\nCharges are historical averages, not tariffs or complete bills.\nLosses do not identify theft; associations do not prove causes.\nv1.0 and v2.0 published 27 November 2026.\nFull calculations and source links accompany the case study.',728,466,688,292,BLUE)
for d in boards:el(d,'simple-id',uuid='{'+str(uuid.uuid5(uuid.NAMESPACE_DNS,'energy-board-'+d.get('name'))).upper()+'}')
windows=el(root,'windows',**{'source-height':'30'})
for i,d in enumerate(boards):
 w=el(windows,'window',**{'class':'dashboard','name':d.get('name'),'maximized':'true' if i==0 else 'false'});vp=el(w,'viewpoints')
 for n in used[d.get('name')]:el(el(vp,'viewpoint',name=n),'zoom',type='entire-view')
 el(w,'active',id='-1');el(w,'simple-id',uuid=ids[d.get('name')])
for n in names:
 w=el(windows,'window',**{'class':'worksheet','name':n,'hidden':'true'});el(w,'cards');el(el(w,'viewpoint'),'zoom',type='entire-view');el(w,'simple-id',uuid='{'+str(uuid.uuid5(uuid.NAMESPACE_DNS,'energy-window-'+n)).upper()+'}')
el(root,'thumbnails')
sys.path.insert(0,str(P.parents[1]/'work/tableau_runtime'))
from tableauhyperapi import HyperProcess,Telemetry,Connection,CreateMode,TableDefinition,TableName,SqlType,Inserter
hyper=P/'health.hyper';td=TableDefinition(TableName('Extract','Extract'),[TableDefinition.Column(n,SqlType.text() if t=='string' else SqlType.big_int() if t=='integer' else SqlType.double()) for n,t in F.items()])
with HyperProcess(Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as hp:
 with Connection(hp.endpoint,str(hyper),CreateMode.CREATE_AND_REPLACE) as conn:
  conn.catalog.create_schema('Extract');conn.catalog.create_table(td)
  with Inserter(conn,td) as ins:ins.add_rows([[r[n] if t=='string' else int(r[n]) if t=='integer' else float(r[n]) for n,t in F.items()] for r in data]);ins.execute()
  assert conn.execute_scalar_query('SELECT COUNT(*) FROM "Extract"."Extract"')==len(data)
ex=el(ds,'extract',count='-1',enabled='true',units='records');cx=el(ex,'connection',authentication='auth-none',author_locale='en_US',**{'class':'hyper','dbname':'Data/Extracts/health.hyper','default-settings':'yes','schema':'Extract','tablename':'Extract'});el(cx,'relation',name='Extract',table='[Extract].[Extract]',type='table');emd=copy.deepcopy(md)
for rec in emd:rec.find('parent-name').text='[Extract]'
cx.append(emd)
for n in colorfields:el(ds,'column-instance',column=f'[{n}]',derivation='None',name=inst(n),pivot='key',type='nominal')
ds.remove(ex);ds.append(ex);ds.remove(dsstyle);ds.append(dsstyle)
svg='''<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="110"><rect width="1440" height="110" fill="#080F1C"/></svg>'''
(P/'header.svg').write_text(svg)
(P/'hole.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><circle cx="50" cy="50" r="50" fill="#101B2D"/></svg>')
for q in root.findall('.//zone'):
 if q.find('button') is not None and q.find('zone-style') is not None:
  st=q.find('zone-style');q.remove(st);q.append(st)

for q in root.findall('.//zone'):
 if q.get('param')=='Image/hole.svg':
  for f in list(q.findall('./zone-style/format')):
   if f.get('attr')=='background-color':q.find('zone-style').remove(f)

for w in works.findall('worksheet'):
 if w.get('name')=='Generation history':
  st=w.find('table/style');el(el(st,'style-rule',element='axis'),'format',attr='display',field=ref('Generation percent'),value='false')

for alias_node in root.findall('.//column/aliases'):
 alias_node.attrib.pop('enabled',None)

for style_node in root.findall('.//style-rule'):
 for f in list(style_node):
  if f.get('attr') in ['tick-label-format','line-markers']:style_node.remove(f)

stats=json.loads((P/'analysis.json').read_text())
sparkvalues={'Spark sales':([stats[str(y)]['Annual sales MWh'] for y in range(2021,2026)],TEAL),'Spark charge':([stats[str(y)]['Published charge'] for y in range(2021,2026)],BLUE),'Spark renewable':([stats[str(y)]['Annual renewable MWh']/stats[str(y)]['Annual net MWh'] for y in range(2021,2026)],'#34D399'),'Spark loss':([stats[str(y)]['Annual loss MWh']/stats[str(y)]['Annual net MWh'] for y in range(2021,2026)],CORAL)}
for n,(vals,color) in sparkvalues.items():
 lo,hi=min(vals),max(vals);points=' '.join(f'{4+i*26},{22-(v-lo)/(hi-lo)*18:.2f}' for i,v in enumerate(vals))
 (P/(n+'.svg')).write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="112" height="26"><rect width="112" height="26" fill="{CARD}"/><polyline points="{points}" fill="none" stroke="{color}" stroke-width="2"/></svg>')

E.indent(root);out=P/'Jamaica Energy Pulse.twbx'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('Jamaica Energy Pulse.twb',E.tostring(root,encoding='utf-8',xml_declaration=True));z.write(hyper,'Data/Extracts/health.hyper');z.write(P/'energy.csv','energy.csv');z.write(P/'header.svg','Image/header.svg');z.write(P/'hole.svg','Image/hole.svg')
with zipfile.ZipFile(out,'a',zipfile.ZIP_DEFLATED) as z:
 for n in sparkvalues:z.write(P/(n+'.svg'),'Image/'+n+'.svg')
(P/'calculated-fields.json').write_text(json.dumps(C,indent=2));print('Built',len(names),'worksheets and',len(boards),'dashboards:',out)
