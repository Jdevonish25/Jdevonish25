from pathlib import Path
import requests,hashlib,json
p=Path(__file__).parent;info=json.loads((p/'sources.json').read_text());r=requests.get(info['url']);r.raise_for_status();assert hashlib.sha256(r.content).hexdigest()==info['sha256'],'Source PDF changed: review before using';(p/'raw').mkdir(exist_ok=True);(p/'raw/METT-2025.pdf').write_bytes(r.content)
