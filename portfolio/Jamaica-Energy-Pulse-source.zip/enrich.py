"""Build analysis fields from the 105 official observations, without joining grains."""
from pathlib import Path
import csv,json,runpy
P=Path(__file__).parent
raw=runpy.run_path(str(P/'prepare.py'))
generation,sales,rates,totals=[raw[k] for k in ['generation','sales','rates','totals']]
rows=list(csv.DictReader((P/'energy.csv').open(encoding='utf-8')))
def pct(a,b):return (a/b-1)*100
def signed(x,unit='%'):return f'{x:+.1f}{unit}'
summary={}
for i,y in enumerate(range(2021,2026)):
 net=totals['Net generation'][i];sold=totals['Reported sales'][i];loss=totals['System losses'][i];charge=totals['Average charge'][i]
 renew=sum(generation[k][i] for k in ['Hydro','Wind','Solar']);rs=renew/net;ls=loss/net
 sale_delta=pct(sold,totals['Reported sales'][i-1]) if i else None
 charge_delta=pct(charge,totals['Average charge'][i-1]) if i else None
 renewable_delta=(rs-sum(generation[k][i-1] for k in ['Hydro','Wind','Solar'])/totals['Net generation'][i-1])*100 if i else None
 loss_delta=(ls-totals['System losses'][i-1]/totals['Net generation'][i-1])*100 if i else None
 label=f'{y}'+(' preliminary' if y==2025 else '')
 summary[y]={'Year label':label,'Annual net MWh':net,'Annual sales MWh':sold,'Annual loss MWh':loss,'Annual renewable MWh':renew,'Published charge':charge,
 'Sales comparison':f'{signed(sale_delta)} vs {y-1}' if i else 'Prior-year data unavailable',
 'Charge comparison':f'{signed(charge_delta)} vs {y-1}' if i else 'Prior-year data unavailable',
 'Renewable comparison':f'{renew/1000:,.1f} GWh | '+(signed(renewable_delta,' pp') if i else 'No prior year'),
 'Loss comparison':f'{loss/1000:,.1f} GWh | '+(signed(loss_delta,' pp') if i else 'No prior year'),
 'Overview insight':f'{label} | Fossil fuels: {(1-rs)*100:.1f}% | Renewables: {rs*100:.1f}% | Losses: {ls*100:.1f}% ({loss/1000:,.1f} GWh).',
 'Cost insight':f'{label} | J${charge:.2f}/kWh'+(f' ({signed(charge_delta)} vs {y-1}) | Sales: {signed(sale_delta)}. Changes are descriptive, not causal.' if i else ' | Prior-year changes unavailable; 2020 is outside this dataset.'),
 'Reconciliation':f'{y}    {net-loss-sold:+,} MWh    {(net-loss-sold)/net*100:+.4f}% of generation',
 'Sales delta':sale_delta,'Charge delta':charge_delta,'Renewable delta pp':renewable_delta,'Loss delta pp':loss_delta}
for r in rows:
 y=int(r['Year']);i=y-2021;cat=r['Category'];metric=r['Metric'];val=float(r['Value']);s=summary[y]
 for k,v in s.items():
  if k not in ['Sales delta','Charge delta','Renewable delta pp','Loss delta pp']:r[k]=v
 r['Class name']=cat.split(' · ',1)[-1] if cat in sales else cat
 r['Class annual sales MWh']=sales[cat][i] if cat in sales else 0
 r['Class average charge']=rates[cat][i] if cat in rates else 0
 r['Customer label']=r['Class name']
 r['Sales sorted']=f"{sorted(sales,key=lambda k:-sales[k][i]).index(cat)+1:02} {r['Class name']}" if cat in sales else '99 Other'
 r['Charge sorted']=f"{sorted(rates,key=lambda k:-rates[k][i]).index(cat)+1:02} {r['Class name']}" if cat in rates else '99 Other'
 r['Generation sorted']=f"{sorted(generation,key=lambda k:-generation[k][i]).index(cat)+1:02} {cat}" if cat in generation else '99 Other'
 if metric=='Sales':r['Bar sales label']=f'{val/1000:,.1f} | {val/s["Annual sales MWh"]*100:.1f}%'
 else:r['Bar sales label']=''
 if metric=='Generation':r['Legend label']=f'{val/s["Annual net MWh"]*100:.1f}%'
 else:r['Legend label']=''
 if metric=='Charge':r['Charge label']=f'J${val:.2f} | {signed(pct(val,s["Published charge"]))}'
 else:r['Charge label']=''
 # Correct source unit for total-energy records (the prototype used a mixed-unit label).
 if metric=='Total' and cat!='Average charge':r['Unit']='MWh'
numeric={'Year':'integer','SourcePage':'integer','Value':'real','Annual net MWh':'real','Annual sales MWh':'real','Annual loss MWh':'real','Annual renewable MWh':'real','Published charge':'real','Class annual sales MWh':'real','Class average charge':'real'}
with (P/'energy.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
(P/'schema.json').write_text(json.dumps({k:numeric.get(k,'string') for k in rows[0]},indent=2))
(P/'analysis.json').write_text(json.dumps(summary,indent=2))
assert len(rows)==105 and all(0<=s['Annual renewable MWh']/s['Annual net MWh']<=1 for s in summary.values())
assert summary[2021]['Sales delta'] is None and abs(summary[2025]['Charge delta']-3.5886126704)<1e-8
assert all(abs(sum(generation[k][i] for k in generation)/totals['Net generation'][i]-1)<1e-12 for i in range(5))
print('Enriched and validated 105 observations; five years and six customer classes.')
