from pathlib import Path
import csv,json,hashlib
P=Path(__file__).parent
years=range(2021,2026)
generation={
 'Petroleum':[1226317,1516217,1378864,1359354,1304545],
 'Natural gas':[2543490,2385955,2810863,2750150,2662617],
 'Hydro':[138432,119442,110284,122470,121231],
 'Wind':[263808,271820,231724,216815,219696],
 'Solar':[131908,131337,133124,142147,104925]}
sales={
 '10 · Residential':[1123328,1080875,1147708,1171284,1157303],
 '20 · General service':[545915,589456,633586,641208,626848],
 '40 · Power service':[742629,775119,811180,798457,776468],
 '50 · Large power':[343079,361261,376909,383551,362832],
 '60 · Street lighting':[49432,41455,39839,39178,38670],
 '70 · Largest power':[281811,322033,355645,328095,288123]}
rates=dict(zip(sales,[[52.04,62.92,55.14,56.95,58.35],[52.90,62.19,53.39,54.65,55.91],[42.40,51.04,43.53,44.88,46.83],[36.09,43.57,37.31,38.26,40.83],[51.98,66.13,59.32,62.54,64.09],[35.71,44.13,38.40,39.32,40.91]]))
totals={'Net generation':[4303955,4424771,4664859,4590936,4413014],
 'Reported sales':[3086194,3170199,3364867,3361773,3250244],
 'System losses':[1217766,1254574,1299607,1229161,1162487],
 'Average charge':[46.57,55.79,47.73,49.88,51.67]}
rows=[]
for metric,items,unit,page in [('Generation',generation,'MWh',15),('Sales',sales,'MWh',15),('Charge',rates,'J$/kWh',18),('Total',totals,'mixed',15)]:
 for cat,values in items.items():
  for year,value in zip(years,values):
   rows.append(dict(Year=year,Period=str(year),Metric=metric,Category=cat,Value=value,Unit='J$/kWh' if cat=='Average charge' else unit,Status='Preliminary' if year==2025 else 'Reported',SourcePage=18 if cat=='Average charge' else page))
with (P/'energy.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
(P/'schema.json').write_text(json.dumps({'Year':'integer','Period':'string','Metric':'string','Category':'string','Value':'real','Unit':'string','Status':'string','SourcePage':'integer'}))
checks=[];metrics={}
for i,y in enumerate(years):
 g=sum(v[i] for v in generation.values());s=sum(v[i] for v in sales.values());net=totals['Net generation'][i];reported=totals['Reported sales'][i];loss=totals['System losses'][i]
 # Preserve small source discrepancies rather than silently changing reported totals.
 assert abs(g-net)<=1 and abs(s-reported)<=1 and net-loss-reported=={2021:-5,2022:-2,2023:385,2024:2,2025:283}[y]
 renewable=sum(generation[k][i] for k in ['Hydro','Wind','Solar'])
 metrics[y]={'net_mwh':net,'sales_mwh':reported,'loss_mwh':loss,'renewable_mwh':renewable,'renewable_share':renewable/net,'loss_share':loss/net,'average_charge_jmd_kwh':totals['Average charge'][i],'generation_component_residual_mwh':net-g,'sales_component_residual_mwh':reported-s,'energy_balance_residual_mwh':net-loss-reported}
 checks.append({'year':y,**metrics[y]})
assert len(rows)==105 and len({(r['Year'],r['Metric'],r['Category']) for r in rows})==105
(P/'validation.json').write_text(json.dumps({'unique_rows':len(rows),'checks':checks},indent=2));(P/'metrics.json').write_text(json.dumps(metrics,indent=2))
(P/'sources.json').write_text(json.dumps({'retrieved':'2026-11-27','publisher':'Ministry of Energy, Transport and Telecommunications','title':'Jamaica Energy Statistics 2025','published':'July 2026','url':'https://www.mett.gov.jm/wp-content/uploads/2021/07/JAMAICA-ENERGY-STATISTICS-2025.pdf','pages':[15,18],'sha256':hashlib.sha256((P/'raw/METT-2025.pdf').read_bytes()).hexdigest(),'scope':'JPS electricity statistics sourced from JPS and independent power producers; not all off-grid electricity','status':'2025 preliminary','transcription':'Source table values transcribed and visually checked against the PDF. No imputed years or synthetic values.'},indent=2))
print(json.dumps(checks,indent=2))

