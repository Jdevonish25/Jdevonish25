from pathlib import Path
import csv,json,zipfile,xml.etree.ElementTree as E
P=Path(__file__).parent
rows=list(csv.DictReader((P/'energy.csv').open(encoding='utf-8')))
summary=json.loads((P/'analysis.json').read_text())
checks=[]
assert len(rows)==105 and len({(r['Year'],r['Metric'],r['Category']) for r in rows})==105
for y in range(2021,2026):
 yr=[r for r in rows if int(r['Year'])==y];s=summary[str(y)]
 assert len(yr)==21 and {r['Status'] for r in yr}==({'Preliminary'} if y==2025 else {'Reported'})
 for metric,total in [('Generation','Annual net MWh'),('Sales','Annual sales MWh')]:
  assert sum(float(r['Value']) for r in yr if r['Metric']==metric)==s[total]
 assert all(float(r['Value'])>0 for r in yr)
 for cat in {r['Category'] for r in yr if r['Metric']=='Charge'}:
  r=next(r for r in yr if r['Category']==cat and r['Metric']=='Charge')
  actual=float(r['Value'])/s['Published charge']-1
  assert abs(actual-(float(r['Class average charge'])/float(r['Published charge'])-1))<1e-12
  checks.append({'year':y,'class':cat,'charge':float(r['Value']),'system_average':s['Published charge'],'premium':actual})
assert len(checks)==30
with zipfile.ZipFile(P/'Jamaica Energy Pulse.twbx') as z:
 assert z.testzip() is None
 root=E.fromstring(z.read('Jamaica Energy Pulse.twb'))
 for d in root.findall('./dashboards/dashboard'):
  assert d.find('size').get('maxwidth')=='1440' and d.find('size').get('maxheight')=='810'
  names=[q.get('name') for q in d.findall('.//zone') if q.get('name')]
  assert len(names)==len(set(names))
  for q in d.findall('.//zone'):
   assert int(q.get('x'))>=0 and int(q.get('y'))>=0
   assert int(q.get('x'))+int(q.get('w'))<=100001 and int(q.get('y'))+int(q.get('h'))<=100001
 assert not any(x.get('attr') in ['tick-label-format','line-markers'] for x in root.findall('.//format'))
result={'source_observations':105,'unique_grain':'Year × Metric × Category','years_checked':5,'class_year_combinations_checked':30,'fixed_dashboard_size':'1440 × 810','dashboards':3,'comparison_checks':checks,'first_year_prior_comparison':summary['2021']['Sales comparison'],'source_residuals_preserved':True}
(P/'quality-checks.json').write_text(json.dumps(result,indent=2))
print('PASS: all 30 class/year calculations, five annual totals, ZIP/XML integrity and all page bounds.')
