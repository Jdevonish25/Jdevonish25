# Reproducing Jamaica Health Pulse

Python 3.13; dependencies: requests, pymupdf, tableauhyperapi. Download both official PDFs from sources.json into sources/population-health.pdf and sources/lifestyle-survey.pdf before running prepare.py. In build.py, replace the local work/tableau_runtime import path with your installed tableauhyperapi package if needed. Run prepare.py, then build.py. This package redistributes curated numeric facts and original project code, not full third-party reports. Read the case study for definitions and limits.
