from pathlib import Path
import csv,json,copy,sys,zipfile,uuid,xml.etree.ElementTree as E
P=Path(__file__).parent;F=json.loads((P/'schema.json').read_text());data=list(csv.DictReader((P/'health.csv').open(encoding='utf-8')))
BG='#F2F6F6';CARD='#FFFFFF';INK='#17343E';MUTED='#526B75';TEAL='#087F80';BLUE='#477CB6';CORAL='#CE705F';GOLD='#AC7C33';LINE='#D9E5E6'
def el(p,t,text=None,**a):
 q=E.SubElement(p,t,{k.replace('_','-'):str(v) for k,v in a.items()})
 if text is not None:q.text=str(text)
 return q
root=E.Element('workbook',{'source-platform':'win','version':'18.1','source-build':'2026.3.0 (20263.26.1022.1645)'})
m=el(root,'document-format-change-manifest')
for n in ['IntuitiveSorting','IntuitiveSorting_SP2','BasicButtonObject','BasicButtonObjectTextSupport','SheetIdentifierTracking','WindowsPersistSimpleIdentifiers']:el(m,n)
datas=el(root,'datasources');params=el(datas,'datasource',name='Parameters',hasconnection='false',inline='true',version='18.1');el(params,'aliases',enabled='yes')
def parameter(n,default,values,caption=None):
 typ='string' if isinstance(default,str) else 'integer';val=json.dumps(default);c=el(params,'column',name=f'[{n}]',caption=caption or n,datatype=typ,role='measure',type='nominal' if typ=='string' else 'quantitative',param_domain_type='list',value=val)
 if typ!='string':c.set('default-format','n0')
 el(c,'calculation',**{'class':'tableau','formula':val});mem=el(c,'members')
 for v in values:el(mem,'member',value=json.dumps(v))
parameter('Sex','Total',['Total','Male','Female'],'Population group · published sex categories')
parameter('Cause','Diabetes',['Diabetes','Cerebrovascular disease','Hypertensive disease','Ischaemic heart disease','Respiratory disease'],'Mortality cause')
parameter('Start year',1996,[1996,2000,2005,2010,2015,2020],'Trend start year')
parameter('End year',2023,[2020,2021,2022,2023],'Trend end year')
parameter('Health measure','Hypertension',['Diabetes','Hypertension','High cholesterol','Chronic kidney disease','Overweight / obesity'])
parameter('Survey group','Total',['Total','Male','Female','15-24','25-34','35-44','45-54','55-64','65-74','75+'],'Survey comparison group · ages 15+')
ds=el(datas,'datasource',name='health',caption='Jamaica Health Pulse | official historical population evidence',inline='true',version='18.1')
cn=el(ds,'connection',**{'class':'federated'});nc=el(el(cn,'named-connections'),'named-connection',name='textscan.health',caption='health');el(nc,'connection',**{'class':'textscan','directory':'','filename':'health.csv','server':'','workgroup-auth-mode':'as-is'})
rel=el(cn,'relation',name='health.csv',table='[health#csv]',type='table',connection='textscan.health');cols=el(rel,'columns',header='yes',separator=',',character_set='UTF-8',locale='en_US');md=el(cn,'metadata-records')
for i,(n,t) in enumerate(F.items()):
 el(cols,'column',name=n,datatype=t,ordinal=i);rec=el(md,'metadata-record',**{'class':'column'})
 for a,b in [('remote-name',n),('remote-type',129 if t=='string' else 20 if t=='integer' else 5),('local-name',f'[{n}]'),('parent-name','[health.csv]'),('remote-alias',n),('ordinal',i),('local-type',t),('aggregation','Count' if t=='string' else 'Sum'),('contains-null','true')]:el(rec,a,b)
el(ds,'aliases',enabled='yes')
for n,t in F.items():el(ds,'column',name=f'[{n}]',datatype=t,role='dimension' if t=='string' else 'measure',type='nominal' if t=='string' else 'quantitative')
aliases=el(ds.find("column[@name='[Measure]']"),'aliases')
for original,short in {'Cerebrovascular disease':'Cerebrovascular','Hypertensive disease':'Hypertensive','Ischaemic heart disease':'Ischaemic heart','Respiratory disease':'Respiratory','Chronic kidney disease':'Chronic kidney','Overweight / obesity':'Excess weight'}.items():el(aliases,'alias',key=json.dumps(original),value=short)
C={}
def calc(n,t,f,fmt=None,dim=False):C[n]=(t,f,fmt,dim)
calc('Sex scope','string',"IF [Sex]=[Parameters].[Sex] THEN 'Yes' ELSE 'No' END",dim=True)
calc('Cause scope','string',"IF [Measure]=[Parameters].[Cause] THEN 'Yes' ELSE 'No' END",dim=True)
calc('Measure scope','string',"IF [Measure]=[Parameters].[Health measure] THEN 'Yes' ELSE 'No' END",dim=True)
calc('Group scope','string',"IF [Group]=[Parameters].[Survey group] THEN 'Yes' ELSE 'No' END",dim=True)
calc('Period scope','string',"IF [Year]>=[Parameters].[Start year] AND [Year]<=[Parameters].[End year] THEN 'Yes' ELSE 'No' END",dim=True)
calc('Latest scope','string',"IF [Year]={FIXED [Record Type],[Measure],[Group]:MAX([Year])} THEN 'Yes' ELSE 'No' END",dim=True)
calc('Value label','real','MIN([Value])','n0.0')
calc('Percent label','real','MIN([Value])/100','p0.0%')
calc('Count label','integer','MIN([Value])','n#,##0')
calc('Year axis','integer','MIN([Year])','n0')
calc('Age order','integer','MIN([Group Order])','n0')
calc('Rate and year','string',"STR(INT(MIN([Value])))+'.'+STR(INT(ROUND((MIN([Value])-INT(MIN([Value])))*10,0)))+' | '+STR(MIN([Year]))")
calc('Survey gap','real',"MAX(IF [Method]='Measured' THEN [Value] END)-MAX(IF [Method]='Self-reported' THEN [Value] END)",'n0.0" pp"')
calc('End rate','real',"MAX(IF [Year]=[Parameters].[End year] THEN [Value] END)",'n0.0')
calc('Start rate','real',"MAX(IF [Year]=[Parameters].[Start year] THEN [Value] END)",'n0.0')
calc('Rate change','real',"(MAX(IF [Year]=[Parameters].[End year] THEN [Value] END)-MAX(IF [Year]=[Parameters].[Start year] THEN [Value] END))/MAX(IF [Year]=[Parameters].[Start year] THEN [Value] END)",'p0.0%')
calc('Intensity band','string',"IF [Value]<20 THEN 'Below 20' ELSEIF [Value]<40 THEN '20 to below 40' ELSEIF [Value]<60 THEN '40 to below 60' ELSEIF [Value]<80 THEN '60 to below 80' ELSE '80 or more' END",dim=True)
calc('Mortality context','string',"[Parameters].[Cause]+' | '+[Parameters].[Sex]+' | '+STR([Parameters].[Start year])+' to '+STR([Parameters].[End year])",dim=True)
calc('Survey context','string',"[Parameters].[Health measure]+' | JHLS III 2016-17 | Published December 2024'",dim=True)
calc('Comparison context','string',"[Parameters].[Survey group]+' | Five health measures | JHLS III 2016-17'",dim=True)
for n,(t,f,fmt,dim) in C.items():
 c=el(ds,'column',name=f'[{n}]',datatype=t,role='dimension' if dim else 'measure',type='nominal' if t=='string' else 'quantitative')
 if fmt:c.set('default-format',fmt)
 el(c,'calculation',**{'class':'tableau','formula':f})
def ref(n,der=None):
 dim=F.get(n)=='string' or C.get(n,(None,None,None,False))[3];der=der or ('none' if dim else 'usr' if n in C else 'min')
 return f'[health].[{der}:{n}:{"nk" if F.get(n)=="string" or C.get(n,(None,))[0]=="string" else "qk"}]'
def inst(n):return ref(n).split('[health].')[1]
def pdep(p):
 dep=el(p,'datasource-dependencies',datasource='Parameters')
 for c in params.findall('column'):dep.append(copy.deepcopy(c))
actions=el(root,'actions')
for i,d in enumerate(['01 National Brief','02 Mortality Trends','03 Survey Explorer','04 Measurement Matters']):
 a=el(actions,'action',caption='Open official source PDF at this page',name=f'[Source{i}]');el(a,'source',dashboard=d,type='sheet');el(a,'link',caption='',expression='<[Source URL]>')
el(el(actions,'datasources'),'datasource',name='health',caption=ds.get('caption'));dep=el(actions,'datasource-dependencies',datasource='health');dep.append(copy.deepcopy(ds.find("column[@name='[Source URL]']")))
works=el(root,'worksheets');names=[];dsstyle=el(ds,'style');dsmark=el(dsstyle,'style-rule',element='mark');colorfields=set()
def sheet(name,measure,kind=None,filters=None,mark='Text',rows='',cols='',series=None,path=None,labels=True,size=11,color=TEAL,label_field=None):
 names.append(name);w=el(works,'worksheet',name=name);el(el(el(w,'layout-options'),'title'),'formatted-text');t=el(w,'table');v=el(t,'view');el(el(v,'datasources'),'datasource',name='health',caption=ds.get('caption'));pdep(v);dep=el(v,'datasource-dependencies',datasource='health')
 for c in ds.findall('column'):dep.append(copy.deepcopy(c))
 for n in list(F)+list(C):
  q=inst(n);der=q[1:].split(':')[0];el(dep,'column-instance',column=f'[{n}]',derivation={'none':'None','min':'Min','usr':'User'}[der],name=q,pivot='key',type='nominal' if q.endswith(':nk]') else 'quantitative')
 for n,typ in F.items():
  if typ=='string':el(dep,'column-instance',column=f'[{n}]',derivation='Attribute',name=f'[attr:{n}:nk]',pivot='key',type='nominal')
 fil=dict(filters or {})
 if kind:fil['Record Type']=[kind]
 for n,values in fil.items():
  g=el(el(v,'filter',**{'class':'categorical','column':ref(n)}),'groupfilter',function='union')
  for val in values:el(g,'groupfilter',function='member',level=inst(n),member=json.dumps(val))
 el(v,'aggregation',value='true');sty=el(t,'style')
 for element,fmts in [('worksheet',{'font-family':'Tableau Book','font-size':'11','color':INK,'background-color':CARD,'display-field-labels':'false'}),('pane',{'background-color':CARD,'band-color':CARD,'band-size':'0'}),('cell',{'background-color':CARD,'color':INK}),('header',{'background-color':CARD,'color':MUTED,'font-size':'10','band-color':CARD,'band-size':'0'}),('axis',{'background-color':CARD,'color':MUTED,'font-size':'10'}),('gridline',{'stroke-size':'0'}),('zeroline',{'stroke-size':'1','stroke-color':LINE})]:
  s=el(sty,'style-rule',element=element)
  for a,b in fmts.items():el(s,'format',attr=a,value=b)
 for f,side in [(rows,'rows'),(cols,'cols')]:
  if f:el(el(sty,'style-rule',element='axis'),'format',attr='title',field=f,scope=side,value='')
 if name=='Sex trends':el(el(sty,'style-rule',element='axis'),'encoding',attr='space',**{'class':'0','domain-expand':'false','field':ref('Year axis'),'field-type':'quantitative','scope':'cols','type':'space'})
 pane=el(el(t,'panes'),'pane',selection_relaxation_option='selection-relaxation-allow');el(el(pane,'view'),'breakdown',value='auto');el(pane,'mark',**{'class':mark});en=el(pane,'encodings')
 if labels or mark=='Text':el(en,'text',column=ref(label_field or measure))
 if path:el(en,'path',column=ref(path))
 if series:
  el(en,'color',column=ref(series))
  if series not in colorfields:
   e=el(dsmark,'encoding',attr='color',field=inst(series),type='palette')
   mapping={'Sex':{'Total':INK,'Male':BLUE,'Female':CORAL},'Method':{'Measured':TEAL,'Self-reported':CORAL},'Intensity band':{'Below 20':'#EDF6F4','20 to below 40':'#D2ECE7','40 to below 60':'#A9DCD3','60 to below 80':'#81CFC4','80 or more':'#58BCAE'}}[series]
   for val,col in mapping.items():el(el(e,'map',to=col),'bucket',json.dumps(val))
   colorfields.add(series)
 for n in ['Measure','Group','Period','Method','Unit','Source URL','Note']:el(en,'tooltip',column=f'[health].[attr:{n}:nk]')
 for n in ['Value label']:el(en,'tooltip',column=ref(n))
 tip='<[health].[attr:Measure:nk]> | <[health].[attr:Group:nk]>\nPeriod: <[health].[attr:Period:nk]>\nValue: <'+ref('Value label')+'> <[health].[attr:Unit:nk]>\nMethod: <[health].[attr:Method:nk]>\n<[health].[attr:Note:nk]>\nSource: <[health].[attr:Source URL:nk]>\nRetrieved 22 Nov 2026. Historical population evidence; not individual medical advice.'
 if mark=='Text':tip='Displayed result: <'+ref(measure)+'>\nRead the card title and date for the measure and population.\nBlank means no observation at the selected endpoint.\nUse the detailed charts and Data Guide for source definitions.'
 el(el(el(pane,'customized-tooltip'),'formatted-text'),'run',tip,fontsize=10,fontcolor=INK)
 if labels or mark=='Text':el(el(el(pane,'customized-label'),'formatted-text'),'run','<'+ref(label_field or measure)+'>',fontsize=size,fontname='Tableau Semibold' if size>=18 else 'Tableau Book',fontcolor=INK)
 st=el(el(pane,'style'),'style-rule',element='mark')
 for a,b in {'mark-color':color,'mark-transparency':'255','size':'3' if mark=='Square' else '.65','has-stroke':'false','mark-labels-show':'true' if labels or mark=='Text' else 'false'}.items():el(st,'format',attr=a,value=b)
 el(t,'rows',rows);el(t,'cols',cols);el(w,'simple-id',uuid='{'+str(uuid.uuid5(uuid.NAMESPACE_DNS,'health-sheet-'+name)).upper()+'}')
 return w
sex={'Sex scope':['Yes']};surveysex={**sex,'Group Type':['Sex'],'Method':['Measured']}
sheet('NCD share','Percent label','Share',{**sex,'Latest scope':['Yes']},size=30)
sheet('NCD deaths','Count label','Count',sex,size=30)
sheet('Hypertension KPI','Percent label','Survey',{**surveysex,'Measure':['Hypertension']},size=30)
sheet('Weight KPI','Percent label','Survey',{**surveysex,'Measure':['Overweight / obesity']},size=30)
sheet('Latest mortality','Value label','Mortality',{**sex,'Latest scope':['Yes']},mark='Bar',rows=ref('Measure'),cols=ref('Value label'),label_field='Rate and year',size=11)
sheet('Survey burden','Percent label','Survey',surveysex,mark='Bar',rows=ref('Measure'),cols=ref('Percent label'),size=12,color=BLUE)
period={'Period scope':['Yes']};mortsel={**sex,**period,'Cause scope':['Yes']}
for n,m in [('End rate KPI','End rate'),('Start rate KPI','Start rate'),('Change KPI','Rate change')]:sheet(n,m,'Mortality',mortsel,size=29)
sheet('Mortality context','Mortality context',size=12)
sheet('Sex trends','Value label','Mortality',{**period,'Cause scope':['Yes']},mark='Line',rows=ref('Value label'),cols=ref('Year axis'),series='Sex',path='Year Key',labels=False)
sheet('Mortality heatmap','Value label','Mortality',{**sex,**period},mark='Square',rows=ref('Measure'),cols=ref('Year Key'),series='Intensity band',size=8)
survsel={'Measure scope':['Yes'],'Group Type':['Sex'],'Sex scope':['Yes']}
sheet('Measured KPI','Percent label','Survey',{**survsel,'Method':['Measured']},size=29)
sheet('Reported KPI','Percent label','Survey',{**survsel,'Method':['Self-reported']},size=29)
sheet('Gap KPI','Survey gap','Survey',survsel,size=29)
sheet('Survey context','Survey context',size=12)
sheet('Age profile','Percent label','Survey',{'Measure scope':['Yes'],'Group Type':['Age']},mark='Line',rows=ref('Percent label'),cols=ref('Group'),series='Method',path='Group',size=10,labels=False)
sheet('Sex profile','Percent label','Survey',{'Measure scope':['Yes'],'Group':['Male','Female']},mark='Line',rows=ref('Group'),cols=ref('Percent label'),series='Method',path='Method',size=10)
sheet('Age heatmap','Percent label','Survey',{'Group Type':['Age'],'Method':['Measured']},mark='Square',rows=ref('Measure'),cols=ref('Group'),series='Intensity band',size=11)
gapfil={'Group scope':['Yes']}
sheet('Comparison context','Comparison context',size=12)
sheet('Method comparison','Percent label','Survey',gapfil,mark='Line',rows=ref('Measure'),cols=ref('Percent label'),series='Method',path='Method',size=11)
sheet('Gap comparison','Survey gap','Survey',gapfil,mark='Bar',rows=ref('Measure'),cols=ref('Survey gap'),size=11,color=CORAL)
# Group-specific cards on Measurement Matters use their own worksheets.
for n,m,method in [('Group measured','Percent label','Measured'),('Group reported','Percent label','Self-reported'),('Group gap','Survey gap',None)]:
 fil={**gapfil,'Measure scope':['Yes']}
 if method:fil['Method']=[method]
 sheet(n,m,'Survey',fil,size=29)

W=1440;H=1120;boards=el(root,'dashboards');used={};current=None;base=None
board_names=['01 National Brief','02 Mortality Trends','03 Survey Explorer','04 Measurement Matters','05 Data Guide']
ids={n:'{'+str(uuid.uuid5(uuid.NAMESPACE_DNS,'jamaica-health-pulse-window-'+n)).upper()+'}' for n in board_names}
def zone(x,y,w,h,kind=None,text=None,font=11,fg=INK,bg=CARD,name=None,**a):
 q=el(base,'zone',id=len(base)+1,h=round(h/H*100000),w=round(w/W*100000),x=round(x/W*100000),y=round(y/H*100000),is_floating='true',**a)
 if kind:q.set('type-v2',kind)
 if name:q.set('name',name);used[current].append(name)
 if text is not None:el(el(q,'formatted-text'),'run',text,fontname='Tableau Semibold' if font>=14 else 'Tableau Book',fontsize=font,fontcolor=fg)
 st=el(q,'zone-style')
 for attr,val in {'background-color':bg,'border-style':'none','padding':'0','margin':'0'}.items():el(st,'format',attr=attr,value=val)
 return q
def txt(s,x,y,w,h,font=11,fg=MUTED,bg=BG):return zone(x,y,w,h,'text',text=s,font=font,fg=fg,bg=bg)
def control(n,x,y,w=334,h=61):return zone(x,y,w,h,'paramctrl',param=f'[Parameters].[{n}]',mode='compact',bg=CARD)
def dash(n,title,sub):
 global base,current
 current=n;used[n]=[];d=el(boards,'dashboard',name=n);el(d,'style');el(d,'size',minwidth=W,maxwidth=W,minheight=H,maxheight=H);el(el(d,'datasources'),'datasource',name='Parameters');pdep(d)
 base=el(el(d,'zones'),'zone',id=0,x=0,y=0,w=100000,h=100000,type_v2='layout-basic');zone(0,0,W,H,'empty',bg=BG)
 zone(0,0,W,110,'bitmap',param='Image/header.svg',is_scaled='1',is_centered='1',bg=INK)
 txt(title,28,27,1140,55,28,'#FFFFFF',INK);txt('JULIAN DEVONISH',1210,27,205,24,10,'#A9DCD3',INK);txt('JAMAICA HEALTH PULSE',1170,66,245,22,9,'#D2ECE7',INK)
 for i,(dest,caption) in enumerate(zip(board_names,['01 National brief','02 Mortality trends','03 Survey explorer','04 Measurement matters','05 Data & guide'])):
  q=zone(28+i*279,120,267,31,'dashboard-object',bg=BG);b=el(q,'button',action=f'tabdoc:goto-sheet window-id="{ids[dest]}"',button_type='text');s=el(b,'button-visual-state');el(s,'caption',caption);el(s,'button-caption-font-style',fontcolor='#FFFFFF' if n==dest else INK,fontname='Tableau Semibold',fontsize=10);el(s,'format',attr='background-color',value=TEAL if n==dest else '#E0EAEA')
 txt(sub,28,162,1384,25,10)
 txt('OFFICIAL JAMAICAN SOURCES · Mortality: 1996-2023 · Survey: 2016-17 · Retrieved 22 Nov 2026 · Historical population analysis, not individual medical advice',28,1080,1384,25,9)
def panel(sheetname,x,y,w,h,title,sub):
 zone(x,y,w,h,'empty');zone(x,y,4,h,'empty',bg=LINE);txt(title,x+17,y+13,w-34,32,16,INK,CARD);txt(sub,x+17,y+53,w-34,29,10,MUTED,CARD);zone(x+10,y+88,w-20,h-98,name=sheetname,show_title='false')
def card(n,title,sub,x,y,w=334,color=TEAL):
 zone(x,y,w,119,'empty');zone(x,y,w,3,'empty',bg=color);txt(title,x+13,y+12,w-26,27,11,MUTED,CARD);zone(x+8,y+42,w-16,49,name=n,show_title='false');txt(sub,x+13,y+94,w-26,22,9,MUTED,CARD)
def block(title,body,x,y,w,h,accent=TEAL):
 zone(x,y,w,h,'empty');txt(title,x+18,y+17,w-36,33,16,accent,CARD);txt(body,x+18,y+66,w-36,h-77,11,MUTED,CARD)

dash(board_names[0],'Chronic disease. A clearer national picture.','Two evidence streams: registered mortality and a population survey. Observation years stay visible; the figures describe different populations and measures.')
control('Sex',28,198,450)
txt('Mortality overview: 2023, except respiratory disease (2022).\nSurvey findings: September 2016-March 2017; ages 15+.',504,202,908,54,11,TEAL)
for i,args in enumerate([('NCD share','Share of all deaths','2023 · all NCD causes',TEAL),('NCD deaths','Deaths attributed to NCDs','2023 · reported count',INK),('Hypertension KPI','Measured hypertension','2016-17 survey · ages 15+',BLUE),('Weight KPI','Measured overweight / obesity','2016-17 survey · ages 15+',CORAL)]):
 n,t,s,c=args;card(n,t,s,28+i*350,284,color=c)
panel('Latest mortality',28,425,684,347,'Mortality across five selected causes','Age-standardised deaths / 100,000 · Labels show value and year')
panel('Survey burden',732,425,680,347,'How common were these health measures?','Measured prevalence · % of selected sex group, ages 15+ · 2016-17')
block('READ THE TWO PANELS DIFFERENTLY','Mortality rates use a standard age structure for comparison.\nThey are not counts or the probability that a person will die.\nSurvey percentages describe people with a measured condition;\nconditions overlap, so these bars must not be added together.\nThe NCD share above covers all NCD causes, not only these five.',28,794,684,256)
block('WHERE THE ANALYSIS LEADS','Explore changes over time and differences between groups.\nThen compare self-reported and measured prevalence to ask\nbetter questions about measurement and health awareness.\nThe dashboard supports investigation; it does not establish\ncauses, treatment effects or individual medical risk.',732,794,680,256)

dash(board_names[1],'Follow the trend. Keep the denominator clear.','Age-standardised mortality rates use the WHO World Standard Population. Compare the same cause, group and period; no missing values are filled.')
for i,n in enumerate(['Sex','Cause','Start year','End year']):control(n,28+i*350,198)
for i,(n,t,s,c) in enumerate([('Start rate KPI','Rate at selected start','Age-standardised deaths / 100,000',BLUE),('End rate KPI','Rate at selected end','Age-standardised deaths / 100,000',TEAL),('Change KPI','Relative change in rate','End versus start · descriptive change',CORAL)]):card(n,t,s,28+i*350,282,color=c)
zone(1078,282,334,119,'empty');txt('MISSING IS NOT ZERO',1092,297,306,27,12,CORAL,CARD);txt('Respiratory rates end in 2022.\nNo value is supplied for 2023.',1092,338,306,49,10,MUTED,CARD)
zone(28,410,1384,30,name='Mortality context',show_title='false',bg=BG)
panel('Sex trends',28,451,1384,291,'One cause, three published sex categories','Total: navy · Male: blue · Female: coral · Y: deaths / 100,000 · X: year')
panel('Mortality heatmap',28,764,1384,277,'Five causes across the selected period','Selected sex group · Intensity: <20 | 20-<40 | 40-<60 | 60-<80 | 80+ deaths / 100,000')

dash(board_names[2],'Different groups. Different health profiles.','JHLS III observations: 2016-17, ages 15+. Age estimates combine sexes; selecting Male or Female affects the cards, not the age-only charts.')
control('Health measure',28,198,684);control('Sex',732,198,680)
for i,(n,t,s,c) in enumerate([('Measured KPI','Measured prevalence','Selected health measure and sex',TEAL),('Reported KPI','Self-reported prevalence','Selected health measure and sex',CORAL),('Gap KPI','Measured minus self-reported','Percentage-point difference',GOLD)]):card(n,t,s,28+i*350,282,color=c)
txt('Teal: measured\nCoral: self-reported',1091,310,308,65,12,TEAL)
zone(28,410,1384,30,name='Survey context',show_title='false',bg=BG)
panel('Age profile',28,451,900,276,'Prevalence across age groups','Selected health measure · All sexes · Both methods shown as published')
panel('Sex profile',948,451,464,276,'Male and female estimates','Selected measure · % · Teal measured / coral reported')
panel('Age heatmap',28,749,1384,292,'All five measures, measured prevalence by age','% in each age group · <20 | 20-<40 | 40-<60 | 60-<80 | 80+ · No significance tests inferred')

dash(board_names[3],'Measurement changes the story you can tell.','Two published prevalence estimates, not a linked diagnosis or treatment cascade. Their difference is shown in percentage points, not a count of undiagnosed people.')
control('Survey group',28,198,684);control('Health measure',732,198,680)
for i,(n,t,s,c) in enumerate([('Group measured','Measured prevalence','Selected measure and comparison group',TEAL),('Group reported','Self-reported prevalence','Selected measure and comparison group',CORAL),('Group gap','Difference in prevalence','Measured minus self-reported · pp',GOLD)]):card(n,t,s,28+i*350,282,color=c)
txt('Aggregate estimates only.\nDifference is not confirmed\nunawareness or diagnosis.',1091,306,308,75,11,CORAL)
zone(28,410,1384,30,name='Comparison context',show_title='false',bg=BG)
panel('Method comparison',28,451,820,324,'Compare the two reported methods','All five measures · Teal: measured · Coral: self-reported · X: prevalence (%)')
panel('Gap comparison',868,451,544,324,'Difference, in percentage points','All five measures · Measured minus self-reported')
block('WHAT THE DIFFERENCE DOES NOT PROVE','The source presents aggregate estimates, not a person-linked\nclassification table. Subtracting the percentages cannot identify\nwhich respondents were unaware, untreated or uncontrolled.\nA valid care cascade would require aligned definitions,\ndenominators and person-level status measures.',28,797,684,253)
block('USEFUL QUESTIONS TO TAKE FORWARD','Where might measurement and self-report differ most?\nWhich demographic patterns deserve closer investigation?\nWhat further evidence would support screening-service planning?\nUse the results to frame questions, then seek confidence intervals,\nlinked care data and more recent observations.',732,797,680,253)

dash(board_names[4],'Understand the evidence before the insight.','Historical official data, transparent definitions and traceable calculations. No patient records or synthetic observations.')
block('01 / What is included','Five selected mortality causes: diabetes, cerebrovascular,\nhypertensive, ischaemic heart and respiratory disease.\nAnnual total/male/female rates: 1996-2023, with the\nrespiratory series ending in 2022. All-NCD death shares\nand 2023 counts are separate measures. Survey findings\ncover five health measures, seven age bands and sex groups.',28,208,684,252)
block('02 / Survey dates and sample','JHLS III collected data September 2016-March 2017.\nThe ministry summary was published December 2024.\nParticipants were aged 15+; 3,420 people were targeted.\nThe report notes smaller blood/urine test subsamples.\nThese summary charts do not supply confidence intervals\nor matched-person tables. No statistical significance is inferred.',732,208,680,252)
block('03 / Mortality definitions','Disease-specific rates are age-standardised to the WHO\nWorld Standard Population. They describe comparative\npopulation rates, not current patient risk or raw death counts.\nRate change = (end rate - start rate) / start rate.\nNCD death share = the published percentage of all deaths.\nNo rates are converted into counts or combined across causes.',28,480,684,252)
block('04 / Measurement definitions','Measured and self-reported prevalence are copied from\nthe source charts. Difference = measured - self-reported,\nin percentage points. This is not an undiagnosed fraction.\nPeople can have multiple conditions; percentages do not sum\nto a population total. Excess weight means overweight/obesity.\nHistorical survey definitions are not current clinical guidance.',732,480,680,252)
block('05 / Trace every observation','Sources: MOHW Population Health Status Report 1995-2023\n(March 2025), tables on PDF pages 38-39 and narrative p28;\nMOHW Vitals / JHLS III (December 2024), charts pp56-58.\nPDF pages are counted from the first file page. Hover on a\nchart mark and choose the official-source action to open it.\nSource hashes, extracted facts and checks accompany GitHub.',28,752,684,298)
block('06 / How to use this dashboard','Use National Brief for a dated overview. Mortality Trends\nchanges cause, period and sex. Survey Explorer compares\nage and sex groups; age estimates are not split by sex.\nMeasurement Matters lets you select one comparison group.\nCharts retain missingness and do not interpolate values.\nNo parish map, care cascade or causal model is invented.\nThe ministry report errata and revised mortality notes were reviewed.',732,752,680,298)

for d in boards:el(d,'simple-id',uuid='{'+str(uuid.uuid5(uuid.NAMESPACE_DNS,'health-board-'+d.get('name'))).upper()+'}')
windows=el(root,'windows',**{'source-height':'30'})
for i,d in enumerate(boards):
 w=el(windows,'window',**{'class':'dashboard','name':d.get('name'),'maximized':'true' if i==0 else 'false'});vp=el(w,'viewpoints')
 for n in used[d.get('name')]:el(el(vp,'viewpoint',name=n),'zoom',type='entire-view')
 el(w,'active',id='-1');el(w,'simple-id',uuid=ids[d.get('name')])
for n in names:
 w=el(windows,'window',**{'class':'worksheet','name':n,'hidden':'true'});el(w,'cards');el(el(w,'viewpoint'),'zoom',type='entire-view');el(w,'simple-id',uuid='{'+str(uuid.uuid5(uuid.NAMESPACE_DNS,'health-window-'+n)).upper()+'}')
el(root,'thumbnails')
sys.path.insert(0,str(P.parents[1]/'work/tableau_runtime'))
from tableauhyperapi import HyperProcess,Telemetry,Connection,CreateMode,TableDefinition,TableName,SqlType,Inserter
hyper=P/'health.hyper';td=TableDefinition(TableName('Extract','Extract'),[TableDefinition.Column(n,SqlType.text() if t=='string' else SqlType.big_int() if t=='integer' else SqlType.double()) for n,t in F.items()])
with HyperProcess(Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as hp:
 with Connection(hp.endpoint,str(hyper),CreateMode.CREATE_AND_REPLACE) as conn:
  conn.catalog.create_schema('Extract');conn.catalog.create_table(td)
  with Inserter(conn,td) as ins:ins.add_rows([[r[n] if t=='string' else int(r[n]) if t=='integer' else float(r[n]) for n,t in F.items()] for r in data]);ins.execute()
  assert conn.execute_scalar_query('SELECT COUNT(*) FROM "Extract"."Extract"')==574
ex=el(ds,'extract',count='-1',enabled='true',units='records');cx=el(ex,'connection',authentication='auth-none',author_locale='en_US',**{'class':'hyper','dbname':'Data/Extracts/health.hyper','default-settings':'yes','schema':'Extract','tablename':'Extract'});el(cx,'relation',name='Extract',table='[Extract].[Extract]',type='table');emd=copy.deepcopy(md)
for rec in emd:rec.find('parent-name').text='[Extract]'
cx.append(emd)
for n in colorfields:el(ds,'column-instance',column=f'[{n}]',derivation='None',name=inst(n),pivot='key',type='nominal')
ds.remove(ex);ds.append(ex);ds.remove(dsstyle);ds.append(dsstyle)
svg='''<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="110" viewBox="0 0 1440 110"><rect width="1440" height="110" fill="#17343E"/><g fill="none" stroke="#71BCB5" opacity=".25"><circle cx="1095" cy="55" r="65"/><circle cx="1095" cy="55" r="48"/><path d="M990 75H1050L1063 55L1079 86L1098 30L1111 75H1160" stroke-width="2"/></g><path d="M0 109H1440" stroke="#087F80" stroke-width="2"/></svg>'''
(P/'header.svg').write_text(svg)
for q in root.findall('.//zone'):
 if q.find('button') is not None and q.find('zone-style') is not None:
  st=q.find('zone-style');q.remove(st);q.append(st)
E.indent(root);out=P/'Jamaica Health Pulse.twbx'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('Jamaica Health Pulse.twb',E.tostring(root,encoding='utf-8',xml_declaration=True));z.write(hyper,'Data/Extracts/health.hyper');z.write(P/'health.csv','health.csv');z.write(P/'header.svg','Image/header.svg')
(P/'calculated-fields.json').write_text(json.dumps(C,indent=2));print('Built',len(names),'worksheets and',len(boards),'dashboards:',out)
