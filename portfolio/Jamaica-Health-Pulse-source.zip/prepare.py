from pathlib import Path
import csv, json, re, hashlib
import pymupdf

P=Path(__file__).parent
sources=json.loads((P/'sources.json').read_text())
urls={s['key']:s['url'] for s in sources}
rows=[]
def add(kind,measure,group,sex,year,value,unit,page,method='',group_type='Sex',order=0,note=''):
    key='population-health' if kind!='Survey' else 'lifestyle-survey'
    rows.append({'Record Type':kind,'Measure':measure,'Group':group,'Sex':sex,'Year':year,'Year Key':str(year),
      'Period':'2016-17' if kind=='Survey' else str(year),'Value':value,'Unit':unit,'Method':method,
      'Group Type':group_type,'Group Order':order,'Source URL':urls[key]+f'#page={page}',
      'Source PDF Page':page,'Source Key':key,'Note':note})

doc=pymupdf.open(P/'sources/population-health.pdf')
rowmap={'Diabetes':(513.5,522.5,530.5),'Cerebrovascular disease':(555.5,564.5,573),
        'Hypertensive disease':(598.5,607,615),'Ischaemic heart disease':(640,648.5,657),
        'Respiratory disease':(680.5,689,697)}
extraction=[]
for page_no in [38,39]:
    words=doc[page_no-1].get_text('words')
    years={int(w[4]):(w[0]+w[2])/2 for w in words if re.fullmatch(r'(19|20)\d{2}',w[4]) and 100<w[1]<107}
    assert len(years)==(12 if page_no==38 else 17)
    def cells(y):
        result={}
        for yr,x in years.items():
            values=[w[4] for w in words if abs((w[0]+w[2])/2-x)<9 and abs((w[1]+w[3])/2-y)<2.5 and re.fullmatch(r'\d+\.\d+|-',w[4])]
            assert len(values)==1,(page_no,yr,y,values)
            result[yr]=None if values[0]=='-' else float(values[0])
        return result
    for measure,ys in rowmap.items():
        for sex,y in zip(['Total','Male','Female'],ys):
            values=cells(y);extraction.append({'page':page_no,'measure':measure,'sex':sex,'row_y':y,'values':values})
            for year,val in values.items():
                if val is not None:add('Mortality',measure,sex,sex,year,val,'Age-standardised deaths per 100,000',page_no,
                    note='WHO World Standard Population; revised series in the 2025 report. Rates are not death counts.')
    for sex,y in zip(['Total','Male','Female'],[423.5,432,440]):
        values=cells(y)
        for year,val in values.items():
            if val is not None:add('Share','All non-communicable diseases',sex,sex,year,val,'Percent of all deaths',page_no,
                note='All NCD causes, not just the five selected mortality causes.')

# Visual transcription of the source charts (PDF pages 56-58).
# Series order: overall, male, female; then seven age bands from 15-24 to 75+.
survey={
 'Diabetes':{'page':56,'measured':[11.9,9.4,14.4,1.5,5.5,9.1,18.7,21.3,27.3,42.4],
             'reported':[6.6,4.4,8.8,.5,1.3,2.1,9.5,17,20.4,30.8]},
 'Hypertension':{'page':56,'measured':[33.8,31.7,35.8,8.1,18,29.7,49.4,70,72.1,77.3],
                'reported':[24,15.4,32.2,5.1,11.7,21.2,29.9,51.1,58,70.2]},
 'High cholesterol':{'page':57,'measured':[24.6,18.4,31,5.5,15,29.6,28.7,37.6,40.9,42.5],
                    'reported':[8.3,4.5,12,2.1,.5,6,10.1,20.1,25.3,31.2]},
 'Chronic kidney disease':{'page':58,'measured':[15.2,12.4,17.6,8,11.5,10.2,11.7,25.2,28.1,43.5],
                         'reported':[1.1,.6,1.7,1.1,.9,.7,1.4,1.2,2.2,2.1]},
 'Overweight / obesity':{'page':58,'measured':[53.8,38.8,67.6,30.5,55.9,66.8,69.7,62.7,55.6,50.9],
                         'reported':[6.5,2.8,9.9,1.2,6,9.6,9.2,11,3.2,10.5]}}
groups=['Total','Male','Female','15-24','25-34','35-44','45-54','55-64','65-74','75+']
for measure,d in survey.items():
    for method,key in [('Measured','measured'),('Self-reported','reported')]:
        for i,(group,value) in enumerate(zip(groups,d[key])):
            add('Survey',measure,group,group if i<3 else 'All sexes',2017,value,'Percent of population in group',d['page'],method,
                'Sex' if i<3 else 'Age',i if i<3 else i-3,
                'JHLS III, September 2016-March 2017, ages 15+. Published December 2024. Different test subsamples; confidence intervals not supplied in these charts. Do not infer significance or individual diagnosis.')
for sex,value in [('Total',17180),('Male',8842),('Female',8338)]:
    add('Count','All non-communicable diseases',sex,sex,2023,value,'Reported deaths',28,
        note='Observed count, distinct from age-standardised rates. Total reconciles to male plus female.')

print('Mortality available',len([r for r in rows if r['Record Type']=='Mortality']))
assert len([r for r in rows if r['Record Type']=='Mortality'])==417
assert len([r for r in rows if r['Record Type']=='Survey'])==100
assert len({(r['Record Type'],r['Measure'],r['Group'],r['Year'],r['Method']) for r in rows})==len(rows)
def value(kind,measure,sex,year,method=''):
    return next(r['Value'] for r in rows if (r['Record Type'],r['Measure'],r['Group'],r['Year'],r['Method'])==(kind,measure,sex,year,method))
assert value('Mortality','Diabetes','Total',1996)==60.2
assert value('Mortality','Diabetes','Total',2023)==79.9
assert value('Mortality','Diabetes','Male',2023)==70.8
assert value('Mortality','Cerebrovascular disease','Total',2023)==78.2
assert value('Mortality','Hypertensive disease','Total',2023)==52.1
assert value('Share','All non-communicable diseases','Total',2023)==78.5
assert 8842+8338==17180
for r in rows:
    assert r['Value']>=0
    if r['Record Type'] in ['Survey','Share']:assert r['Value']<=100
fields={k:'integer' if k in ['Year','Source PDF Page','Group Order'] else 'real' if k=='Value' else 'string' for k in rows[0]}
with (P/'health.csv').open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
(P/'schema.json').write_text(json.dumps(fields,indent=2));(P/'mortality-extraction.json').write_text(json.dumps(extraction,indent=2))
(P/'survey-transcription.json').write_text(json.dumps(survey,indent=2))
checks={'records':len(rows),'mortality_records':417,'survey_records':100,'mortality_period':'1996-2023',
        'survey_period':'2016-17','survey_publication':'December 2024','retrieved':'2026-11-22',
        'checks':'Unique grain, bounds, known source values, NCD death count reconciliation passed',
        'caveats':['Historical population data, not current patient records','Self-report versus measured prevalence is not a person-linked diagnosis cascade','Survey charts do not report uncertainty intervals','Report errata must be checked; no interpolation of missing values']}
(P/'validation.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
