from pathlib import Path
import csv,json,copy,sys,zipfile,xml.etree.ElementTree as E
P=Path(__file__).parent;F=json.loads((P/'schema.json').read_text());data=list(csv.DictReader((P/'loans.csv').open(encoding='utf8')))
BG='#101923';CARD='#1B2A38';INK='#F0F5F8';MUTED='#B7C7D7';TEAL='#67DFC0';BLUE='#82B3FF';AMBER='#F1BD79';ROSE='#F18F9D';LINE='#354758'
def el(p,t,text=None,**a):
 q=E.SubElement(p,t,{k.replace('_','-'):str(v) for k,v in a.items()})
 if text is not None:q.text=str(text)
 return q
root=E.Element('workbook',{'source-platform':'win','version':'18.1','source-build':'2026.3.0 (20263.26.1022.1645)'})
m=el(root,'document-format-change-manifest')
for n in ['IntuitiveSorting','IntuitiveSorting_SP2']:el(m,n)
datas=el(root,'datasources');params=el(datas,'datasource',name='Parameters',hasconnection='false',inline='true',version='18.1');el(params,'aliases',enabled='yes')
def parameter(name,default,values=None,lo=None,hi=None,step=None,caption=None):
 typ='string' if isinstance(default,str) else 'integer';val=json.dumps(default)
 c=el(params,'column',name=f'[{name}]',caption=caption or name,datatype=typ,role='measure',type='nominal' if typ=='string' else 'quantitative',param_domain_type='list' if values else 'range',value=val)
 if typ!='string':c.set('default-format','n#,##0')
 el(c,'calculation',**{'class':'tableau','formula':val})
 if values:
  for v in values:el(el(c,'members') if c.find('members') is None else c.find('members'),'member',value=json.dumps(v))
 else:el(c,'range',min=lo,max=hi,granularity=step or 1)
parameter('Loan type','Used vehicle',['Used vehicle','New vehicle','Personal unsecured','Home mortgage'])
parameter('Loan amount',2000000,lo=100000,hi=60000000,step=100000,caption='Loan amount · JMD')
parameter('Term months',60,[12,24,36,48,60,72,84,96,108,120,180,240,300,360,420],caption='Repayment term · months')
parameter('Monthly income',250000,lo=0,hi=2000000,step=5000,caption='Take-home income · JMD/month')
parameter('Existing debts',30000,lo=0,hi=1000000,step=1000,caption='Existing debt payments · JMD/month')
parameter('Living expenses',100000,lo=0,hi=1500000,step=5000,caption='Essential expenses · JMD/month')
parameter('Debt budget percent',30,lo=5,hi=70,step=5,caption='Your debt-budget cap · % of net income')
parameter('Employment','Permanent employee',['Permanent employee','Contract employee','Self-employed','Other / not specified'])
parameter('Rate convention','Nominal annual',['Nominal annual','Effective annual'],caption='Model rate convention · assumption')
parameter('Bank detail','JN Bank',['JN Bank','Scotiabank Jamaica','First Global Bank','JMMB Bank','NCB Jamaica'],caption='Bank to inspect')
ds=el(datas,'datasource',name='loans',caption='Jamaica Loan Match | official published product snapshot',inline='true',version='18.1')
cn=el(ds,'connection',**{'class':'federated'});nc=el(el(cn,'named-connections'),'named-connection',name='textscan.loans',caption='loans');el(nc,'connection',**{'class':'textscan','directory':'','filename':'loans.csv','server':'','workgroup-auth-mode':'as-is'})
rel=el(cn,'relation',name='loans.csv',table='[loans#csv]',type='table',connection='textscan.loans');cols=el(rel,'columns',header='yes',separator=',',character_set='UTF-8',locale='en_US');md=el(cn,'metadata-records')
for i,(n,t) in enumerate(F.items()):
 el(cols,'column',name=n,datatype=t,ordinal=i);rec=el(md,'metadata-record',**{'class':'column'})
 for a,b in [('remote-name',n),('remote-type',129 if t=='string' else 20 if t=='integer' else 5),('local-name',f'[{n}]'),('parent-name','[loans.csv]'),('remote-alias',n),('ordinal',i),('local-type',t),('aggregation','Count' if t=='string' else 'Sum'),('contains-null','true')]:el(rec,a,b)
el(ds,'aliases',enabled='yes')
for n,t in F.items():el(ds,'column',name=f'[{n}]',datatype=t,role='dimension' if t=='string' else 'measure',type='nominal' if t=='string' else 'quantitative')
el(el(ds.find("column[@name='[Bank]']"),'aliases'),'alias',key='"Scotiabank Jamaica"',value='Scotiabank')
C={}
def calc(n,t,f,fmt=None,dim=False):C[n]=(t,f,fmt,dim)
money='n"J$"#,##0';percent='p0.0%'
calc('Loan scope','string',"IF [Loan Type]=[Parameters].[Loan type] THEN 'Yes' ELSE 'No' END",dim=True)
calc('Term scope','string',"IF [Term Months]=[Parameters].[Term months] THEN 'Yes' ELSE 'No' END",dim=True)
calc('Bank scope','string',"IF [Bank]=[Parameters].[Bank detail] THEN 'Yes' ELSE 'No' END",dim=True)
calc('Low endpoint','string',"IF [Endpoint]='Low' THEN 'Yes' ELSE 'No' END",dim=True)
calc('Rate available','string',"IF ISNULL([Rate]) THEN 'No' ELSE 'Yes' END",dim=True)
calc('Monthly rate','real',"IF [Parameters].[Rate convention]='Effective annual' THEN POWER(1+[Rate]/100,1.0/12)-1 ELSE [Rate]/1200 END")
calc('Valid term','string',"IF [Max Term Months]>0 AND [Term Months]>[Max Term Months] THEN 'No' ELSE 'Yes' END",dim=True)
calc('Trend scope','string',"IF [Term Months] <= (IF [Parameters].[Loan type]='Home mortgage' THEN 420 ELSEIF [Parameters].[Loan type]='Personal unsecured' THEN 84 ELSE 120 END) AND ([Max Term Months]=0 OR [Term Months]<=[Max Term Months]) THEN 'Yes' ELSE 'No' END",dim=True)
calc('Monthly payment','real',"IF [Valid term]='Yes' AND NOT ISNULL([Rate]) THEN IF [Monthly rate]=0 THEN [Parameters].[Loan amount]/[Term Months] ELSE [Parameters].[Loan amount]*[Monthly rate]/(1-POWER(1+[Monthly rate],-[Term Months])) END END")
calc('Upper monthly rate','real',"IF [Parameters].[Rate convention]='Effective annual' THEN POWER(1+[Rate High]/100,1.0/12)-1 ELSE [Rate High]/1200 END")
calc('Upper payment','real',"IF [Valid term]='Yes' AND NOT ISNULL([Rate High]) THEN IF [Upper monthly rate]=0 THEN [Parameters].[Loan amount]/[Term Months] ELSE [Parameters].[Loan amount]*[Upper monthly rate]/(1-POWER(1+[Upper monthly rate],-[Term Months])) END END")
calc('Upper payment value','real','MIN([Upper payment])',money)
calc('Payment value','real','MIN([Monthly payment])',money)
calc('Payment K','real','MIN([Monthly payment])/1000','n"J$"0.0"k"')
calc('Interest value','real','MIN([Monthly payment]*[Term Months]-[Parameters].[Loan amount])',money)
calc('Interest K','real','MIN([Monthly payment]*[Term Months]-[Parameters].[Loan amount])/1000','n"J$"#,##0"k"')
calc('Rate percent','real','MIN([Rate])/100','p0.00%')
calc('Term axis','real','MIN([Term Months])','n0')
calc('Payment budget','real','MAX(0,MIN([Parameters].[Monthly income]*[Parameters].[Debt budget percent]/100.0-[Parameters].[Existing debts],[Parameters].[Monthly income]-[Parameters].[Existing debts]-[Parameters].[Living expenses]))')
calc('Budget KPI','real','MIN([Payment budget])',money)
calc('Loan KPI','real','MIN([Parameters].[Loan amount])',money)
calc('Coverage KPI','integer','COUNTD(IF NOT ISNULL([Rate Low]) THEN [Bank] END)','n0')
calc('Quote KPI','integer','COUNTD(IF ISNULL([Rate Low]) THEN [Bank] END)','n0')
calc('Budget status','string',"IF ISNULL([Rate Low]) THEN 'Quote required' ELSEIF [Valid term]='No' THEN 'Term exceeds published limit' ELSEIF [Max Amount JMD]>0 AND [Parameters].[Loan amount]>[Max Amount JMD] THEN 'Amount exceeds published limit' ELSEIF [Employment Rule]='Permanent employment required' AND [Parameters].[Employment]<>'Permanent employee' THEN 'Employment condition not met' ELSEIF [Monthly payment]>[Payment budget] THEN 'Above selected budget' ELSEIF ISNULL([Rate High]) THEN 'Upper rate unknown' ELSEIF [Upper payment]>[Payment budget] THEN 'Range crosses budget' ELSE 'Full range within budget' END",dim=True)
calc('Comparison label','string',"ATTR([Rate Label])+' | '+IF MIN([Max Term Months])>0 AND [Parameters].[Term months]>MIN([Max Term Months]) THEN 'Term exceeds published limit' ELSEIF ISNULL(MIN([Rate Low])) THEN 'Request a bank quote' ELSE 'J$'+STR(INT(ROUND(MIN([Monthly payment]),0)))+'–'+IF ISNULL(MIN([Upper payment])) THEN '?' ELSE 'J$'+STR(INT(ROUND(MIN([Upper payment]),0))) END+'/mo' END")
calc('Scenario context','string',"[Parameters].[Loan type]+' | J$'+STR([Parameters].[Loan amount])+' | '+STR([Parameters].[Term months])+' months | '+[Parameters].[Rate convention]+' model'",dim=True)
calc('Detail narrative','string',"ATTR([Bank])+CHAR(10)+ATTR([Rate Label])+CHAR(10)+ATTR([Rate Basis])+CHAR(10)+CHAR(10)+ATTR([Notes])")
calc('Requirement narrative','string',"'EMPLOYMENT CHECK'+CHAR(10)+ATTR([Employment Rule])+CHAR(10)+CHAR(10)+'YOUR SELECTION: '+[Parameters].[Employment]+CHAR(10)+CHAR(10)+ATTR([Documents])")
calc('Source narrative','string',"'Official source: '+ATTR([Source URL])+CHAR(10)+'Reviewed '+ATTR([Reviewed])+'. Effective date often unspecified; confirm a current quote.'")
calc('Budget narrative','string',"'Model budget: J$'+STR(INT(MIN([Payment budget])))+'/month.'+CHAR(10)+'Lower of your debt cap and remaining cash after expenses.'")
calc('Amount note','string',"IF MIN([Max Amount JMD])>0 AND [Parameters].[Loan amount]>MIN([Max Amount JMD]) THEN 'Selected amount exceeds the published product maximum.' ELSE 'Amount and term remain subject to the bank’s assessment.' END")
calc('Model note','string',"'Illustration only: '+[Parameters].[Rate convention]+' scenario.'+CHAR(10)+'Excludes fees, insurance, taxes and rate changes.'+CHAR(10)+'Confirm written quotes.'",dim=True)
for n,(t,f,fmt,dim) in C.items():
 c=el(ds,'column',name=f'[{n}]',datatype=t,role='dimension' if dim else 'measure',type='nominal' if t=='string' else 'quantitative')
 if fmt:c.set('default-format',fmt)
 el(c,'calculation',**{'class':'tableau','formula':f})
def ref(n,der=None):
 dim=F.get(n)=='string' or C.get(n,(None,None,None,False))[3];der=der or ('none' if dim else 'usr' if n in C else 'min')
 return f'[loans].[{der}:{n}:{"nk" if F.get(n)=="string" or C.get(n,(None,))[0]=="string" else "qk"}]'
def inst(n):return ref(n).split('[loans].')[1]
def pdep(parent):
 dep=el(parent,'datasource-dependencies',datasource='Parameters')
 for c in params.findall('column'):dep.append(copy.deepcopy(c))
works=el(root,'worksheets');names=[];dsstyle=el(ds,'style');dsmark=el(dsstyle,'style-rule',element='mark');colorfields=set()
def sheet(name,measure,dim='Bank',mark='Text',term=True,detail=False,extra=None,color=TEAL,series=None,rows=None,cols=None,labels=True,textsize=11,path=None):
 names.append(name);w=el(works,'worksheet',name=name);el(el(el(w,'layout-options'),'title'),'formatted-text');t=el(w,'table');v=el(t,'view');el(el(v,'datasources'),'datasource',name='loans',caption=ds.get('caption'));pdep(v);dep=el(v,'datasource-dependencies',datasource='loans')
 for c in ds.findall('column'):dep.append(copy.deepcopy(c))
 for n in list(F)+list(C):
  q=inst(n);der=q[1:].split(':')[0];el(dep,'column-instance',column=f'[{n}]',derivation={'none':'None','min':'Min','usr':'User'}[der],name=q,pivot='key',type='nominal' if q.endswith(':nk]') else 'quantitative')
 for n,typ in F.items():
  if typ=='string':el(dep,'column-instance',column=f'[{n}]',derivation='Attribute',name=f'[attr:{n}:nk]',pivot='key',type='nominal')
 filters={'Loan scope':['Yes']}
 if term:filters['Term scope']=['Yes']
 if detail:filters['Bank scope']=['Yes']
 filters.update(extra or {})
 for n,values in filters.items():
  g=el(el(v,'filter',**{'class':'categorical','column':ref(n)}),'groupfilter',function='union')
  for val in values:el(g,'groupfilter',function='member',level=inst(n),member=json.dumps(val))
 rr=rows if rows is not None else '' if mark=='Text' else ref(dim);cc=cols if cols is not None else '' if mark=='Text' else ref(measure)
 el(v,'aggregation',value='true');style=el(t,'style')
 for name_,fmts in [('worksheet',{'font-family':'Tableau Book','font-size':'11','color':INK,'background-color':CARD,'display-field-labels':'false'}),('pane',{'background-color':CARD,'band-color':CARD,'band-size':'0'}),('cell',{'background-color':CARD,'color':INK}),('header',{'background-color':CARD,'band-color':CARD,'band-size':'0','color':MUTED,'font-size':'11'}),('axis',{'background-color':CARD,'color':MUTED,'font-size':'10'}),('gridline',{'stroke-size':'0'}),('zeroline',{'stroke-size':'1','stroke-color':LINE})]:
  st=el(style,'style-rule',element=name_)
  for a,b in fmts.items():el(st,'format',attr=a,value=b)
 for field,side in [(rr,'rows'),(cc,'cols')]:
  if field:el(el(style,'style-rule',element='axis'),'format',attr='title',field=field,scope=side,value='')
 if dim=='Bank' and rr:el(el(style,'style-rule',element='cell'),'format',attr='width',field=ref('Bank'),value='205')
 p=el(el(t,'panes'),'pane',selection_relaxation_option='selection-relaxation-allow');el(el(p,'view'),'breakdown',value='auto');el(p,'mark',**{'class':mark});en=el(p,'encodings')
 if labels or mark=='Text':el(en,'text',column=ref(measure))
 if path:el(en,'path',column=ref(path))
 if series:
  el(en,'color',column=ref(series))
  if series not in colorfields:
   enc=el(dsmark,'encoding',attr='color',field=inst(series),type='palette')
   mapping={'Budget status':{'Full range within budget':TEAL,'Range crosses budget':AMBER,'Upper rate unknown':AMBER,'Above selected budget':ROSE,'Quote required':MUTED,'Term exceeds published limit':AMBER,'Amount exceeds published limit':AMBER,'Employment condition not met':AMBER},'Bank':{'JN Bank':TEAL,'Scotiabank Jamaica':BLUE,'First Global Bank':AMBER,'JMMB Bank':'#B6A1F0','NCB Jamaica':ROSE}}.get(series,{})
   for value,col in mapping.items():el(el(enc,'map',to=col),'bucket',json.dumps(value))
   colorfields.add(series)
 for n in ['Bank','Loan Type','Rate Label','Rate Basis','Evidence','Employment Rule','Documents','Notes','Source URL']:el(en,'tooltip',column=f'[loans].[attr:{n}:nk]')
 for n in ['Payment value','Interest value','Rate percent','Budget KPI']:el(en,'tooltip',column=ref(n))
 tip='Jamaica Loan Match\n<[loans].[attr:Bank:nk]> | <[loans].[attr:Loan Type:nk]>\nPublished: <[loans].[attr:Rate Label:nk]>\nBasis: <[loans].[attr:Rate Basis:nk]>\nModel payment: <'+ref('Payment value')+'> | Model interest: <'+ref('Interest value')+'>\nYour model budget: <'+ref('Budget KPI')+'>\n<[loans].[attr:Employment Rule:nk]>\n<[loans].[attr:Notes:nk]>\nSource: <[loans].[attr:Source URL:nk]>\nReviewed 21 Nov 2026. Estimates exclude fees and insurance; not an approval or personalised quote.'
 el(el(el(p,'customized-tooltip'),'formatted-text'),'run',tip,fontsize=10,fontcolor='#162433')
 if labels or mark=='Text':el(el(el(p,'customized-label'),'formatted-text'),'run','<'+ref(measure)+'>',fontsize=textsize,fontname='Tableau Semibold' if textsize>=18 else 'Tableau Book',fontcolor=INK)
 st=el(el(p,'style'),'style-rule',element='mark')
 for a,b in {'mark-color':color,'mark-transparency':'255','size':'.7','has-stroke':'false','mark-labels-show':'true' if labels or mark=='Text' else 'false'}.items():el(st,'format',attr=a,value=b)
 el(t,'rows',rr);el(t,'cols',cc);return w
for n,m in [('Budget card','Budget KPI'),('Amount card','Loan KPI'),('Coverage card','Coverage KPI'),('Quote card','Quote KPI')]:sheet(n,m,textsize=29)
sheet('Context','Scenario context',textsize=12)
sheet('Model caution','Model note',textsize=10)
sheet('Rates','Rate percent',mark='Line',path='Endpoint',extra={'Rate available':['Yes']},labels=True,color=BLUE)
sheet('Payments','Payment K',mark='Bar',extra={'Low endpoint':['Yes'],'Rate available':['Yes'],'Valid term':['Yes']},series='Budget status')
sheet('Bank comparison','Comparison label',rows=ref('Bank'),extra={'Low endpoint':['Yes']},textsize=9)
sheet('Budget narrative','Budget narrative',textsize=12)
sheet('Detail','Detail narrative',detail=True,textsize=12)
sheet('Requirements','Requirement narrative',detail=True,textsize=12)
sheet('Source','Source narrative',detail=True,textsize=10)
sheet('Detail payment','Payment value',detail=True,extra={'Low endpoint':['Yes']},textsize=28)
sheet('Detail interest','Interest value',detail=True,extra={'Low endpoint':['Yes']},textsize=28)
sheet('Amount note','Amount note',detail=True,textsize=11)
sheet('Payment curve','Payment K',mark='Line',term=False,extra={'Low endpoint':['Yes'],'Rate available':['Yes'],'Trend scope':['Yes']},series='Bank',rows=ref('Payment K'),cols=ref('Term axis'),path='Term Key',labels=False)
sheet('Interest curve','Interest K',mark='Line',term=False,extra={'Low endpoint':['Yes'],'Rate available':['Yes'],'Trend scope':['Yes']},series='Bank',rows=ref('Interest K'),cols=ref('Term axis'),path='Term Key',labels=False)
actions=E.parse(P/'actions.xml').getroot()
for board in ['02 Bank Detail','03 Term Tradeoffs']:
 a=copy.deepcopy(actions.find('action'));a.set('name','[OfficialSource_'+board[:2]+']');a.find('source').set('dashboard',board);actions.insert(1,a)
root.insert(list(root).index(root.find('worksheets')),actions)
boards=el(root,'dashboards');used={};base=None;current=None;W=1440;H=1120
def zone(x,y,w,h,kind=None,text=None,font=11,fg=INK,bg=CARD,name=None,**extra):
 q=el(base,'zone',h=round(h/H*100000),w=round(w/W*100000),x=round(x/W*100000),y=round(y/H*100000),id=len(base)+1,is_floating='true',**extra)
 if kind:q.set('type-v2',kind)
 if name:q.set('name',name);used[current].append(name)
 if text is not None:el(el(q,'formatted-text'),'run',text,fontname='Tableau Semibold' if font>=14 else 'Tableau Book',fontsize=font,fontcolor=fg)
 st=el(q,'zone-style')
 for a,b in {'background-color':bg,'border-style':'none','padding':'0' if kind in ['text','empty','bitmap'] else '8','margin':'0'}.items():el(st,'format',attr=a,value=b)
 return q
def txt(t,x,y,w,h,font=11,fg=MUTED,bg=BG):return zone(x,y,w,h,'text',text=t,font=font,fg=fg,bg=bg)
def control(n,x,y,w,h=61):return zone(x,y,w,h,'paramctrl',param=f'[Parameters].[{n}]',mode='compact',bg=CARD)
def dash(name,title,sub,inputs=True):
 global base,current
 current=name;used[name]=[];d=el(boards,'dashboard',name=name);el(d,'style');el(d,'size',minwidth=W,maxwidth=W,minheight=H,maxheight=H);el(el(d,'datasources'),'datasource',name='Parameters');pdep(d)
 base=el(el(d,'zones'),'zone',id=0,x=0,y=0,w=100000,h=100000,type_v2='layout-basic');zone(0,0,W,H,'empty',bg=BG)
 zone(0,0,W,112,'bitmap',param='Image/header.svg',is_scaled='1',is_centered='1',bg=BG)
 txt(title,28,36,1160,49,28,INK);txt('JULIAN DEVONISH',1210,25,207,25,10,TEAL);txt('OFFICIAL BANK SOURCES',1178,65,235,22,9,MUTED)
 txt(sub,28,126,1384,38,11)
 if inputs:
  for i,n in enumerate(['Loan type','Loan amount','Term months','Rate convention']):control(n,28+i*350,178,334)
  for i,n in enumerate(['Monthly income','Existing debts','Living expenses','Debt budget percent']):control(n,28+i*350,253,334)
  zone(28,326,1384,34,name='Context',show_title='false',bg=BG)
 txt('Source snapshot: 21 Nov 2026 · JMD loans · Estimates exclude fees / insurance · Not a bank quote or approval · Open 04 Guide before relying on comparisons',28,1074,1384,27,9)
def panel(n,x,y,w,h,title,sub):
 zone(x,y,w,h,'empty');txt(title,x+15,y+12,w-30,30,15,INK,CARD);txt(sub,x+15,y+49,w-30,43,10,MUTED,CARD);zone(x+8,y+96,w-16,h-104,name=n,show_title='false')
def cards():
 for i,(n,title,sub,col) in enumerate([('Budget card','Your monthly payment budget','Selected debt cap and remaining cash',TEAL),('Amount card','Amount to borrow','Same principal in every comparison',BLUE),('Coverage card','Banks with a numeric rate','Published range or starting rate',AMBER),('Quote card','Banks requiring a quote','Kept visible; no invented rates',ROSE)]):
  x=28+i*350;zone(x,377,334,128,'empty');zone(x,377,334,3,'empty',bg=col);txt(title,x+12,390,310,25,11,MUTED,CARD);zone(x+5,418,324,49,name=n,show_title='false');txt(sub,x+12,473,310,24,9,MUTED,CARD)
dash('01 Loan Match','Find a loan that fits your budget.','Compare published Jamaican bank products, then test the repayment against your own budget. No approval probability or guaranteed best bank is inferred.')
cards()
panel('Rates',28,525,684,280,'Published rate comparison','Published annual rates; confirm each bank’s rate basis.')
panel('Payments',732,525,680,280,'Starting repayment illustration','J$000/month · Teal: fits · Rose: above budget · Amber: review')
zone(28,825,684,230,'empty');txt('All five banks stay visible',43,837,654,30,15,INK,CARD);txt('Published rates and model ranges · Hover for source; use menu to open',43,872,654,24,9,MUTED,CARD);zone(36,902,668,146,name='Bank comparison',show_title='false')
zone(732,825,680,230,'empty');txt('READ THE COMPARISON CORRECTLY',748,839,648,27,12,TEAL,CARD);zone(748,878,648,82,name='Budget narrative',show_title='false');zone(748,966,648,78,name='Model caution',show_title='false')
dash('02 Bank Detail','Read the conditions behind the rate.','Inspect one bank at a time. Your employment selection checks explicit published requirements; it does not calculate an approval probability.')
control('Bank detail',28,378,450);control('Employment',498,378,450)
txt('General requirements often need bank confirmation. A budget fit is not a lending decision.',968,388,444,52,11,AMBER)
zone(28,461,684,272,'empty');zone(44,476,652,241,name='Detail',show_title='false')
zone(732,461,680,272,'empty');zone(748,476,648,241,name='Requirements',show_title='false')
panel('Detail payment',28,753,334,150,'Monthly estimate','Starting rate; excludes fees.')
panel('Detail interest',382,753,330,150,'Modelled interest','Over the selected term.')
zone(732,753,680,150,'empty');txt('CHECK BEFORE YOU APPLY',748,768,648,27,12,TEAL,CARD);txt('Ask for the nominal rate, effective annual rate, all fees, insurance,\nrepayment schedule, fixed-rate period and early-settlement charges.\nIncome alone cannot establish credit eligibility.',748,813,648,76,11,MUTED,CARD)
zone(28,923,1384,62,name='Source',show_title='false');zone(28,992,1384,61,name='Amount note',show_title='false')
dash('03 Term Tradeoffs','A smaller payment can cost more overall.','Explore term scenarios at each bank’s published starting rate. Lines are illustrations; approval, age limits, deposit and final pricing remain subject to the bank.')
cards()
panel('Payment curve',28,525,1384,244,'Monthly repayment across possible terms','X: term in months. Y: J$ thousands/month. Known published maximum terms are respected; unknown maxima need confirmation.')
panel('Interest curve',28,789,1384,245,'Interest cost across the same terms','X: term in months. Y: J$ thousands interest, excluding fees and insurance. Longer terms can reduce instalments while increasing interest.')
txt('Bank colours: JN teal · Scotiabank blue · First Global amber. Quote-only banks have no estimated curve. Use tooltips for bank names and source details.',28,1040,1384,25,10,TEAL)
dash('04 Guide','Understand the rates. Know the limits.','Read this guide before interpreting rates, affordability or product requirements.',False)
def block(x,y,w,h,title,body):
 zone(x,y,w,h,'empty');txt(title,x+16,y+15,w-32,33,17,INK,CARD);txt(body,x+16,y+66,w-32,h-76,11,MUTED,CARD)
block(28,192,684,245,'What this dashboard compares','Five banks: JN, Scotiabank Jamaica, First Global, JMMB and NCB.\nFour purposes: personal unsecured, new vehicle, used vehicle and\nhome mortgage. Twenty curated product entries; nine have a\nnumeric rate/range and eleven need a quote in reviewed sources.\nThese are public product observations, not customer-level records.\nNo generated customer data or inferred approval probabilities.')
block(732,192,680,245,'Rates are not all defined alike','Scotiabank labels its range APR/EAIR. Other reviewed pages use\nannual interest or per-annum wording without a full convention.\nChoose Nominal annual or Effective annual to test a COMMON\nmodel assumption. This does not resolve the bank’s contract basis.\nThe lowest model payment is not proof of the cheapest actual offer.\nConfirm equivalent rate definitions and all costs in written quotes.')
block(28,457,684,265,'How the calculator works','Monthly rate = annual % / 1200 in the nominal scenario; or\n(1 + annual % / 100)^(1/12) − 1 in the effective scenario.\nPayment = principal × r / [1 − (1+r)^(-number of months)].\nInterest illustration = payment × months − principal.\nConstant reducing-balance rate, equal monthly payments. No\nfees, insurance, taxes, payment holidays or rate resets included.\nUnknown upper rates are kept unknown, never copied from minima.')
block(732,457,680,265,'What “within budget” means','Budget is the greater of zero and the LOWER of:\n1) take-home income × your debt cap % − existing debt payments;\n2) take-home income − existing debts − essential living expenses.\nThe default 30% is an editable personal-budget assumption. It is\nnot a bank debt-service threshold. Employment and explicit product\nlimits can flag conditions; credit history, age, stability, collateral\nand bank underwriting are not predicted or fully evaluated.')
block(28,742,684,300,'Source evidence and missing information','Sources are the banks’ own rate tables and product pages.\nReviewed / downloaded 21 November 2026; many pages have no\neffective date. A live website is not assurance of a current offer.\nExpired dealer promotions and estimated third-party rates excluded.\nNCB fee-based digital products are not labelled 0% interest loans.\nJN iProtect has different terms and is not mixed with standard loans.\nUse bank-detail source URLs and tooltips for evidence; a rate\nquote and complete fee schedule are required before choosing.')
block(732,742,680,300,'Controls, privacy and interpretation','Start with Loan type, amount, term and rate convention. Then\nchange income, debts and expenses to test your own budget.\nBank Detail shows published requirements and source links.\nTerm Tradeoffs keeps your amount/rate convention and varies term.\nUse fictional scenario values on this public dashboard; avoid\nsharing URLs/screenshots containing your personal income.\nRevert on the Tableau toolbar restores the published example.\nIndependent portfolio project; no bank endorsement or affiliation.')
windows=el(root,'windows',**{'source-height':'30'})
for i,d in enumerate(boards):
 w=el(windows,'window',**{'class':'dashboard','name':d.get('name'),'maximized':'true' if i==0 else 'false'});vp=el(w,'viewpoints')
 for n in used[d.get('name')]:el(el(vp,'viewpoint',name=n),'zoom',type='entire-view')
 el(w,'active',id='-1')
for name in names:
 w=el(windows,'window',**{'class':'worksheet','name':name,'hidden':'true'});cs=el(w,'cards');left=el(el(cs,'edge',name='left'),'strip',size=160)
 for ct in ['pages','filters','marks']:el(left,'card',type=ct)
 top=el(cs,'edge',name='top')
 for ct in ['columns','rows','title']:el(el(top,'strip',size=26),'card',type=ct)
 el(el(w,'viewpoint'),'zoom',type='entire-view')
el(root,'thumbnails')
sys.path.insert(0,str(P.parents[1]/'work/tableau_runtime'))
from tableauhyperapi import HyperProcess,Telemetry,Connection,CreateMode,TableDefinition,TableName,SqlType,Inserter
hyper=P/'loans.hyper';td=TableDefinition(TableName('Extract','Extract'),[TableDefinition.Column(n,SqlType.text() if t=='string' else SqlType.big_int() if t=='integer' else SqlType.double()) for n,t in F.items()])
with HyperProcess(Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as hp:
 with Connection(hp.endpoint,str(hyper),CreateMode.CREATE_AND_REPLACE) as conn:
  conn.catalog.create_schema('Extract');conn.catalog.create_table(td)
  with Inserter(conn,td) as ins:ins.add_rows([[r[n] if t=='string' else None if not r[n] else int(r[n]) if t=='integer' else float(r[n]) for n,t in F.items()] for r in data]);ins.execute()
  assert conn.execute_scalar_query('SELECT COUNT(*) FROM "Extract"."Extract"')==600
ex=el(ds,'extract',count='-1',enabled='true',units='records');cx=el(ex,'connection',authentication='auth-none',author_locale='en_US',**{'class':'hyper','dbname':'Data/Extracts/loans.hyper','default-settings':'yes','schema':'Extract','tablename':'Extract'});el(cx,'relation',name='Extract',table='[Extract].[Extract]',type='table');emd=copy.deepcopy(md)
for rec in emd:rec.find('parent-name').text='[Extract]'
cx.append(emd)
for n in colorfields:el(ds,'column-instance',column=f'[{n}]',derivation='None',name=inst(n),pivot='key',type='nominal')
ds.remove(ex);ds.append(ex);ds.remove(dsstyle);ds.append(dsstyle);E.indent(root)
svg='''<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="112" viewBox="0 0 1440 112"><defs><linearGradient id="g"><stop stop-color="#143d49"/><stop offset="1" stop-color="#101923"/></linearGradient></defs><rect width="1440" height="112" fill="url(#g)"/><path d="M930 96 980 75 1018 80 1060 50 1100 59 1150 20 1190 35" fill="none" stroke="#67DFC0" stroke-width="2" opacity=".28"/><path d="M0 110H1440" stroke="#335261"/></svg>'''
(P/'header.svg').write_text(svg,encoding='utf8')
out=P/'Jamaica Loan Match.twbx'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('Jamaica Loan Match.twb',E.tostring(root,encoding='utf8',xml_declaration=True));z.write(hyper,'Data/Extracts/loans.hyper');z.write(P/'loans.csv','loans.csv');z.write(P/'header.svg','Image/header.svg')
(P/'calculated-fields.json').write_text(json.dumps(C,indent=2),encoding='utf8');print('Built',len(names),'worksheets and',len(boards),'dashboards:',out)

from navigation import apply as add_navigation
add_navigation(out)
