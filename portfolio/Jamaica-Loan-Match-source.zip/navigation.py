from pathlib import Path
import zipfile, uuid, xml.etree.ElementTree as E

def apply(path):
    path = Path(path)
    with zipfile.ZipFile(path) as z:
        files = {n: z.read(n) for n in z.namelist()}
    name = next(n for n in files if n.endswith('.twb'))
    root = E.fromstring(files[name].decode('utf-8'))
    manifest = root.find('document-format-change-manifest')
    for tag in ['BasicButtonObject', 'BasicButtonObjectTextSupport', 'SheetIdentifierTracking', 'WindowsPersistSimpleIdentifiers']:
        if manifest.find(tag) is None: E.SubElement(manifest, tag)
    boards = root.findall('./dashboards/dashboard')
    destinations = {}
    for window in root.findall('./windows/window'):
        if window.get('class') != 'dashboard': continue
        simple = window.find('simple-id')
        if simple is None:
            simple = E.SubElement(window, 'simple-id', uuid='{'+str(uuid.uuid5(uuid.NAMESPACE_DNS, 'loan-match-window-'+window.get('name'))).upper()+'}')
        destinations[window.get('name')] = simple.get('uuid')
    captions = ['01 Compare loans', '02 Bank conditions', '03 Term tradeoffs', '04 Data & guide']
    for board in boards:
        zones = board.find('zones')
        for old in list(zones):
            if old.find('button') is not None: zones.remove(old)
        base = board.find('./zones/zone')
        for zone in list(base):
            if zone.find('button') is not None: base.remove(zone)
            elif zone.get('type-v2') == 'text' and 11000 < int(zone.get('y', 0)) < 16000:
                zone.set('y', '14107'); zone.set('h', '1607')
                for run in zone.findall('./formatted-text/run'): run.set('fontsize', '9')
        for i, (destination, caption) in enumerate(zip(destinations, captions)):
            active = destination == board.get('name')
            q = E.SubElement(base, 'zone', {'id':str(100+i),'type-v2':'dashboard-object','is-floating':'true',
                'x':str(round((28+i*240)/1440*100000)), 'y':str(round(120/1120*100000)),
                'w':str(round(226/1440*100000)), 'h':str(round(30/1120*100000))})
            button = E.SubElement(q,'button',{'action':f'tabdoc:goto-sheet window-id="{destinations[destination]}"','button-type':'text'})
            state = E.SubElement(button,'button-visual-state')
            E.SubElement(state,'caption').text=caption
            E.SubElement(state,'button-caption-font-style',fontcolor='#101923' if active else '#B7C7D7',fontname='Tableau Semibold',fontsize='10')
            E.SubElement(state,'format',attr='background-color',value='#67DFC0' if active else '#1B2A38')
    E.indent(root)
    files[name] = E.tostring(root,encoding='utf-8',xml_declaration=True)
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for n,b in files.items(): z.writestr(n,b)

if __name__ == '__main__': apply(Path(__file__).parent/'Jamaica Loan Match.twbx')
