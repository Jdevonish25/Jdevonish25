from pathlib import Path
import csv,json,urllib.request,hashlib,math
P=Path(__file__).parent
(P/'raw').mkdir(exist_ok=True)
URLS={
 'jn_rates':'https://www.jnbank.com/personal-banking/loans/loans-interest-rates/',
 'jn_mortgage':'https://www.jnbank.com/personal-banking/mortgage/mortgage-rates/',
 'jn_personal':'https://www.jnbank.com/personal-banking/loans/unsecured/',
 'jn_auto':'https://www.jnbank.com/personal-banking/loans/auto-loans/',
 'scotia_rates':'https://jm.scotiabank.com/personal/rates-and-fees/borrowing-rates.html',
 'scotia_auto':'https://jm.scotiabank.com/personal/borrowing/auto-loans.html',
 'fgb_used':'https://firstglobal-bank.com/personal-banking/personal-loans/pre-owned-motor-vehicle-loan/',
 'fgb_new':'https://firstglobal-bank.com/personal-banking/personal-loans/new-motor-vehicle-loan/',
 'fgb_personal':'https://firstglobal-bank.com/personal-banking/personal-loans/unsecured-loan/',
 'fgb_mortgage':'https://firstglobal-bank.com/personal-banking/mortgage/',
 'jmmb':'https://jm.jmmb.com/loans-overview',
 'ncb':'https://www.jncb.com/personal/loans/',
}
manifest=[]
for key,url in URLS.items():
 try:
  content=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=35).read()
  (P/'raw'/f'{key}.html').write_bytes(content)
  manifest.append({'key':key,'url':url,'retrieved':'2026-11-21','sha256':hashlib.sha256(content).hexdigest()})
 except Exception as e:manifest.append({'key':key,'url':url,'retrieved':'2026-11-21','download_error':str(e)})
(P/'sources.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
products=[]
def product(bank,kind,lo=None,hi=None,source='',basis='Not published in reviewed source',term=0,amount=0,ltv=0,employment='Confirm with bank',docs='Income, identity and credit assessment; ask bank for full checklist.',notes='Fees, insurance and final offer require confirmation.'):
 label='Quote required' if lo is None else f'From {lo:.2f}%' if hi is None else f'{lo:.2f}% – {hi:.2f}%' if hi!=lo else f'{lo:.2f}%'
 products.append({'Product ID':bank+' | '+kind,'Bank':bank,'Loan Type':kind,'Rate Low':lo,'Rate High':hi,'Rate Label':label,'Rate Basis':basis,'Max Term Months':term,'Max Amount JMD':amount,'Max Financing Percent':ltv,'Employment Rule':employment,'Documents':docs,'Notes':notes,'Source URL':URLS[source],'Evidence': 'Quote required' if lo is None else 'Starting rate only' if hi is None else 'Published rate / range','Reviewed':'21 Nov 2026'})
jn='Annual interest rate; compounding convention not specified'
for kind,lo,hi in [('New vehicle',8.99,10.74),('Used vehicle',10.74,11.99)]:
 product('JN Bank',kind,lo,hi,'jn_rates',jn,120,ltv=100,notes='General auto page says up to 10 years and up to 100% financing; vehicle-specific term and deposit require confirmation.')
product('JN Bank','Personal unsecured',18.99,26.25,'jn_rates',jn,84,5000000,employment='Salaried / self-employed documentation published',docs='Salaried: income letter and 3 months payslips. Self-employed: 12 months bank activity, financial statements if available and auditor confirmation. ID, TRN, address and credit checks also required.',notes='Reducing-balance repayments; up to 5–7 years, conditions apply. iProtect is a separate conditional product and is excluded.')
product('JN Bank','Home mortgage',9.85,9.85,'jn_mortgage',jn,ltv=90,notes='JN Home Loan for purchase or construction of residence. Published financing up to 90%. Undated source: request a current quote; other mortgage purposes have different rates.')
for kind,lo,hi in [('New vehicle',8.50,11.75),('Used vehicle',10.10,14.75),('Personal unsecured',18,24.99),('Home mortgage',8.50,12.49)]:
 product('Scotiabank Jamaica',kind,lo,hi,'scotia_rates','APR/EAIR as labelled by bank; contract basis to confirm',notes='Range depends on term and security. APR/EAIR label is not treated as a verified nominal contract rate. No expired dealer promotions used.')
product('First Global Bank','Used vehicle',8.95,None,'fgb_used','Per annum; compounding convention not specified',84,ltv=95,employment='Permanent employment required',docs='Permanent employment; vehicle invoice; personal use; 12 months comprehensive insurance. Vehicles up to 7 years old.',notes='Starting rate only; no published upper rate. Closing in first 2 years attracts one additional monthly loan payment. Full fees require quote.')
for kind,key in [('New vehicle','fgb_new'),('Personal unsecured','fgb_personal'),('Home mortgage','fgb_mortgage')]:product('First Global Bank',kind,source=key,notes='No verified numeric rate captured for this product. Ask for a current written quote; no rate inferred from another product.')
for kind in ['New vehicle','Used vehicle','Personal unsecured','Home mortgage']:
 term=120 if kind=='New vehicle' else 108 if kind=='Used vehicle' else 420 if kind=='Home mortgage' else 0
 product('JMMB Bank',kind,source='jmmb',term=term,ltv=95 if kind=='Home mortgage' else 100 if 'vehicle' in kind else 0,notes='Rate quote required. Mortgage maximum: 35 years or years to age 65; vehicle terms up to 10 years new / 9 years used. Borrower age and product conditions can shorten term.')
for kind in ['New vehicle','Used vehicle','Personal unsecured','Home mortgage']:product('NCB Jamaica',kind,source='ncb',notes='Rate quote required for the selected standard loan. Fee-based payday/digital products are excluded; no 0% rate assigned to fee-bearing products.')
terms=[12,24,36,48,60,72,84,96,108,120,180,240,300,360,420]
rows=[]
for p in products:
 for term in terms:
  for endpoint,rate in [('Low',p['Rate Low']),('High',p['Rate High'])]:rows.append({**p,'Term Months':term,'Term Key':f'{term:03}','Endpoint':endpoint,'Endpoint Order':1 if endpoint=='Low' else 2,'Rate':rate})
F={k:'real' if k in ['Rate Low','Rate High','Rate','Max Amount JMD','Max Financing Percent'] else 'integer' if k in ['Term Months','Endpoint Order','Max Term Months'] else 'string' for k in rows[0]}
with (P/'loans.csv').open('w',newline='',encoding='utf8') as f:w=csv.DictWriter(f,fieldnames=F);w.writeheader();w.writerows(rows)
(P/'schema.json').write_text(json.dumps(F,indent=2));(P/'products.json').write_text(json.dumps(products,indent=2,ensure_ascii=False),encoding='utf8')
assert len(products)==20 and len(rows)==600
assert sum(p['Rate Low'] is not None for p in products)==9
def payment(principal,annual,months,effective=False):
 r=(1+annual/100)**(1/12)-1 if effective else annual/1200
 return principal/months if r==0 else principal*r/(1-(1+r)**(-months))
assert abs(payment(1000000,0,60)-16666.6666667)<.001
assert abs(payment(1000000,12,12)-88848.7886783)<.01
assert payment(2000000,8.95,60)<payment(2000000,10.74,60)<payment(2000000,14.75,60)
assert payment(1000000,12,60,True)<payment(1000000,12,60)
checks={'products':20,'banks':5,'types':4,'products_with_numeric_rates':9,'products_needing_quote':11,'rows':600,'reviewed':'2026-11-21','default_used_vehicle_payment_JMD':{p['Bank']:round(payment(2000000,p['Rate Low'],60),2) for p in products if p['Loan Type']=='Used vehicle' and p['Rate Low'] is not None},'calculation_checks':'passed','source_scope':'Published webpages retrieved; no assurance of current bank offer; source dates often unspecified'}
(P/'validation.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
