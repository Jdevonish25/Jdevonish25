from pathlib import Path
import csv,json,copy,sys,zipfile,base64,xml.etree.ElementTree as E
P=Path(__file__).parent
F=json.loads((P/'schema.json').read_text()); V=json.loads((P/'validation.json').read_text())
data=list(csv.DictReader((P/'courtside.csv').open(encoding='utf-8')))
BG='#EDF1F6'; CARD='#FFFFFF'; INK='#17243A'; MUTED='#53677D'; NAVY='#111A2B'; ORANGE='#E88334'; CYAN='#147DAD'; PALE='#E0EBF5'; LINE='#D8E2EE'
def el(p,t,text=None,**a):
 q=E.SubElement(p,t,{k.replace('_','-'):str(v) for k,v in a.items()})
 if text is not None:q.text=str(text)
 return q
root=E.Element('workbook',{'source-platform':'win','version':'18.1','source-build':'2026.3.0 (20263.26.1022.1645)'})
m=el(root,'document-format-change-manifest')
for n in ['IntuitiveSorting','IntuitiveSorting_SP2']:el(m,n)
datas=el(root,'datasources');params=el(datas,'datasource',name='Parameters',hasconnection='false',inline='true',version='18.1');el(params,'aliases',enabled='yes')
def parameter(name,values,default,caption=None):
 col=el(params,'column',caption=caption or name,datatype='string',name=f'[{name}]',param_domain_type='list',role='measure',type='nominal',value=json.dumps(default,ensure_ascii=False))
 el(col,'calculation',**{'class':'tableau','formula':json.dumps(default,ensure_ascii=False)})
 mem=el(col,'members')
 for v in values:el(mem,'member',value=json.dumps(v,ensure_ascii=False))
 return col
parameter('Season',V['seasons'],'2026-27','Season')
parameter('Phase',['Regular Season','Playoffs'],'Regular Season','Competition')
parameter('Metric',['Points / game','Rebounds / game','Assists / game','Threes / game'],'Points / game','Leaderboard metric')
pn=sorted({r['Player'] for r in data if r['Record Type']=='Player'})
parameter('Player A',pn,'Luka Dončić','Player A')
parameter('Player B',pn,'Shai Gilgeous-Alexander','Player B')
ds=el(datas,'datasource',name='courtside',caption='NBA Courtside | validated season snapshots',inline='true',version='18.1')
cn=el(ds,'connection',**{'class':'federated'});nc=el(el(cn,'named-connections'),'named-connection',name='textscan.courtside',caption='courtside')
el(nc,'connection',**{'class':'textscan','directory':'','filename':'courtside.csv','server':'','workgroup-auth-mode':'as-is'})
rel=el(cn,'relation',name='courtside.csv',table='[courtside#csv]',type='table',connection='textscan.courtside');cols=el(rel,'columns',header='yes',separator=',',character_set='UTF-8',locale='en_US');md=el(cn,'metadata-records')
for i,(n,t) in enumerate(F.items()):
 el(cols,'column',name=n,datatype=t,ordinal=i);rec=el(md,'metadata-record',**{'class':'column'})
 for tag,val in [('remote-name',n),('remote-type',129 if t=='string' else 20 if t=='integer' else 5),('local-name',f'[{n}]'),('parent-name','[courtside.csv]'),('remote-alias',n),('ordinal',i),('local-type',t),('aggregation','Count' if t=='string' else 'Sum'),('contains-null','false')]:el(rec,tag,val)
el(ds,'aliases',enabled='yes')
for n,t in F.items():el(ds,'column',name=f'[{n}]',datatype=t,role='dimension' if t=='string' else 'measure',type='nominal' if t=='string' else 'quantitative')
C={}
def calc(n,t,f,fmt=None,dim=False):C[n]=(t,f,fmt,dim)
calc('Scope','string',"IF [Season]=[Parameters].[Season] AND [Phase]=[Parameters].[Phase] THEN 'Yes' ELSE 'No' END",dim=True)
calc('Phase Scope','string',"IF [Phase]=[Parameters].[Phase] THEN 'Yes' ELSE 'No' END",dim=True)
calc('Compare Scope','string',"IF [Player]=[Parameters].[Player A] OR [Player]=[Parameters].[Player B] THEN 'Yes' ELSE 'No' END",dim=True)
calc('A Scope','string',"IF [Player]=[Parameters].[Player A] THEN 'Yes' ELSE 'No' END",dim=True)
calc('B Scope','string',"IF [Player]=[Parameters].[Player B] THEN 'Yes' ELSE 'No' END",dim=True)
calc('Side','string',"IF [Player]=[Parameters].[Player A] THEN 'A' ELSE 'B' END",dim=True)
calc('Player Label','string',"LEFT([Player],1)+'. '+MID([Player],FIND([Player],' ')+1)",dim=True)
calc('Metric Rank','integer',"CASE [Parameters].[Metric] WHEN 'Points / game' THEN [Rank Points] WHEN 'Rebounds / game' THEN [Rank Rebounds] WHEN 'Assists / game' THEN [Rank Assists] ELSE [Rank 3P Made] END",'n0')
calc('Hero Slot','string','STR([Metric Rank])',dim=True)
calc('Top Twelve','string',"IF [Leader Eligible]='Yes' AND [Metric Rank]>=1 AND [Metric Rank]<=12 THEN 'Yes' ELSE 'No' END",dim=True)
calc('PPG','real','IF SUM([Games])>0 THEN SUM([Points])/SUM([Games]) END','n0.0')
calc('RPG','real','IF SUM([Games])>0 THEN SUM([Rebounds])/SUM([Games]) END','n0.0')
calc('APG','real','IF SUM([Games])>0 THEN SUM([Assists])/SUM([Games]) END','n0.0')
calc('3PM PG','real','IF SUM([Games])>0 THEN SUM([3P Made])/SUM([Games]) END','n0.0')
calc('Minutes PG','real','IF SUM([Games])>0 THEN SUM([Minutes])/SUM([Games]) END','n0.0')
calc('TS','real','IF SUM([FG Attempts])+.44*SUM([FT Attempts])>0 THEN SUM([Points])/(2*(SUM([FG Attempts])+.44*SUM([FT Attempts]))) END','p0.0%')
calc('eFG','real','IF SUM([FG Attempts])>0 THEN (SUM([FG Made])+.5*SUM([3P Made]))/SUM([FG Attempts]) END','p0.0%')
calc('3P Share','real','IF SUM([FG Attempts])>0 THEN SUM([3P Attempts])/SUM([FG Attempts]) END','p0.0%')
calc('3P Accuracy','real','IF SUM([3P Attempts])>0 THEN SUM([3P Made])/SUM([3P Attempts]) END','p0.0%')
calc('Win Pct','real','IF SUM([Games])>0 THEN SUM([Wins])/SUM([Games]) END','p0.0%')
calc('Offense','real','IF SUM([Possessions])>0 THEN 100*SUM([Points])/SUM([Possessions]) END','n0.0')
calc('Defense','real','IF SUM([Opponent Possessions])>0 THEN 100*SUM([Opponent Points])/SUM([Opponent Possessions]) END','n0.0')
calc('Net Rating','real','[Offense]-[Defense]','n0.0')
calc('Pace','real','IF SUM([Games])>0 THEN SUM([Pace Weighted])/SUM([Games]) END','n0.0')
calc('Games Played','real','SUM([Games])/2','n0')
calc('Metric Value','real',"CASE [Parameters].[Metric] WHEN 'Points / game' THEN [PPG] WHEN 'Rebounds / game' THEN [RPG] WHEN 'Assists / game' THEN [APG] ELSE [3PM PG] END",'n0.0')
calc('Hero Value','string',"'#'+STR(MIN([Metric Rank]))+'  |  '+STR(ROUND([Metric Value],1))+' / game'")
calc('Hero Context','string',"ATTR([Season])+' / '+ATTR([Phase])+' / '+[Parameters].[Metric]")
calc('Season Context','string',"ATTR([Season])+'  /  '+ATTR([Phase])+IF ATTR([Season])='2026-27' THEN '  /  IN PROGRESS' ELSE '  /  COMPLETED' END")
calc('A Name','string','ATTR([Player])')
calc('B Name','string','ATTR([Player])')
calc('Player Detail','string',"STR(SUM([Games]))+' games  |  '+STR(ROUND([Minutes PG],1))+' min/game  |  Team: '+ATTR([Team])")
calc('Selection Note','string',"IF [Parameters].[Season]='2026-27' AND [Parameters].[Phase]='Playoffs' THEN 'No 2026–27 playoff observations yet. Choose a completed season.' ELSE 'Selected '+[Parameters].[Season]+' '+[Parameters].[Phase]+'. Player figures are per appearance; league scoring is per team-game.' END")
calc('Leader Story','string',"'LEADERBOARD / '+[Parameters].[Metric]+CHAR(10)+MAX(IF [Metric Rank]=1 THEN [Player] END)+' leads this exploratory pool at '+STR(ROUND(MAX(IF [Metric Rank]=1 THEN CASE [Parameters].[Metric] WHEN 'Points / game' THEN [Points]/[Games] WHEN 'Rebounds / game' THEN [Rebounds]/[Games] WHEN 'Assists / game' THEN [Assists]/[Games] ELSE [3P Made]/[Games] END END),1))+'.'")
calc('A Career Scope','string',"IF [Player]=[Parameters].[Player A] THEN 'Yes' ELSE 'No' END",dim=True)
calc('B Career Scope','string',"IF [Player]=[Parameters].[Player B] THEN 'Yes' ELSE 'No' END",dim=True)
calc('Season Status','string',"IF [Season]='2026-27' THEN 'In progress' ELSE 'Completed' END",dim=True)
for n,(t,f,fmt,dim) in C.items():
 col=el(ds,'column',name=f'[{n}]',datatype=t,role='dimension' if dim else 'measure',type='nominal' if t=='string' else 'quantitative')
 if fmt:col.set('default-format',fmt)
 if n in {'Metric Value','Win Pct','Offense','Defense','PPG','RPG','APG','TS','3P Share','3P Accuracy'}:col.set('caption',{'Metric Value':'Per game','Win Pct':'Win percentage','Offense':'Points scored / 100 possessions','Defense':'Points allowed / 100 possessions','PPG':'Points / game','RPG':'Rebounds / game','APG':'Assists / game','TS':'True shooting','3P Share':'3PA share','3P Accuracy':'3P accuracy'}[n])
 el(col,'calculation',**{'class':'tableau','formula':f})
def isdim(n):return F.get(n)=='string' or n in C and C[n][3]
def ref(n,der=None):
 der=der or ('none' if isdim(n) else 'usr' if n in C else 'sum')
 return f'[courtside].[{der}:{n}:{"nk" if F.get(n)=="string" or C.get(n,(None,))[0]=="string" else "qk"}]'
def inst(n):return ref(n).split('[courtside].')[1]
def params_dep(parent):
 dep=el(parent,'datasource-dependencies',datasource='Parameters')
 for col in params.findall('column'):dep.append(copy.deepcopy(col))
def category(v,n,values):
 g=el(el(v,'filter',**{'class':'categorical','column':ref(n)}),'groupfilter',function='union')
 for val in values:el(g,'groupfilter',function='member',level=inst(n),member=json.dumps(val,ensure_ascii=False))
works=el(root,'worksheets');names=[];dsstyle=el(ds,'style');dsmark=el(dsstyle,'style-rule',element='mark');colorfields=set()
def sheet(name,measure='PPG',dim='Player',mark='Bar',kind='Player',scope=True,phase=True,extra=None,rows=None,cols=None,color=ORANGE,series=None,size=None,labels=True,sort=False,textsize=10):
 names.append(name);w=el(works,'worksheet',name=name);el(el(el(w,'layout-options'),'title'),'formatted-text');table=el(w,'table');v=el(table,'view');sources=el(v,'datasources');el(sources,'datasource',name='courtside',caption=ds.get('caption'));params_dep(v)
 dep=el(v,'datasource-dependencies',datasource='courtside')
 for col in ds.findall('column'):dep.append(copy.deepcopy(col))
 for n in list(F)+list(C):
  q=inst(n);der=q[1:].split(':')[0];el(dep,'column-instance',column=f'[{n}]',derivation={'none':'None','sum':'Sum','usr':'User'}[der],name=q,pivot='key',type='nominal' if q.endswith(':nk]') else 'quantitative')
 for n,t in F.items():
  if t=='string':el(dep,'column-instance',column=f'[{n}]',derivation='Attribute',name=f'[attr:{n}:nk]',pivot='key',type='nominal')
 filters={'Record Type':[kind]}
 if scope:filters['Scope']=['Yes']
 elif phase:filters['Phase Scope']=['Yes']
 filters.update(extra or {})
 for n,values in filters.items():category(v,n,values)
 rr=rows if rows is not None else '' if mark=='Text' else ref(measure) if mark in ['Line','Area'] else ref(dim)
 cc=cols if cols is not None else '' if mark=='Text' else ref(dim) if mark in ['Line','Area'] else ref(measure)
 if sort:el(el(v,'shelf-sorts'),'shelf-sort-v2',dimension_to_sort=rr,direction='DESC',is_on_innermost_dimension='true',measure_to_sort_by=cc,shelf='rows')
 slices=el(v,'slices')
 for n in filters:el(slices,'column',ref(n))
 el(v,'aggregation',value='true');style=el(table,'style')
 for e,formats in [('worksheet',{'font-family':'Tableau Book','font-size':'10','color':INK,'background-color':CARD,'display-field-labels':'false'}),('pane',{'background-color':CARD}),('cell',{'background-color':CARD,'color':INK}),('header',{'color':MUTED,'font-size':'10'}),('axis',{'color':MUTED,'font-size':'10'}),('gridline',{'stroke-size':'0'}),('zeroline',{'stroke-size':'1','stroke-color':LINE})]:
  st=el(style,'style-rule',element=e)
  for a,b in formats.items():el(st,'format',attr=a,value=b)
 if dim=='Player' and mark!='Text':el(el(style,'style-rule',element='cell'),'format',attr='width',field=ref('Player'),value='230')
 if mark=='Circle':
  ax=el(style,'style-rule',element='axis')
  for fld,scp in [(rr,'rows'),(cc,'cols')]:
   lo,hi=(85,130) if measure=='Offense' else ((.25,.45) if scp=='rows' else (.10,.60))
   el(ax,'encoding',attr='space',field=fld,scope=scp,**{'class':'0','field-type':'quantitative','range-type':'fixed','min':lo,'max':hi,'type':'space'})
 pane=el(el(table,'panes'),'pane',selection_relaxation_option='selection-relaxation-allow');pv=el(pane,'view');el(pv,'breakdown',value='auto');el(pane,'mark',**{'class':mark});enc=el(pane,'encodings')
 if mark=='Text' or labels:el(enc,'text',column=ref(measure))
 if mark=='Line':el(enc,'path',column=ref(dim))
 if mark=='Circle':el(enc,'lod',column=ref(dim))
 if size:el(enc,'size',column=ref(size))
 if series:
  el(enc,'color',column=ref(series))
  if series not in colorfields:
   ce=el(dsmark,'encoding',attr='color',field=inst(series),type='palette')
   colors={'Conference':{'East':ORANGE,'West':CYAN},'Side':{'A':ORANGE,'B':CYAN},'Coverage':{'COMPLETED':CYAN,'IN PROGRESS':ORANGE}}.get(series,{})
   for val,col in colors.items():el(el(ce,'map',to=col),'bucket',json.dumps(val))
   colorfields.add(series)
 for n in ['Player','Team','Season','Phase','Coverage']:el(enc,'tooltip',column=f'[courtside].[attr:{n}:nk]')
 for n in ['PPG','RPG','APG','Games','TS','3P Share','Offense','Defense']:el(enc,'tooltip',column=ref(n))
 tip='NBA Courtside | '+kind+' season snapshot\nSeason: <[courtside].[attr:Season:nk]> | <[courtside].[attr:Phase:nk]>\nPlayer: <[courtside].[attr:Player:nk]> | Team: <[courtside].[attr:Team:nk]>\nPoints/game: <'+ref('PPG')+'> | Rebounds/game: <'+ref('RPG')+'> | Assists/game: <'+ref('APG')+'>\nAppearances / team-games: <'+ref('Games')+'>\nTS%: <'+ref('TS')+'> | 3PA share: <'+ref('3P Share')+'>\nStatus: <[courtside].[attr:Coverage:nk]>\nSource: NBA.com Stats via llimllib/nba_data. Snapshot through 20 Nov 2026.'
 el(el(el(pane,'customized-tooltip'),'formatted-text'),'run',tip,fontsize=10,fontcolor=INK)
 if mark=='Text' or labels:el(el(el(pane,'customized-label'),'formatted-text'),'run','<'+ref(measure)+'>',fontsize=textsize,fontname='Tableau Semibold' if textsize>=18 else 'Tableau Book',fontcolor=INK)
 st=el(el(pane,'style'),'style-rule',element='mark')
 for a,b in {'mark-color':color,'mark-transparency':'230','size':'.7' if mark=='Circle' else '.6','has-stroke':'false','mark-labels-show':'true' if labels or mark=='Text' else 'false'}.items():el(st,'format',attr=a,value=b)
 el(table,'rows',rr);el(table,'cols',cc)
 return w

for name,measure in [('League PPG','PPG'),('League 3PA','3P Share'),('League Pace','Pace'),('League Games','Games Played')]:sheet(name,measure,mark='Text',kind='League',textsize=30)
sheet('Context','Season Context',mark='Text',kind='League',textsize=13)
sheet('Selection Note','Selection Note',mark='Text',kind='League',textsize=11)
sheet('Leaders','Metric Value',dim='Player Label',extra={'Top Twelve':['Yes']},series='Conference',sort=True)
sheet('Leader Story','Leader Story',mark='Text',extra={'Top Twelve':['Yes']},textsize=16)
sheet('Team Wins','Win Pct','Team',kind='Team',sort=True,series='Conference',textsize=10,extra={'Team Top Fifteen':['Yes']})
sheet('Team Attack','Offense','Team',kind='Team',rows=ref('Defense'),cols=ref('Offense'),mark='Circle',size='Win Pct',series='Conference',labels=False)
sheet('Team Net','Net Rating','Team',kind='Team',sort=True,series='Conference',textsize=10,extra={'Team Top Fifteen':['Yes']})
sheet('Team Shots','3P Share','Team',kind='Team',rows=ref('3P Accuracy'),cols=ref('3P Share'),mark='Circle',series='Conference',size='3P Attempts',labels=False)
sheet('Team Scoring','PPG','Team',kind='Team',sort=True,series='Conference',textsize=10,extra={'Team Top Fifteen':['Yes']})
for tag,side in [('A','A Scope'),('B','B Scope')]:
 sheet(tag+' Name',tag+' Name',mark='Text',extra={side:['Yes']},textsize=21)
 sheet(tag+' PPG','PPG',mark='Text',extra={side:['Yes']},textsize=34)
 sheet(tag+' Detail','Player Detail',mark='Text',extra={side:['Yes']},textsize=11)
for name,measure in [('Compare Points','PPG'),('Compare Boards','RPG'),('Compare Assists','APG'),('Compare TS','TS')]:sheet(name,measure,dim='Side',rows=ref(measure),cols=ref('Side'),extra={'Compare Scope':['Yes']},series='Side',textsize=10)
sheet('Career Compare','PPG','Season',scope=False,extra={'Compare Scope':['Yes']},mark='Line',series='Side',labels=False)
for name,measure in [('Era Scoring','PPG'),('Era Threes','3P Share'),('Era Pace','Pace'),('Era Accuracy','3P Accuracy')]:sheet(name,measure,'Season',kind='League',scope=False,mark='Line',labels=False,textsize=9)

# Each portrait is a real filtered mark, using the same precomputed rank as the leaderboard.
shape_encoding=el(dsmark,'encoding',attr='shape',field=inst('Player ID'),type='shape',palette='NBA')
for portrait in sorted((P/'portraits').glob('*.png')):
 el(el(shape_encoding,'map',to='NBA/'+portrait.name),'bucket',json.dumps(portrait.stem))
for slot in range(1,6):
 w=sheet('Starting Five '+str(slot),dim='Player ID',mark='Shape',rows='',cols='',extra={'Hero Slot':[str(slot)],'Leader Eligible':['Yes']},labels=False)
 enc=w.find('./table/panes/pane/encodings');el(enc,'shape',column=ref('Player ID'))
 for st in w.findall('./table/style/style-rule'):
  if st.get('element') in ['worksheet','pane','cell']:
   for fmt in st.findall('format'):
    if fmt.get('attr')=='background-color':fmt.set('value',NAVY)
 for fmt in w.findall('./table/panes/pane/style/style-rule/format'):
  if fmt.get('attr')=='size':fmt.set('value','2.4')
 w=sheet('Starting Value '+str(slot),'Hero Value',mark='Text',extra={'Hero Slot':[str(slot)],'Leader Eligible':['Yes']},textsize=11)
 for st in w.findall('./table/style/style-rule'):
  for fmt in st.findall('format'):
   if fmt.get('attr')=='background-color':fmt.set('value',NAVY)
 w.find('./table/panes/pane/customized-label/formatted-text/run').set('fontcolor','#F5A45D')
w=sheet('Starting Context','Hero Context',mark='Text',kind='League',textsize=10)
for st in w.findall('./table/style/style-rule'):
 for fmt in st.findall('format'):
  if fmt.get('attr')=='background-color':fmt.set('value',NAVY)
w.find('./table/panes/pane/customized-label/formatted-text/run').set('fontcolor','#C3CFDE')

boards=el(root,'dashboards');used={};base=None;current=None;W=1440;H=1240
def zone(x,y,w,h,kind=None,text=None,font=11,fg=INK,bg=CARD,name=None,**extra):
 q=el(base,'zone',h=round(h/H*100000),w=round(w/W*100000),x=round(x/W*100000),y=round(y/H*100000),id=len(base)+1,is_floating='true',**extra)
 if kind:q.set('type-v2',kind)
 if name:q.set('name',name);used[current].append(name)
 if text is not None:el(el(q,'formatted-text'),'run',text,fontname='Tableau Semibold' if font>=14 else 'Tableau Book',fontsize=font,fontcolor=fg)
 st=el(q,'zone-style')
 for a,b in {'background-color':bg,'border-style':'none','padding':'0' if kind in ['text','empty','bitmap'] else '6','margin':'0'}.items():el(st,'format',attr=a,value=b)
 return q
def txt(t,x,y,w,h,font=11,fg=MUTED,bg=BG):return zone(x,y,w,h,'text',text=t,font=font,fg=fg,bg=bg)
def image(file,x,y,w,h):return zone(x,y,w,h,'bitmap',param='Image/'+file,is_scaled='1',is_centered='1',bg=NAVY)
def control(n,x,y,w):return zone(x,y,w,58,'paramctrl',param=f'[Parameters].[{n}]',mode='compact',bg=CARD)
def dash(name,subtitle,players=False,metric=False,era=False,height=1240):
 global base,current,H
 H=height
 current=name;used[name]=[];d=el(boards,'dashboard',name=name);el(d,'style');el(d,'size',minwidth='1100',maxwidth='1600',minheight=H,maxheight=H)
 el(el(d,'datasources'),'datasource',name='Parameters');params_dep(d)
 base=el(el(d,'zones'),'zone',id=0,x=0,y=0,w=100000,h=100000,type_v2='layout-basic');zone(0,0,W,H,'empty',bg=BG)
 if name=='01 Courtside':
  image('hero-dynamic.png',0,0,1440,243)
  for slot in range(1,6):
   zone(530+(slot-1)*176,8,174,194,name='Starting Five '+str(slot),show_title='false',bg=NAVY)
   zone(530+(slot-1)*176,202,174,32,name='Starting Value '+str(slot),show_title='false',bg=NAVY)
  zone(28,203,490,35,name='Starting Context',show_title='false',bg=NAVY)
 else:image('hero.png',0,0,1440,243)
 txt(subtitle,28,253,1384,42,13,INK)
 if not era:control('Season',28,307,220)
 control('Phase',268 if not era else 28,307,230)
 if metric:control('Metric',518,307,330)
 if players:control('Player A',518,307,432);control('Player B',970,307,442)
 if not players and not era:zone(878,309,534,53,name='Context',show_title='false')
 if era:txt('Trend charts always span all 13 seasons. Competition selector applies to every chart.',290,319,1120,37,11,MUTED)
 txt('NBA.com statistics via llimllib/nba_data | Games through 20 Nov 2026 | 2026–27 partial | NBA.com portraits | Unofficial fan portfolio',28,H-48,1384,25,8,MUTED)
 txt('TABS: 01 Courtside  •  02 Matchup Lab  •  03 Team Identity  •  04 Evolution  •  05 Start Here',28,H-20,1384,18,8,MUTED)
 return d
def panel(name,x,y,w,h,title,sub):
 zone(x,y,w,h,'empty');zone(x,y,w,3,'empty',bg=ORANGE);txt(title,x+15,y+14,w-30,29,15,INK,CARD);txt(sub,x+15,y+49,w-30,43,10,MUTED,CARD);zone(x+8,y+96,w-16,h-104,name=name,show_title='false')
def cards(items,y=387):
 for i,(name,title,cap) in enumerate(items):
  x=28+350*i;zone(x,y,334,114,'empty');txt(title,x+13,y+10,308,25,10,MUTED,CARD);zone(x+4,y+36,326,49,name=name,show_title='false');txt(cap,x+13,y+86,308,23,9,MUTED,CARD)

dash('01 Courtside','THE LEAGUE AT A GLANCE  /  Choose a season, competition and leaderboard metric. Rates use the selected snapshot.',metric=True)
cards([('League PPG','POINTS PER TEAM / GAME','Total points ÷ team appearances'),('League 3PA','SHOTS FROM BEYOND THE ARC','Three-point attempts ÷ all field-goal attempts'),('League Pace','POSSESSIONS / 48 MINUTES','Average source pace across team-games'),('League Games','NBA GAMES IN THE SNAPSHOT','Each game counted once')])
panel('Leaders',28,521,852,432,'01 / Who is setting the pace?','Top 12 with ≥5 appearances and ≥15 minutes/game. Exploratory pool, not official NBA leader qualification.')
panel('Team Wins',900,521,512,432,'02 / The win column','Top 15 by win percentage. Orange = East; blue = West.')
zone(28,975,852,175,'empty',bg=PALE);zone(44,991,820,72,name='Leader Story',show_title='false',bg=PALE)
txt('Compare volume with efficiency and availability in Matchup Lab. One scoring figure is not an all-around player ranking.',44,1076,820,60,11,MUTED,PALE)
zone(900,975,512,175,'empty',bg=NAVY);txt('READ BEFORE THE HOT TAKE',918,991,476,28,12,'#F5A45D',NAVY);txt('2026–27 is still in progress.\nPlayoffs are a separate competition.\nGo to Start Here for definitions.',918,1038,476,92,12,'#E4ECF7',NAVY)

dash('02 Matchup Lab','PLAYER MATCHUP LAB  /  Choose two players and the same season. Photos celebrate the era; selected names below identify the statistics.',players=True,height=1400)
for tag,x,col in [('A',28,ORANGE),('B',732,CYAN)]:
 zone(x,387,680,156,'empty');zone(x,387,680,4,'empty',bg=col);zone(x+12,401,656,45,name=tag+' Name',show_title='false');zone(x+12,448,200,55,name=tag+' PPG',show_title='false');txt('POINTS / GAME',x+230,465,425,32,11,MUTED,CARD);zone(x+12,506,656,26,name=tag+' Detail',show_title='false')
panel('Compare Points',28,563,680,206,'Scoring','Points per appearance. Orange = A; blue = B.')
panel('Compare Boards',732,563,680,206,'Rebounding','Rebounds per appearance. Compare roles and minutes too.')
panel('Compare Assists',28,789,680,206,'Playmaking','Assists per appearance; turnovers are available in the data.')
panel('Compare TS',732,789,680,206,'Scoring efficiency','TS% = PTS ÷ [2 × (FGA + 0.44 × FTA)]. Estimated free-throw weighting.')
panel('Career Compare',28,1015,1384,313,'The scoring arc across this era','All seasons in the selected competition. Orange = A; blue = B. Missing seasons are not zero.')

dash('03 Team Identity','TEAM IDENTITY  /  Compare results, scoring efficiency and shot selection. Hover over a point for the team and context.')
panel('Team Attack',28,387,852,378,'01 / Offense meets defense','X: points scored/100 possessions. Y: points allowed/100. LOWER-RIGHT is stronger; bubble size = win%.')
panel('Team Net',900,387,512,378,'02 / Net points per 100','Top 15 by win%. Offense minus defense; positive is better.')
panel('Team Shots',28,785,852,389,'03 / The three-point bet','X: share of shots from three. Y: three-point accuracy. Bubble size = attempts; color = conference.')
panel('Team Scoring',900,785,512,389,'04 / Scoreboard pressure','Top 15 by win%. Points per team-game; consider pace too.')

dash('04 Evolution','HOW BASKETBALL CHANGED  /  A 13-season view of scoring, pace and the three-point shot. Read rates rather than unequal season totals.',era=True)
panel('Era Scoring',28,387,680,345,'01 / More points on the board','League points per team-game; not the average of player scoring averages.')
panel('Era Threes',732,387,680,345,'02 / Beyond the arc','Share of all field-goal attempts that are threes. Ratio of total attempts.')
panel('Era Pace',28,752,680,345,'03 / How fast is the game?','Average source pace, possessions per 48 minutes. Playoff mixes differ by season.')
panel('Era Accuracy',732,752,680,345,'04 / Volume versus precision','Three-point makes ÷ attempts. Current-season observations remain provisional.')
txt('Rates help comparison across shortened seasons, but do not remove roster, rule, schedule or playoff-opponent differences. These trends do not establish causes.',28,1119,1384,48,11,MUTED)

dash('05 Start Here','START HERE  /  Understand what the dashboard measures before comparing players, teams or eras.',era=True)
def block(x,y,w,h,title,body):
 zone(x,y,w,h,'empty');txt(title,x+17,y+15,w-34,35,16,INK,CARD);txt(body,x+17,y+65,w-34,h-79,12,MUTED,CARD)
block(28,387,680,237,'01 / Real basketball, clearly scoped','NBA.com Stats, accessed through Larry’s public nba_data mirror.\n13 seasons: 2014–15 through 2026–27. Snapshot through 20 Nov 2026.\nRegular season and playoffs are separate. Preseason, All-Star,\nplay-in and NBA Cup final game IDs are excluded from team totals.')
block(732,387,680,237,'02 / Choose the right counting unit','Player: one player × season × competition, season totals.\nTeam: one team × season × competition, aggregated team-games.\nLeague: totals of team records; two team appearances per game.\nPlayer records are never summed together with team records.')
block(28,644,680,237,'03 / Make a fair player comparison','Per-game figures divide by that player’s appearances, not team games.\nLeaderboard pool: ≥5 games and ≥15 minutes/game. This is not\nofficial NBA qualification. Matchup Lab has no eligibility threshold.\nTraded players retain season totals; team labels show their last team.')
block(732,644,680,237,'04 / Metrics in plain basketball language','3PA share: three-point attempts ÷ field-goal attempts.\nTS% estimates scoring efficiency using 0.44 × free-throw attempts.\nOffense / defense: points per 100 source possessions.\nNet rating is their difference; pace is possessions per 48 minutes.')
block(28,901,680,273,'05 / Use the controls with confidence','Season and competition parameters update the analytical pages.\nEvolution ignores the season selection and shows the full era.\nChoose Player A and B to compare the same season; career lines\nspan all seasons in the selected competition. A blank means no\nrecord, not zero production. Current-season playoffs have no data.\nRevert on the Tableau toolbar restores the published defaults.')
block(732,901,680,273,'06 / Trust, attribution and limitations','Player point totals reconcile to team totals in every season/phase.\nAll paired game margins and wins reconcile to final scores.\nNo simulated statistics, forecasts, salaries or betting advice.\nLatest NBA.com portraits are decorative, not historical jerseys.\nSource: nba.com/stats | mirror: github.com/llimllib/nba_data\nImages: NBA.com. Unofficial fan analytics; no NBA endorsement.')

windows=el(root,'windows',**{'source-height':'30'})
for i,d in enumerate(boards):
 w=el(windows,'window',**{'class':'dashboard','name':d.get('name'),'maximized':'true' if i==0 else 'false'});vp=el(w,'viewpoints')
 for n in used[d.get('name')]:el(el(vp,'viewpoint',name=n),'zoom',type='entire-view')
 el(w,'active',id='-1')
for n in names:
 w=el(windows,'window',**{'class':'worksheet','name':n,'hidden':'true'});cards=el(w,'cards');left=el(el(cards,'edge',name='left'),'strip',size=160)
 for ct in ['pages','filters','marks']:el(left,'card',type=ct)
 top=el(cards,'edge',name='top')
 for ct in ['columns','rows','title']:el(el(top,'strip',size=26),'card',type=ct)
 el(el(w,'viewpoint'),'zoom',type='entire-view')
el(root,'thumbnails')
shapes=el(el(root,'external'),'shapes')
for portrait in sorted((P/'portraits').glob('*.png')):el(shapes,'shape',base64.b64encode(portrait.read_bytes()).decode(),name='NBA/'+portrait.name)
sys.path.insert(0,str(P.parents[1]/'work/tableau_runtime'))
from tableauhyperapi import HyperProcess,Telemetry,Connection,CreateMode,TableDefinition,TableName,SqlType,Inserter
hyper=P/'courtside.hyper';td=TableDefinition(TableName('Extract','Extract'),[TableDefinition.Column(n,SqlType.text() if t=='string' else SqlType.big_int() if t=='integer' else SqlType.double()) for n,t in F.items()])
with HyperProcess(Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as hp:
 with Connection(hp.endpoint,str(hyper),CreateMode.CREATE_AND_REPLACE) as conn:
  conn.catalog.create_schema('Extract');conn.catalog.create_table(td)
  with Inserter(conn,td) as ins:ins.add_rows([[r[n] if t=='string' else int(r[n]) if t=='integer' else float(r[n]) for n,t in F.items()] for r in data]);ins.execute()
  assert conn.execute_scalar_query('SELECT COUNT(*) FROM "Extract"."Extract"')==10153
ex=el(ds,'extract',count='-1',enabled='true',units='records');cx=el(ex,'connection',authentication='auth-none',author_locale='en_US',**{'class':'hyper','dbname':'Data/Extracts/courtside.hyper','default-settings':'yes','schema':'Extract','tablename':'Extract'});el(cx,'relation',name='Extract',table='[Extract].[Extract]',type='table');emd=copy.deepcopy(md)
for rec in emd:rec.find('parent-name').text='[Extract]'
cx.append(emd)
for n in colorfields|{'Player ID'}:el(ds,'column-instance',column=f'[{n}]',derivation='None',name=inst(n),pivot='key',type='nominal')
ds.remove(ex);ds.append(ex);ds.remove(dsstyle);ds.append(dsstyle);E.indent(root)
out=P/'NBA Courtside - The Modern Era.twbx'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('NBA Courtside - The Modern Era.twb',E.tostring(root,encoding='utf-8',xml_declaration=True));z.write(hyper,'Data/Extracts/courtside.hyper');z.write(P/'courtside.csv','courtside.csv')
 for im in (P/'images').glob('*.png'):z.write(im,'Image/'+im.name)
(P/'calculated-fields.json').write_text(json.dumps(C,indent=2));print('Built',len(names),'worksheets and',len(boards),'dashboards:',out)
