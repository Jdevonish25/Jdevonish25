from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import urllib.request,json
from PIL import Image, ImageDraw, ImageFont,ImageOps
P=Path(__file__).parent;D=P/'images';D.mkdir(exist_ok=True)
people={'2544':'LeBron James','201939':'Stephen Curry','203999':'Nikola Jokić','1629029':'Luka Dončić','1628983':'Shai Gilgeous-Alexander','203507':'Giannis Antetokounmpo','1641705':'Victor Wembanyama','1628369':'Jayson Tatum'}
def fetch(i):
 u=f'https://cdn.nba.com/headshots/nba/latest/1040x760/{i}.png';f=D/f'{i}.png'
 if not f.exists():f.write_bytes(urllib.request.urlopen(u,timeout=25).read())
 Image.open(f).verify()
 return {'player':people[i],'url':u,'file':f.name}
with ThreadPoolExecutor(4) as ex:credits=list(ex.map(fetch,people))
(P/'image-credits.json').write_text(json.dumps({'source':'NBA.com headshots','note':'Portraits identify featured players; latest portraits do not represent historical team affiliation. Unofficial fan portfolio; no NBA endorsement.','images':credits},indent=2))
font=lambda n,b=False:ImageFont.truetype('C:/Windows/Fonts/'+('segoeuib.ttf' if b else 'segoeui.ttf'),n)
# A deliberately image-led hero, with real player photographs and a stylized court.
hero=Image.new('RGB',(1600,270),'#111A2B');d=ImageDraw.Draw(hero)
for x in range(1600):
 v=int(12+14*x/1600);d.line((x,0,x,270),fill=(v,v+8,v+19))
d.line((0,267,1600,267),fill='#F59B4D',width=5)
d.text((30,28),'NBA COURTSIDE',font=font(52,True),fill='white')
d.text((33,99),'THE MODERN ERA',font=font(23,True),fill='#F5A45D')
d.text((33,147),'Real numbers. Big names. Better basketball debates.',font=font(17),fill='#C3CFDE')
d.text((33,191),'2014–15 → 2026–27  |  JULIAN DEVONISH',font=font(15),fill='#95A7BE')
for j,i in enumerate(['2544','201939','1629029','1628983','203999']):
 im=Image.open(D/f'{i}.png').convert('RGBA');im.thumbnail((300,230));hero.paste(im,(570+j*180,260-im.height),im)
hero.save(D/'hero.png')
# Portrait montage is explicitly decorative: it never implies that filtered numbers belong to these faces.
court=Image.new('RGB',(780,300),'#172438');dc=ImageDraw.Draw(court);line='#36506D'
dc.rectangle((20,20,760,280),outline=line,width=3);dc.line((390,20,390,280),fill=line,width=3);dc.ellipse((330,90,450,210),outline=line,width=3)
for x in [20,640]:dc.rectangle((x,95,x+120,205),outline=line,width=3)
dc.arc((60,35,360,265),-90,90,fill=line,width=3);dc.arc((420,35,720,265),90,270,fill=line,width=3)
dc.text((225,132),'KNOW THE GAME.',font=font(25,True),fill='#F5A45D');court.save(D/'court.png')
print('Downloaded',len(credits),'portraits; created hero and court graphics.')
