from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import csv,json,urllib.request
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).parent;D=P/'images';S=P/'portraits';S.mkdir(exist_ok=True)
rows=list(csv.DictReader((P/'courtside.csv').open(encoding='utf-8')))
people={r['Player ID']:r['Player'] for r in rows if r['Record Type']=='Player' and any(0<int(r['Rank '+m])<=5 for m in ['Points','Rebounds','Assists','3P Made'])}
font=lambda n,b=False:ImageFont.truetype('C:/Windows/Fonts/'+('segoeuib.ttf' if b else 'segoeui.ttf'),n)
def fetch(item):
 i,name=item;u=f'https://cdn.nba.com/headshots/nba/latest/260x190/{i}.png';raw=D/f'{i}-small.png'
 if not raw.exists():
  try:raw.write_bytes(urllib.request.urlopen(u,timeout=30).read())
  except Exception as ex:return {'id':i,'player':name,'error':str(ex)}
 try:im=Image.open(raw).convert('RGBA')
 except Exception as ex:return {'id':i,'player':name,'error':str(ex)}
 card=Image.new('RGBA',(300,260),'#111A2B');im.thumbnail((300,219));card.alpha_composite(im,((300-im.width)//2,216-im.height));d=ImageDraw.Draw(card)
 words=name.split();lines=[name] if d.textlength(name,font=font(18,True))<=290 else [' '.join(words[:-1]),words[-1]]
 for j,line in enumerate(lines):d.text((150,219+j*21),line,font=font(18,True),anchor='mt',fill='#F5F8FF')
 card.save(S/f'{i}.png',optimize=True)
 return {'id':i,'player':name,'url':u,'file':f'portraits/{i}.png'}
with ThreadPoolExecutor(6) as pool:credits=list(pool.map(fetch,people.items()))
(P/'dynamic-portrait-credits.json').write_text(json.dumps(credits,indent=2))
errors=[r for r in credits if 'error'in r];print('Portraits:',len(credits),'errors:',errors)
assert not errors
# Title panel is separate from data-driven portrait sheets.
hero=Image.new('RGB',(1600,270),'#111A2B');d=ImageDraw.Draw(hero)
d.line((0,267,1600,267),fill='#F59B4D',width=5)
d.text((30,28),'NBA COURTSIDE',font=font(48,True),fill='white')
d.text((33,94),'THE MODERN ERA',font=font(22,True),fill='#F5A45D')
d.text((33,139),'THE STARTING FIVE',font=font(19,True),fill='#F5A45D')
d.text((33,173),'Top 5 in your selected leaderboard category',font=font(16),fill='#C3CFDE')
d.text((33,205),'2014–15 → 2026–27  |  JULIAN DEVONISH',font=font(14),fill='#95A7BE')
hero.save(D/'hero-dynamic.png')
