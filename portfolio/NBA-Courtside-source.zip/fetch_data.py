from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import urllib.request, json, hashlib, datetime
P=Path(__file__).parent
RAW=P/'raw'; RAW.mkdir(exist_ok=True)
base='https://basketball-data.billmill.org/nba/stats'
tables={'players':'player_season_stats','names':'player_seasons','teams':'team_seasons','games':'team_game_logs'}
def fetch(task):
    label,table,season=task
    url=f'{base}/{table}/season={season}/data.parquet'; f=RAW/f'{label}-{season}.parquet'
    if not f.exists(): f.write_bytes(urllib.request.urlopen(url,timeout=35).read())
    return dict(file=f.name,url=url,sha256=hashlib.sha256(f.read_bytes()).hexdigest(),bytes=f.stat().st_size)
tasks=[(l,t,y) for y in range(2015,2028) for l,t in tables.items()]
with ThreadPoolExecutor(4) as pool: manifest=list(pool.map(fetch,tasks))
(P/'sources.json').write_text(json.dumps({'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'origin':'NBA.com Stats','mirror':'Larry / llimllib nba_data','mirror_docs':'https://github.com/llimllib/nba_data/blob/main/docs/DATA_DICTIONARY.md','files':manifest},indent=2))
print('Downloaded',len(manifest),'files;',sum(x['bytes'] for x in manifest),'bytes')
