from pathlib import Path
import duckdb,json,csv,collections,datetime,hashlib
P=Path(__file__).parent; c=duckdb.connect()
def rows(label):
    paths=[str(x) for x in sorted((P/'raw').glob(label+'-*.parquet'))]
    q=c.sql('SELECT * FROM read_parquet(?,union_by_name=true,hive_partitioning=false)',params=[paths])
    names=[x[0] for x in q.description]
    return [dict(zip(names,r)) for r in q.fetchall()]
players=rows('players'); names={(r['season'],r['player_id']):r['name'] for r in rows('names')}; teams={(r['season'],r['team_id']):r for r in rows('teams')}
games=[r for r in rows('games') if r['game_id'][:3] in ['002','004'] and teams.get((r['season'],r['team_id']),{}).get('is_nba') and r['game_date']<=datetime.date(2026,11,20)]
lookup={(r['game_id'],r['team_id']):r for r in games}
assert len(lookup)==len(games)
assert all((r['game_id'],r['opp_team_id']) in lookup for r in games)
for r in games:
    other=lookup[r['game_id'],r['opp_team_id']]
    assert r['plus_minus']==r['pts']-other['pts']
    assert r['pts']!=other['pts']
    assert bool(r['win'])==(r['pts']>other['pts'])

fields={'Record Type':'string','Season':'string','Season End':'integer','Phase':'string','Player':'string','Player ID':'string','Team':'string','Team ID':'string','Conference':'string','Coverage':'string','Games':'integer','Wins':'integer','Minutes':'real','Points':'integer','Rebounds':'integer','Assists':'integer','Steals':'integer','Blocks':'integer','Turnovers':'integer','FG Made':'integer','FG Attempts':'integer','3P Made':'integer','3P Attempts':'integer','FT Made':'integer','FT Attempts':'integer','Possessions':'real','Opponent Points':'integer','Opponent Possessions':'real','Pace Weighted':'real','Age':'real','Player Team Count':'integer','Last Game':'string','Leader Eligible':'string'}
for stat in ['Points','Rebounds','Assists','3P Made']:fields['Rank '+stat]='integer'
fields['Team Top Fifteen']='string'
def new(kind,y,phase):
    return {**{n:'' if t=='string' else 0 for n,t in fields.items()},'Record Type':kind,'Season':f'{y-1}-{str(y)[2:]}','Season End':y,'Phase':phase,'Coverage':'IN PROGRESS' if y==2027 else 'COMPLETED'}
mapping={'gp':'Games','w':'Wins','min':'Minutes','pts':'Points','reb':'Rebounds','ast':'Assists','stl':'Steals','blk':'Blocks','tov':'Turnovers','fgm':'FG Made','fga':'FG Attempts','fg3m':'3P Made','fg3a':'3P Attempts','ftm':'FT Made','fta':'FT Attempts','poss':'Possessions'}
out=[]; keys=set(); player_nulls=collections.Counter()
for p in players:
    if p['season_type'] not in ['regular_season','playoffs'] or not p['gp']:continue
    y=p['season'];phase='Regular Season' if p['season_type']=='regular_season' else 'Playoffs'; key=(y,phase,p['player_id'])
    assert key not in keys;keys.add(key)
    n=new('Player',y,phase); n['Player']=names[y,p['player_id']];n['Player ID']=p['player_id'];tid=p.get('player_last_team_id') or p['team_id'];tm=teams.get((y,tid),{})
    n.update({'Team':tm.get('nba_abbrev','MULTI'),'Team ID':tid or '','Conference':tm.get('conference',''),'Age':p.get('age') or 0,'Player Team Count':p.get('team_count') or 1})
    for src,dest in mapping.items():
        if p.get(src) is None:player_nulls[src]+=1
        n[dest]=p.get(src) or 0
    n['Leader Eligible']='Yes' if n['Games']>=5 and n['Minutes']/n['Games']>=15 else 'No'
    assert n['Points']==2*n['FG Made']+n['3P Made']+n['FT Made']
    assert n['FG Made']<=n['FG Attempts'] and n['3P Made']<=n['3P Attempts']
    out.append(n)

agg=collections.defaultdict(list)
for g in games:agg[g['season'],'Regular Season' if g['game_id'].startswith('002') else 'Playoffs',g['team_id']].append(g)
for (y,phase,tid),gg in agg.items():
    n=new('Team',y,phase);tm=teams[y,tid];n.update({'Team':tm['nba_abbrev'],'Team ID':tid,'Conference':tm['conference'],'Games':len(gg),'Wins':sum(int(g['win']) for g in gg),'Last Game':str(max(g['game_date'] for g in gg))})
    for src,dest in mapping.items():
        if src not in ['gp','w']:n[dest]=sum(g.get(src) or 0 for g in gg)
    n['Opponent Points']=sum(lookup[g['game_id'],g['opp_team_id']]['pts'] for g in gg)
    n['Opponent Possessions']=sum(lookup[g['game_id'],g['opp_team_id']].get('poss') or 0 for g in gg)
    n['Pace Weighted']=sum(g.get('pace') or 0 for g in gg)
    assert n['Points']==2*n['FG Made']+n['3P Made']+n['FT Made']
    out.append(n)

for (y,phase),rs in collections.defaultdict(list).items():pass
league=collections.defaultdict(list)
for n in out:
    if n['Record Type']=='Team':league[n['Season End'],n['Phase']].append(n)
for (y,phase),rs in league.items():
    n=new('League',y,phase)
    for field,t in fields.items():
        if t!='string' and field!='Season End':n[field]=sum(r[field] for r in rs)
    n['Last Game']=max(r['Last Game'] for r in rs)
    assert n['Points']==n['Opponent Points'] and n['Games']==2*n['Wins']
    out.append(n)

summary={'rows':len(out),'types':dict(collections.Counter(r['Record Type'] for r in out)),'seasons':sorted({r['Season'] for r in out}),'phases':sorted({r['Phase'] for r in out}),'latest_game':str(max(r['game_date'] for r in games)),'player_source_nulls':dict(player_nulls),'team_game_rows':len(games),'distinct_games':len(games)//2,'league':[{**{k:r[k] for k in ['Season','Phase','Games','Points','3P Attempts','FG Attempts','3P Made','Possessions','Pace Weighted','Last Game']},'ppg':r['Points']/r['Games'],'3pa_share':r['3P Attempts']/r['FG Attempts']} for r in out if r['Record Type']=='League'],'current_leaders':sorted([{'player':r['Player'],'id':r['Player ID'],'team':r['Team'],'games':r['Games'],'ppg':r['Points']/r['Games']} for r in out if r['Record Type']=='Player' and r['Season End']==2027 and r['Phase']=='Regular Season' and r['Leader Eligible']=='Yes'],key=lambda r:-r['ppg'])[:10]}
for y in range(2015,2028):
 for phase in ['Regular Season','Playoffs']:
  eligible=[r for r in out if r['Record Type']=='Player' and r['Season End']==y and r['Phase']==phase and r['Leader Eligible']=='Yes']
  for stat in ['Points','Rebounds','Assists','3P Made']:
   for rank,r in enumerate(sorted(eligible,key=lambda r:(-r[stat]/r['Games'],r['Player'])),1):r['Rank '+stat]=rank
  team_rows=[r for r in out if r['Record Type']=='Team' and r['Season End']==y and r['Phase']==phase]
  for rank,r in enumerate(sorted(team_rows,key=lambda r:(-r['Wins']/r['Games'],r['Team'])),1):r['Team Top Fifteen']='Yes' if rank<=15 else 'No'
(P/'schema.json').write_text(json.dumps(fields,indent=2));(P/'validation.json').write_text(json.dumps(summary,indent=2))
with (P/'courtside.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(out)
print(json.dumps({k:v for k,v in summary.items() if k!='league'},indent=2))
